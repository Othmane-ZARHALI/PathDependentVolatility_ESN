# Background Notes for the PDV / Randomized-Signature Note

**Purpose.** A self-contained reading companion that supplies the theory behind A. Pallavicini's note *Mathematical Formulations of Path-Dependent Volatility via Randomized Signatures and Reservoir Computing*. The three pillars — **rough volatility**, **path-dependent volatility (PDV)**, and **signature / reservoir models** — are developed only as far as needed to read the note without gaps, with the key equations written in the same form the note uses, and with verified references so you can check everything yourself. Inline pointers "**→ note:**" connect each concept to where it appears in the paper.

A note on citations: bibliographic details below were cross-checked against the published sources (years, venues, volume/page numbers). Where the paper's own reference list is slightly off, I flag it in §7.

---

## 0. Orientation: the ladder of volatility models, and where this note sits

It helps to read the note against the standard progression of equity-volatility models, because the note is an attempt to sit at the top of all three columns at once.

| | Driver of volatility | Markovian? | Fits skew term structure? | Reproduces stylized facts? |
|---|---|---|---|---|
| Black–Scholes | constant | yes | no | no |
| Local vol (Dupire) | function of $(S_t,t)$ | yes | by construction (statically) | wrong dynamics |
| Classical stoch vol (Heston, SABR, Bergomi) | own Brownian factor(s) | yes | partially; short-end skew too flat | partially |
| Rough volatility (rBergomi, rough Heston) | fractional/Volterra noise | **no** | yes, incl. exploding short-end skew | roughness, skew $\sim\tau^{H-1/2}$ |
| Path-dependent vol (Guyon–Lekeufack) | the **price path** itself | yes (4-factor approx.) | yes | endogeneity, Zumbach, "rough-like" |
| Signature / reservoir vol | functional of a path via its (randomized) signature | yes (finite reservoir) | aims to | aims to |

The note's object is a **finite-dimensional Markovian reservoir** $R_t\in\mathbb R^N$ whose positive readout is the instantaneous variance $V_t=f(w^\top R_t+\beta)$, marketed as a single engine that (i) approximates rough behaviour, (ii) behaves like PDV, (iii) is a randomized signature, and (iv) calibrates jointly to SPX and VIX. To read it critically you need the vocabulary of all three traditions plus the VIX/forward-variance machinery. We build them in this order: volatility-modeling background (§1), the stylized facts the note targets (§2), rough/fractional processes and their Markovian approximations (§3), PDV (§4), signatures/rough-paths/reservoirs (§5), and a reading guide (§6).

---

## 1. Volatility-modeling background you will need

### 1.1 Forward variance, variance swaps, and the VIX

Let $V_t$ be the instantaneous variance ($\sigma_t^2$) of the index. Two objects recur throughout the note.

The **forward variance curve** is the term structure of expected future instantaneous variance under the pricing measure $\mathbb Q$,
$$
\xi_t(u)=\mathbb E_t^{\mathbb Q}[V_u],\qquad u\ge t,
$$
which is, by construction, a family of $\mathbb Q$-martingales in $t$. Bergomi's *forward-variance* (a.k.a. variance-curve) models take $\xi_t(\cdot)$ as the modeling primitive rather than the spot variance; this is the natural language for VIX. See Bergomi (2016) for the canonical treatment.

A **variance swap** pays realized variance; its fair strike is the (risk-neutral) expected integrated variance, $\frac1T\mathbb E_0^{\mathbb Q}[\int_0^T V_s\,ds]$. Under a *continuous* price process this equals the price of the log-contract, which is replicable by a static strip of options (Demeterfi–Derman–Kamal–Zou 1999; Carr–Madan). This is why variance is "linear" in option prices.

The **VIX** is, in the continuous-diffusion idealization, the square root of the expected forward *integrated* variance over the next $\tau=30$ days:
$$
\mathrm{VIX}_T^2=\mathbb E_T^{\mathbb Q}\!\Big[\frac1\tau\int_T^{T+\tau} V_s\,ds\Big].
$$
**→ note:** this is the note's Eq. for $\mathrm{VIX}_T^2$ in §4.3, and its VIX-futures auto-calibration in §4.2 rests on $F(T)=\mathbb E^{\mathbb Q}[\mathrm{VIX}_T]$. Two facts you must keep separate:
- Matching the **forward-variance curve** $\xi_t(u)$ (equivalently variance-swap strikes) is **linear** in $V$.
- Matching **VIX futures** $\mathbb E[\mathrm{VIX}_T]=\mathbb E[\sqrt{\,\cdot\,}]$ is **not** linear, because of the concave square root. By Jensen, $\mathbb E[\sqrt{X}]\le\sqrt{\mathbb E[X]}$; the gap is the *convexity adjustment*, a functional of the model's volatility-of-variance. (This is exactly the subtlety behind the note's deterministic rescaling $\eta(t)$.)

The actual market VIX is computed from a discrete option strip (CBOE methodology) and equals the expected integrated variance only in the no-jump limit; with jumps there is a further gap (Carr–Wu 2006).

### 1.2 The implied-volatility surface, the ATM skew, and its short-maturity slope

Write $\sigma_{\mathrm{BS}}(k,\tau)$ for the Black–Scholes implied vol at log-moneyness $k=\log(K/F_\tau)$ and maturity $\tau$. The single most diagnostic quantity for "roughness" is the **at-the-money (ATM) skew**,
$$
\mathcal S(\tau)=\Big|\partial_k\,\sigma_{\mathrm{BS}}(k,\tau)\big|_{k=0}\Big|.
$$
Empirically $\mathcal S(\tau)$ **explodes** as $\tau\to0$ like a power law $\mathcal S(\tau)\sim\tau^{H-1/2}$ with $H$ small. Classical (Markovian, Brownian-driven) stochastic-vol models produce a *bounded* short-maturity skew ($\mathcal S(\tau)\to\text{const}$), which is the empirical failure that motivated rough volatility. The power-law exponent $H-\tfrac12$ links the *skew* to the *roughness* exponent $H$ — a connection you should hold onto, because the note estimates $H$ two different ways (from variance roughness and from skew decay) and they ought to agree. (Alòs–León–Vives 2007; Fukasawa 2011, 2017; Bayer–Friz–Gatheral 2016; Bayer et al. 2019.) **→ note:** Figure 7 ("skew power-law decay") and Figure 4 ("$m_2$ scaling").

### 1.3 The leverage effect

The negative correlation between returns and contemporaneous volatility changes ($\rho<0$) generates the negative skew of equity smiles. In the note this enters as the correlation between the asset Brownian $Z^S$ and the reservoir Brownians $W$. (Black 1976; Bouchaud–Matacz–Potters 2001.)

---

## 2. The stylized facts the note tries to reproduce

The note's "diagnostics" (its §5) are exactly the canonical stylized facts of volatility. Knowing their precise statements is what lets you judge whether the model reproduces them.

### 2.1 Roughness of volatility (the Hurst exponent)

Gatheral, Jaisson & Rosenbaum (2018) measured the regularity of (log-)realized volatility from high-frequency data and found that it behaves like a fractional Brownian motion with **Hurst exponent $H\approx0.1$**, i.e. *rougher* than Brownian motion ($H=\tfrac12$), "at any reasonable timescale." Operationally, roughness is read off the **second-order structure function**
$$
m_2(\Delta)=\mathbb E\big[\,|V_{t+\Delta}-V_t|^2\big]\ \propto\ \Delta^{2H}\quad(\Delta\to0),
$$
so a log–log regression of $m_2$ against $\Delta$ has slope $2H$. **→ note:** Eq. (for $m_2$) and Figure 4; the note reports slope $0.4135\Rightarrow H\approx0.21$. The original RFSV model is *fractional stochastic volatility with $H<1/2$*; this is the empirical anchor of the whole rough-vol program. Reference: Gatheral–Jaisson–Rosenbaum (2018); the microstructural "why" is Jaisson–Rosenbaum (2016) and El Euch–Fukasawa–Rosenbaum (2018).

### 2.2 Exploding ATM skew (already in §1.2)

The skew power law $\mathcal S(\tau)\sim\tau^{H-1/2}$ is the *option-market* fingerprint of the same $H$. For a genuine single-$H$ rough model the $H$ from §2.1 and the $H$ here coincide.

### 2.3 The skew-stickiness ratio (SSR)

The **SSR** measures how much the ATM implied vol moves when the spot moves, relative to the skew:
$$
\mathrm{SSR}(\tau)=\frac{1}{\mathcal S(\tau)}\cdot\frac{\partial\,\sigma_{\mathrm{ATM}}(\tau)}{\partial\log S}.
$$
It interpolates between the "sticky-strike" and "sticky-moneyness" regimes and is a sharp test of *smile dynamics*. Bergomi–Guyon (2012) gave the expansion linking SSR to the model's skew and term structure; for rough models the short-maturity SSR is often quoted near the value $\tfrac32+H$ (treat the exact constant as a result of the rough-vol asymptotics literature, not folklore — see Bourgey–Delemotte–De Marco 2024 and the recent Friz–Gatheral 2025 "Computing the SSR"). **→ note:** Eq. (24) and Figure 6, with the important distinction the note draws between the *ATM-option SSR* and the *variance-swap SSR* (the latter strips option convexity; cf. Bergomi 2016).

### 2.4 The Zumbach effect (time-reversal asymmetry)

Financial time series are **not** time-reversal invariant: past *trends/returns* influence future volatility more than past volatility influences future returns. The standard quantitative measure is the asymmetry between the cross-correlation of future squared returns with past returns and its time-reverse. A common form (the "weak Zumbach effect") is: *past squared returns forecast future integrated variance better than past integrated variance forecasts future squared returns.* **→ note:** Eq. (23), $\mathcal Z(\Delta)=\mathbb E[r_{t+\Delta}^2 r_t]-\mathbb E[r_{t+\Delta}r_t^2]$, and Figure 5.

This is a genuine constraint that *kills most classical models*: a time-reversible diffusion cannot produce it. Rough Heston produces a *weak* Zumbach effect (Gatheral–Jusselin–Rosenbaum 2020; El Euch–Rosenbaum compute it explicitly); microstructurally it arises from **quadratic Hawkes** feedback (Blanc–Donier–Bouchaud 2017; Dandapani–Jusselin–Rosenbaum 2021). References for the effect itself: Zumbach (2009) "Time reversal invariance in finance"; Chicheportiche–Bouchaud (2014). *(Caution: it is precisely because the variance process of a time-reversible reservoir cannot generate this on its own that the note's near-zero $\mathcal Z\sim10^{-8}$ is worth scrutiny — see the review.)*

### 2.5 Is volatility "really" rough? (the debate you should know about)

There is an active controversy you should be aware of when reading any roughness claim. Estimating $H$ from discretely-sampled, noisy (proxy) volatility is biased *downward*: Gatheral–Jaisson–Rosenbaum themselves note that classical long-memory estimators are fooled by RFSV, and the converse holds too — measurement error and the use of realized-variance proxies can manufacture *apparent* roughness ("spurious roughness"). Cont–Das and Rogers argue much of the measured roughness is an artefact of the proxy; Fukasawa–Takabatake–Westphal develop estimators robust to this; Guyon–Lekeufack show a *Markovian* PDV model produces "rough-like" paths at the daily scale without any true fractional driver. Net: roughness is a statement about *finite-scale* behaviour, and a finite Markovian model can mimic it. References: Cont–Das (2024) "Rough volatility: fact or artefact?"; Rogers (2019); Fukasawa–Takabatake–Westphal (2019); Guyon–Lekeufack (2023) (their "spurious roughness" remark).

---

## 3. Fractional and rough processes (the mathematics)

### 3.1 Fractional Brownian motion and the Hurst exponent

**Fractional Brownian motion (fBM)** $B^H$ is the centered Gaussian process with $B^H_0=0$ and
$$
\mathrm{Cov}(B^H_t,B^H_s)=\tfrac12\big(|t|^{2H}+|s|^{2H}-|t-s|^{2H}\big),\qquad H\in(0,1).
$$
Key properties: it is **self-similar** with exponent $H$ ($B^H_{ct}\stackrel{d}{=}c^HB^H_t$); its increments are stationary and, for $H<\tfrac12$, **negatively correlated** (anti-persistent, "rough"); its sample paths are Hölder-continuous of any order $<H$; and it is a **semimartingale only for $H=\tfrac12$** (ordinary BM). For $H<\tfrac12$ it is neither Markov nor a semimartingale — the source of all the technical difficulty in rough volatility. (Mandelbrot–Van Ness 1968; Decreusefond–Üstünel 1999; Nualart's Malliavin-calculus book.)

For volatility one usually uses the **Riemann–Liouville (Volterra) fBM**, the building block of rough Bergomi:
$$
\widehat W^H_t=\frac{1}{\Gamma(H+\tfrac12)}\int_0^t (t-s)^{H-\frac12}\,dW_s,
$$
which has the same local regularity $H$ but a one-sided ("causal") representation. **→ note:** the kernel $K_H(t)=t^{H-1/2}/\Gamma(H+\tfrac12)$ here is *exactly* the object the note's fractional loading $D_{jj}\propto\kappa_j^{1/2-H}$ is trying to discretize (see §3.3).

The crucial fact for the note: **a finite-dimensional SDE driven by Brownian motion is a semimartingale, hence has $H=\tfrac12$ at the infinitesimal scale.** True roughness ($H<\tfrac12$) requires either a fractional/Volterra (non-Markovian) driver or an *infinite*-dimensional Markovian representation. A finite reservoir can only reproduce roughness as a *finite-scale* (pre-asymptotic) effect.

### 3.2 The three canonical rough-volatility models

- **RFSV** (rough fractional stochastic volatility) — Gatheral–Jaisson–Rosenbaum (2018): $\log\sigma_t$ is a fractional Ornstein–Uhlenbeck process with $H\approx0.1$. This is the *time-series* model.
- **Rough Bergomi** (rBergomi) — Bayer–Friz–Gatheral (2016): a forward-variance model with
$$
V_t=\xi_0(t)\,\exp\!\Big(\eta\,\widehat W^H_t-\tfrac12\eta^2 t^{2H}\Big),
$$
i.e. variance is the (normalized) exponential of a Riemann–Liouville fBM. Three parameters $(H,\eta,\rho)$; reproduces the exploding skew with a strikingly parsimonious fit; **non-Markovian**, and Monte Carlo is the workhorse (hybrid scheme of Bennedsen–Lunde–Pakkanen 2017).
- **Rough Heston** — El Euch–Rosenbaum (2018, 2019): the variance solves a **stochastic Volterra equation** (a fractional CIR),
$$
V_t=V_0+\frac1{\Gamma(\alpha)}\int_0^t (t-s)^{\alpha-1}\big[\lambda(\theta-V_s)\,ds+\nu\sqrt{V_s}\,dW_s\big],\quad \alpha=H+\tfrac12\in(\tfrac12,1).
$$
It is an **affine Volterra process** (Abi Jaber–Larsson–Pulido 2019), so its characteristic function is known via a *fractional Riccati* equation — making semi-closed-form pricing possible despite non-Markovianity. **→ note:** the note positions itself relative to these; its reservoir is an attempt to get rough-like behaviour while staying Markovian and cheap.

### 3.3 The fractional kernel and its Laplace (spectral) representation — *the* key object

This is the single most important piece of math for reading the note's architecture. The fractional kernel is **completely monotone** and admits a Laplace representation as a continuous superposition of exponentials:
$$
K_H(t)=\frac{t^{H-1/2}}{\Gamma(H+\tfrac12)}=\int_0^\infty e^{-\kappa t}\,\mu_H(d\kappa),\qquad
\mu_H(d\kappa)=\frac{\kappa^{-H-1/2}}{\Gamma(\tfrac12-H)\,\Gamma(\tfrac12+H)}\,d\kappa.
$$
(Check: $\int_0^\infty e^{-\kappa t}\kappa^{\alpha-1}d\kappa=\Gamma(\alpha)t^{-\alpha}$ with $\alpha=\tfrac12-H$.) Each $e^{-\kappa t}$ is the kernel of an **Ornstein–Uhlenbeck** process with mean-reversion speed $\kappa$. So a rough (Volterra) process is, exactly, a *continuum of OU factors* indexed by their speed $\kappa$, weighted by $\mu_H$.

**→ note:** discretizing this integral on a grid of speeds $\{\kappa_j\}$ with quadrature weights $\{c_j\}$ gives $K_H(t)\approx K_N(t)=\sum_{j=1}^N c_j e^{-\kappa_j t}$. On a **logarithmic** grid, $d\kappa\approx\kappa\,d\log\kappa$, so the mass per node scales as $\kappa^{1/2-H}$ — which is precisely the note's "fractional loading" $D_{jj}\propto\kappa_j^{1/2-H}$ and its log-spaced speeds $\kappa\in[\kappa_{\min},\kappa_{\max}]$. This identity is the rigorous content behind the note's Rough/Cascade/Unified architectures.

### 3.4 Markovian (multifactor) approximations of rough volatility

Because the kernel is a superposition of OU factors, a rough process can be **approximated by a finite Markovian system**: take $N$ OU factors $Y^j$ driven by a **common** Brownian $B$,
$$
dY^j_t=-\kappa_j Y^j_t\,dt+dB_t,\qquad X^N_t=\sum_{j=1}^N c_j Y^j_t=\int_0^t K_N(t-s)\,dB_s,
$$
and $X^N\to \int_0^t K_H(t-s)\,dB_s$ (Riemann–Liouville fBM) in $L^2$ as $K_N\to K_H$. This is the **multifactor Markovian approximation**; the finite system is Markovian in $(Y^1,\dots,Y^N)$ and converges *pathwise* to the rough process.

Literature you should know:
- **Carmona–Coutin–Montseny (2000)** — fBM as a superposition of OU processes (the original idea).
- **Abi Jaber–El Euch (2019)** "Multifactor approximation of rough volatility models" — the rough-Heston/affine-Volterra version, with convergence.
- **Abi Jaber (2019)** "Lifting the Heston model" — the *infinite-dimensional* Markovian lift (measure-valued), the $N\to\infty$ limit object; and Abi Jaber–El Euch (2019) "Markovian structure of the Volterra Heston model."
- **Bayer–Breneis (2023)** and **Harms (2020)** — *optimal* node/weight placement (Gaussian quadrature of $\mu_H$) and strong convergence **rates**; geometric in $N$ for well-chosen nodes versus algebraic for naive log-grids.

**One subtlety that is decisive for reading the note.** The pathwise approximation above requires the OU factors to share a **common** Brownian $B$. There is a *different* construction in which each factor has its **own independent** Brownian: a superposition of *independent* OU processes can reproduce a power-law **autocovariance** (Barndorff-Nielsen's "superposition of OU = long memory"; Barndorff-Nielsen–Shephard 2001), but it approximates only the *second-order/covariance* structure, not the pathwise Volterra integral. Whether a "sum of OU" model is rough *in path* (common Brownian) or merely rough *in covariance* (independent Brownians) is a real distinction — and it is exactly the distinction at issue in the note's reservoir, whose diffusion is diagonal (independent per-node Brownians). Keep this in mind; it is developed further in §5.4 and is central to the review.

A useful recent reference that compares these regimes head-on: **Abi Jaber–Li (2024)** "Volatility models in practice: Rough, Path-dependent or Markovian." A broad survey: **Di Nunno–Kubilius–Mishura–Yurchenko-Tytarenko (2023)** "From constant to rough."

---

## 4. Path-dependent volatility (PDV)

### 4.1 Endogenous volatility: Hobson–Rogers and Guyon–Lekeufack

In **path-dependent volatility** models the instantaneous volatility is a deterministic functional of the *past price path itself*, with **no independent volatility noise**:
$$
V_t=F\big(\{S_u\}_{u\le t}\big).
$$
The early example is Hobson–Rogers (1998), where volatility depends on an exponentially-weighted "offset" of past log-prices. The modern, empirically-driven version is **Guyon–Lekeufack (2023)**, "Volatility is (mostly) path-dependent." Their central empirical finding: up to roughly **90% of the variance of equity-index implied volatility (e.g. the VIX) and ~60–65% of next-day realized volatility is explained endogenously by past index returns**. The functional form is strikingly simple — a linear combination of a *trend* feature and the square root of an *activity* feature:
$$
\sigma_t=\beta_0+\beta_1 R_{1,t}+\beta_2\sqrt{R_{2,t}},\qquad
R_{1,t}=\sum_{t_i\le t}K_1(t-t_i)\,r_i,\quad
R_{2,t}=\sum_{t_i\le t}K_2(t-t_i)\,r_i^2,
$$
where $r_i$ are past daily returns and the kernels are **time-shifted power laws** (TSPL) $K_j(\tau)=Z_{\alpha_j,\delta_j}/(\tau+\delta_j)^{\alpha_j}$, with the two kernels capturing short and long memory. $R_1$ (signed, weighted past returns) is a *trend*; $\sqrt{R_2}$ (weighted past squared returns) is a *recent realized volatility*. The positive loading on $R_2$ produces **volatility clustering**; the negative loading on $R_1$ produces the **leverage effect** and, crucially, the **Zumbach** time-reversal asymmetry — because volatility responds to *past directional returns*, not just past variance.

Two structural consequences matter for the note:
- **Markovianization by exponential kernels.** A TSPL kernel can be approximated by a sum of exponentials, $K_j(\tau)\approx\sum_k \omega_{jk}e^{-\kappa_{jk}\tau}$. Each exponential turns the convolution feature into an OU-type state variable, so the path-dependent model becomes a **finite-dimensional Markov** model in those states. Guyon–Lekeufack propose a **4-factor Markovian PDV model** (two factors per kernel) that "captures all the important stylized facts, produces very realistic price and (rough-like) volatility paths, and jointly fits SPX and VIX smiles remarkably well." **→ note:** this is the conceptual template for the note's reservoir, and it is the strongest existing competitor; the note should be read as trying to generalize the readout from "$\beta_0+\beta_1 R_1+\beta_2\sqrt{R_2}$" to "$f(w^\top R)$ on a larger random reservoir."
- **"Spurious roughness."** The 4-factor model is *Markovian* (hence $H=\tfrac12$ infinitesimally) yet produces volatility paths that *look* rough at the daily scale and pass roughness estimators. This is direct evidence that finite Markovian dynamics can mimic roughness over observable scales — the honest interpretation of the note's Figure 4.

Follow-ups: implied vol is path-dependent too (Andrés–Bocquet–Lekeufack / Andrés et al. 2023); the 4-factor PDV joint SPX/VIX calibration is pushed further by Gazzani–Guyon (2024) and "Joint deep calibration of the 4-factor PDV model" (2025). The empirical-microstructure roots are Zumbach (2009), Chicheportiche–Bouchaud (2014), Blanc–Donier–Bouchaud (2017).

### 4.2 Well-posedness: PDV as a stochastic Volterra equation

Because the continuous-time PDV model feeds back the price path into the volatility, $V$ depends on $S$ which depends on $V$ — a **self-referential** (Volterra / functional) SDE with non-Lipschitz coefficients (the $\sqrt{R_2}$) and a positivity question. Existence, uniqueness, and positivity of the Guyon–Lekeufack model (as a stochastic Volterra equation with general, non-convolutional, unbounded kernels) were established by **Andrés–Jourdain (2024)**. **→ note:** this is exactly the well-posedness machinery a genuinely *price-driven* reservoir would need (the note's reservoir sidesteps it by using exogenous Brownians; see §5.4 and the review). Background on functional Itô calculus: Dupire (2019); on stochastic Volterra equations: Abi Jaber–Larsson–Pulido (2019).

---

## 5. Signatures, rough paths, and signature / reservoir models

### 5.1 The path signature

For a continuous path of bounded variation $X:[0,T]\to\mathbb R^d$, the **signature** is the infinite collection of iterated integrals
$$
S(X)_{0,T}=\Big(1,\ \big(\textstyle\int_0^T dX^{i}\big)_i,\ \big(\textstyle\int_{0<s_1<s_2<T} dX^{i}_{s_1}dX^{j}_{s_2}\big)_{i,j},\ \dots\Big)\in T((\mathbb R^d)),
$$
living in the tensor algebra. It is the noncommutative analogue of "all the moments of the path." Foundational facts:
- **Chen's identity:** the signature is multiplicative over concatenation of paths (a group-like element of the tensor algebra). (Chen 1957, 1977.)
- **Uniqueness:** the signature determines the path up to "tree-like" equivalence (reparametrization + cancellation); adding time as a coordinate removes the ambiguity. (Hambly–Lyons 2010.)
- **Universality / linear approximation:** continuous functionals of the path are approximated *arbitrarily well by linear functionals of the signature* (a Stone–Weierstrass statement on the group-like elements). This is why signatures are a *universal feature map* for sequential data — and why a **linear readout** suffices once you have enough signature terms.
- **Log-signature and the free Lie algebra:** the $\log$ of the signature lives in the free Lie algebra over $\mathbb R^d$; it is a non-redundant ("compressed") coordinate system. Level-2 terms encode **areas / Lévy area** (the antisymmetric part) and **quadratic variation / realized variance** (the symmetric part) — directly relevant to volatility and to time-reversal asymmetry.
- **Augmentations:** time augmentation, lead-lag, basepoint and cumulative transforms are standard tricks that make specific features (e.g. quadratic variation, time-reversal) linearly accessible. (Chevyrev–Kormilitzin 2016; Lyons–McLeod 2024; Kidger–Morrill et al. for the ML side.)

### 5.2 Rough paths and controlled differential equations

When the driving path $X$ is **rough** (e.g. Brownian motion, $H=\tfrac12$, or rough fBM down to $H>\tfrac14$ with a level-2 enhancement), the integrals defining the signature and the solution of a **controlled differential equation (CDE)**
$$
dY_t=\sum_i f_i(Y_t)\,dX^i_t
$$
cannot be defined pathwise by classical means. **Lyons' rough-path theory (1998)** resolves this by *enhancing* $X$ with its postulated iterated integrals (the rough path $\mathbf X$) and proving that the solution map (the **Itô–Lyons map**) is *continuous* in a rough-path metric — a deterministic, pathwise theory that contains Itô/Stratonovich calculus as special cases. The signature is precisely the object that solves the simplest (linear) CDE, $dS_t=S_t\otimes dX_t$. References: Lyons (1998); Lyons–Caruana–Lévy (2007); Friz–Victoir (2010); Friz–Hairer (2020, textbook).

### 5.3 Signature volatility models

Abi Jaber–Gérard (2025), "Signature volatility models: pricing and hedging with Fourier," take the (square-root of) instantaneous variance to be a **linear functional of the time-extended signature of a Brownian motion**,
$$
\sigma_t=\boldsymbol\ell\cdot\widehat{\mathbb X}_t,\qquad \widehat X=(t,\,W),
$$
where $W$ may be correlated with the price's Brownian. This single family is remarkably flexible: by choosing the linear functional $\boldsymbol\ell$ it can approximate rough, path-dependent, and classical dynamics, and (because of the linear-in-signature structure) it admits **Fourier/Laplace pricing**. Two readings of the *driving* path matter for the note:
- if $\widehat X$ is built from the **price's own** Brownian (time-augmented), the model is genuinely **path-dependent in the price** (endogenous);
- if $\widehat X$ is built from an **independent background** Brownian, it is a stochastic-volatility model whose "signature" is of an exogenous process, *not* of the price path.

**→ note:** the note is in the *second* category — its reservoir is driven by exogenous Brownians $W$ — which is why calling it "endogenous PDV à la Guyon–Lekeufack" is in tension with the construction (see the review). Closely related and worth reading: Cuchiero–Gazzani–Svaluto-Ferro (2023) "Signature-based models: theory and calibration"; Perez Arribas–Salvi–Szpruch (2020) "Sig-SDEs"; and — directly relevant to the well-posedness/no-arbitrage points — **Abi Jaber–Gassiat–Sotnikov (2025) "Martingale property and moment explosions in signature volatility models."**

### 5.4 Randomized signatures, reservoir computing, and echo state networks

The full signature is infinite-dimensional. A **randomized signature** replaces it by a *random projection* into $\mathbb R^N$: one solves a finite system
$$
dR_t=\Big(AR_t+\sum_i B_i\,\sigma(R_t)\Big)\,dX^i_t\quad(\text{schematically}),
$$
with **random** $A,B_i$, whose components approximate the (infinitely many) signature coordinates by a Johnson–Lindenstrauss-type argument. Cuchiero–Gonon–Grigoryeva–Ortega–Teichmann (2022) make this precise: reservoir computing is explained as random projections of state-affine systems generating Volterra-series expansions, yielding *strongly universal* finite reservoirs whose dimension is logarithmically reduced. **→ note:** this is the paper the note builds on (its reference [6]); the note's reservoir SDE $dR_t=AR_t\,dt+\Sigma(R_t)\,dW_t$ with trained linear readout $w$ is exactly a continuous-time reservoir.

The relevant background:
- **Reservoir computing / Echo State Networks (ESN) / Liquid State Machines:** a randomly initialized recurrent system with only a **trained linear readout**. The defining requirement is the **Echo State Property (ESP) / fading memory** — the reservoir asymptotically forgets its initial condition, so its state is a well-defined functional of the input history. (Jaeger 2001; Maass–Natschläger–Markram 2002.)
- **Universality:** ESNs are universal approximators of fading-memory filters (Grigoryeva–Ortega 2018, "Echo state networks are universal," *Neural Networks* 108:495–508; and their JMLR 2018 state-affine result); with stochastic inputs (Gonon–Ortega 2020); fading-memory ESNs are universal (Gonon–Ortega 2021). **Crucially, universality is *asymptotic in the reservoir dimension $N$*.**
- **Approximation / generalization rates:** Gonon–Grigoryeva–Ortega, "Risk bounds for reservoir computing" (JMLR 2020) and "Approximation bounds for random neural networks and reservoir systems" (*Ann. Appl. Probab.* 2023) give the $O(N^{-1/2})$-type rates. **→ note:** these are what one would invoke to justify the note's small $N=24$ and to quantify the error of a *linear readout on a random reservoir*.
- **Random features (the linear-readout backbone):** Rahimi–Recht (2007, "Random features for large-scale kernel machines"; 2008, "Weighted sums of random kitchen sinks") show that a random nonlinear feature map plus a *linear* readout approximates a kernel machine at rate $O(m^{-1/2})$ in the number of features $m$; statistical rates in Rudi–Rosasco (2017). This is the precise sense in which "train only the readout" is principled.
- **Directly on point:** Compagnoni et al. (2023), "On the effectiveness of randomized signatures as reservoir for learning rough dynamics" (IJCNN) — randomized signatures as reservoirs specifically for *rough* dynamics.

**The decisive subtlety again.** In the rough-approximation theory of §3.4, the OU factors must share a **common** Brownian to approximate the Volterra integral *pathwise*. A reservoir with a **diagonal** diffusion uses **independent** Brownians per node, which (per §3.4) yields long-memory at the *covariance* level only. So whether a reservoir is "rough" in the strong (pathwise) sense or only in the weak (covariance) sense depends on the *coupling of the noise*, not just on the spectrum of $A$ — a point the note's architecture choices bear on directly, and the crux of the review.

---

## 6. Reading guide: mapping the note's equations to this background

| Note (symbol / section) | What it is | Read first |
|---|---|---|
| $dR_t=AR_t\,dt+\Sigma(R_t)\,dW_t$ (§2) | continuous-time reservoir / state-affine system | §5.4, §3.4 |
| $V_t=f(w^\top R_t+\beta)$, softplus $f$ (§2) | positive *linear-readout* of a random reservoir | §5.1 (universality), §5.4 |
| exact OU step, variance $\frac{1-e^{-2\kappa\Delta}}{2\kappa}$ (§2) | exponential integrator for OU; exact only for the *linear, normal* part | §3.4 |
| $D_{jj}\propto\kappa_j^{1/2-H}$, log-spaced $\kappa$ (§3.3–3.5) | log-grid quadrature weight of the fractional measure $\mu_H$ | §3.3 |
| Rough/Cascade/Unified architectures (§3) | finite multifactor (Markovian) approximations of a rough kernel | §3.3–3.4 |
| leverage $\rho$, $d\langle Z^S,W^{(j)}\rangle=\rho\,dt$ (§4) | the leverage effect; admissibility constraint | §1.3, and the review |
| $\mathrm{VIX}_T^2=\mathbb E_T[\frac1\tau\int_T^{T+\tau}V_s\,ds]$ (§4.3) | VIX = expected forward integrated variance | §1.1 |
| $\eta(t)$ auto-calibration to VIX futures (§4.2) | matching $\mathbb E[\sqrt{\cdot}]$ — nonlinear (Jensen) | §1.1 |
| KC/RN estimator (§4.3) | a conditional-expectation regression with a random-feature correction | §5.4; and the review (geometric- vs arithmetic-mean bias) |
| $m_2(\Delta)\propto\Delta^{2H}$, skew $\sim\tau^{H-1/2}$, SSR, $\mathcal Z(\Delta)$ (§5) | the stylized-fact diagnostics | §2.1–2.4 |
| "$\rho\approx-1$ = endogenous PDV" (§5.1) | a PDV interpretation of the leverage | §4.1, §5.3; and the review |

A compact way to hold the whole picture: **rough volatility = a continuum of OU factors (a Volterra kernel); a Markovian approximation = a finite, common-driven sum of OU factors; PDV = volatility as a functional of the price path (trend + activity); a randomized signature / reservoir = a random finite-dimensional state-affine system with a trained linear readout.** The note tries to be all four at once, and the interesting questions (developed in the review) are about exactly where those identifications hold and where they break — most sharply, the common-vs-independent Brownian distinction (§3.4/§5.4), the $\mathbb Q$-vs-$\mathbb P$ measure under which the diagnostics live (§2.4–2.5), and the martingale/ergodicity well-posedness of the softplus reservoir (§4.2, §5.3).

---

## 7. References (grouped, verified)

*Bibliographic details checked against the published sources. A "†" marks a work I'd read first in each group.*

**Rough volatility — foundations and asymptotics**
- † J. Gatheral, T. Jaisson, M. Rosenbaum (2018). *Volatility is rough.* Quantitative Finance 18(6), 933–949.
- F. Comte, E. Renault (1998). *Long memory in continuous-time stochastic volatility models.* Mathematical Finance 8(4), 291–323.
- T. Jaisson, M. Rosenbaum (2016). *Rough fractional diffusions as scaling limits of nearly unstable heavy-tailed Hawkes processes.* Annals of Applied Probability 26(5), 2860–2882.
- O. El Euch, M. Fukasawa, M. Rosenbaum (2018). *The microstructural foundations of leverage effect and rough volatility.* Finance and Stochastics 22(2), 241–280.
- E. Alòs, J. León, J. Vives (2007). *On the short-time behavior of the implied volatility for jump-diffusion models with stochastic volatility.* Finance and Stochastics 11(4), 571–589.
- M. Fukasawa (2011). *Asymptotic analysis for stochastic volatility: martingale expansion.* Finance and Stochastics 15(4), 635–654; and (2017) *Short-time at-the-money skew and rough fractional volatility.* Quantitative Finance 17(2), 189–198.
- B. Mandelbrot, J. Van Ness (1968). *Fractional Brownian motions, fractional noises and applications.* SIAM Review 10(4), 422–437.

**Rough-volatility pricing models**
- † C. Bayer, P. Friz, J. Gatheral (2016). *Pricing under rough volatility.* Quantitative Finance 16(6), 887–904.
- O. El Euch, M. Rosenbaum (2019). *The characteristic function of rough Heston models.* Mathematical Finance 29(1), 3–38; and (2018) *Perfect hedging in rough Heston models.* Annals of Applied Probability 28(6), 3813–3856.
- E. Abi Jaber, M. Larsson, S. Pulido (2019). *Affine Volterra processes.* Annals of Applied Probability 29(5), 3155–3200.
- M. Bennedsen, A. Lunde, M. Pakkanen (2017). *Hybrid scheme for Brownian semistationary processes.* Finance and Stochastics 21(4), 931–965.

**Markovian / multifactor approximations of rough volatility** *(the note's reservoir lives here)*
- † E. Abi Jaber, O. El Euch (2019). *Multifactor approximation of rough volatility models.* SIAM J. Financial Mathematics 10(2), 309–349.
- E. Abi Jaber (2019). *Lifting the Heston model.* Quantitative Finance 19(12), 1995–2013; and E. Abi Jaber, O. El Euch (2019). *Markovian structure of the Volterra Heston model.* Statistics & Probability Letters 149, 63–72.
- P. Carmona, L. Coutin, G. Montseny (2000). *Approximation of some Gaussian processes.* Statistical Inference for Stochastic Processes 3(1–2), 161–171.
- C. Bayer, S. Breneis (2023). *Markovian approximations of stochastic Volterra equations with the fractional kernel.* Quantitative Finance 23(1), 53–70.
- P. Harms (2020). *Strong convergence rates for Markovian representations of fractional processes.* (arXiv:1902.01471.)
- O. Barndorff-Nielsen, N. Shephard (2001). *Non-Gaussian Ornstein–Uhlenbeck-based models...* J. Royal Statistical Society B 63(2), 167–241. *(superposition-of-OU long memory)*
- E. Abi Jaber, S. Li (2024). *Volatility models in practice: Rough, Path-dependent or Markovian.* (arXiv:2401.03345.) *(head-to-head comparison)*

**Path-dependent volatility**
- † J. Guyon, J. Lekeufack (2023). *Volatility is (mostly) path-dependent.* Quantitative Finance 23(9), 1221–1258. (SSRN 4174589, 2022.)
- J. Guyon (2014). *Path-dependent volatility.* Risk, October 2014.
- D. Hobson, L. C. G. Rogers (1998). *Complete models with stochastic volatility.* Mathematical Finance 8(1), 27–48.
- H. Andrès, B. Jourdain (2024). *Existence, uniqueness and positivity of solutions to the Guyon–Lekeufack path-dependent volatility model with general kernels.* (arXiv:2408.02477.)
- G. Gazzani, J. Guyon (2024). *Pricing and calibration in the 4-factor path-dependent volatility model.* (arXiv:2406.02319.)
- B. Dupire (2019). *Functional Itô calculus.* Quantitative Finance 19(5), 721–729.

**Stylized facts: leverage, SSR, Zumbach / time-reversal**
- R. Cont (2001). *Empirical properties of asset returns: stylized facts and statistical issues.* Quantitative Finance 1(2), 223–236.
- L. Bergomi, J. Guyon (2012). *Stochastic volatility's orderly smiles.* Risk 25(5), 60–66.
- F. Bourgey, J. Delemotte, S. De Marco (2024). *Smile dynamics and rough volatility.* (SSRN.) — and P. Friz, J. Gatheral (2025). *Computing the SSR.* Quantitative Finance 25(5), 701–710.
- G. Zumbach (2009). *Time reversal invariance in finance.* Quantitative Finance 9(5), 505–515.
- R. Chicheportiche, J.-P. Bouchaud (2014). *The fine-structure of volatility feedback I: multi-scale self-reflexivity.* Physica A 410, 174–195.
- P. Blanc, J. Donier, J.-P. Bouchaud (2017). *Quadratic Hawkes processes for financial prices.* Quantitative Finance 17(2), 171–188.
- A. Dandapani, P. Jusselin, M. Rosenbaum (2021). *From quadratic Hawkes processes to super-Heston rough volatility models with Zumbach effect.* Quantitative Finance 21(8), 1235–1247.

**Is volatility really rough? (the debate)**
- R. Cont, P. Das (2024). *Rough volatility: fact or artefact?* Sankhya B 86, 191–223.
- L. C. G. Rogers (2019). *Things we think we know.* (Working paper / in *Options — 45 Years...*, 2023.)
- M. Fukasawa, T. Takabatake, R. Westphal (2019/2022). *Is volatility rough?* (arXiv:1905.04852.)

**Signatures and rough paths**
- † T. Lyons (1998). *Differential equations driven by rough signals.* Revista Matemática Iberoamericana 14(2), 215–310.
- T. Lyons, M. Caruana, T. Lévy (2007). *Differential Equations Driven by Rough Paths.* Lecture Notes in Mathematics 1908, Springer (Saint-Flour 2004).
- P. Friz, N. Victoir (2010). *Multidimensional Stochastic Processes as Rough Paths.* Cambridge University Press.
- P. Friz, M. Hairer (2020). *A Course on Rough Paths*, 2nd ed. Springer (Universitext). *(best textbook entry point)*
- K.-T. Chen (1957, 1977). *Integration of paths...* / *Iterated path integrals.* Annals of Mathematics 65(1); Bulletin AMS 83(5).
- B. Hambly, T. Lyons (2010). *Uniqueness for the signature of a path of bounded variation and the reduced path group.* Annals of Mathematics 171(1), 109–167.
- † I. Chevyrev, A. Kormilitzin (2016). *A primer on the signature method in machine learning.* (arXiv:1603.03788.) — and T. Lyons, A. McLeod (2024). *Signature methods in machine learning.* EMS Surveys.

**Signature / sig-SDE volatility models**
- † E. Abi Jaber, L.-A. Gérard (2025). *Signature volatility models: pricing and hedging with Fourier.* SIAM J. Financial Mathematics 16(2), 606–642. (arXiv:2402.01820.)
- E. Abi Jaber, P. Gassiat, D. Sotnikov (2025). *Martingale property and moment explosions in signature volatility models.* (arXiv:2503.17103.)
- C. Cuchiero, G. Gazzani, S. Svaluto-Ferro (2023). *Signature-based models: theory and calibration.* SIAM J. Financial Mathematics 14(3), 910–957.
- I. Perez Arribas, C. Salvi, L. Szpruch (2020). *Sig-SDEs model for quantitative finance.* ACM ICAIF.

**Reservoir computing, randomized signatures, random features**
- † C. Cuchiero, L. Gonon, L. Grigoryeva, J.-P. Ortega, J. Teichmann (2022). *Discrete-time signatures and randomness in reservoir computing.* IEEE Trans. Neural Networks and Learning Systems 33(11), 6321–6330. (doi:10.1109/TNNLS.2021.3076777) — *the note's ref [6].*
- L. Grigoryeva, J.-P. Ortega (2018). *Echo state networks are universal.* Neural Networks 108, 495–508; and *Universal discrete-time reservoir computers... state-affine systems.* JMLR 19(24), 1–40.
- L. Gonon, J.-P. Ortega (2020). *Reservoir computing universality with stochastic inputs.* IEEE TNNLS 31(1), 100–112; and (2021) *Fading memory echo state networks are universal.* Neural Networks 138, 10–13.
- L. Gonon, L. Grigoryeva, J.-P. Ortega (2020). *Risk bounds for reservoir computing.* JMLR 21(240), 1–61; and (2023) *Approximation bounds for random neural networks and reservoir systems.* Annals of Applied Probability 33(1), 28–69.
- H. Jaeger (2001). *The "echo state" approach...* GMD Report 148. — W. Maass, T. Natschläger, H. Markram (2002). *Real-time computing without stable states.* Neural Computation 14(11), 2531–2560.
- A. Rahimi, B. Recht (2007). *Random features for large-scale kernel machines*; (2008) *Weighted sums of random kitchen sinks.* NeurIPS. — A. Rudi, L. Rosasco (2017). *Generalization properties of learning with random features.* NeurIPS.
- E. M. Compagnoni et al. (2023). *On the effectiveness of randomized signatures as reservoir for learning rough dynamics.* IJCNN.

**VIX, variance swaps, joint SPX/VIX calibration**
- † L. Bergomi (2016). *Stochastic Volatility Modeling.* Chapman & Hall/CRC. *(the note's ref [3]; SSR, forward variance, VIX)*
- K. Demeterfi, E. Derman, M. Kamal, J. Zou (1999). *More than you ever wanted to know about volatility swaps.* Goldman Sachs Quantitative Strategies Research Notes.
- P. Carr, L. Wu (2006). *A tale of two indices.* Journal of Derivatives 13(3), 13–29.
- J. Gatheral, P. Jusselin, M. Rosenbaum (2020). *The quadratic rough Heston model and the joint S&P 500/VIX smile calibration problem.* Risk, May 2020.
- E. Abi Jaber, C. Illand, S. Li (2023). *The quintic Ornstein–Uhlenbeck volatility model that jointly calibrates SPX & VIX smiles.* Risk, Cutting Edge.
- F. Baschetti, G. Bormetti, S. Romagnoli, P. Rossi (2022). *The SINC way: a fast and accurate approach to Fourier pricing.* Quantitative Finance 22(3), 427–446. *(the Baschetti–Bormetti–Rossi group; cf. the note's ref [2] on deep PDV calibration)*

**Surveys / textbooks (overview reading)**
- G. Di Nunno, K. Kubilius, Y. Mishura, A. Yurchenko-Tytarenko (2023). *From constant to rough: a survey of continuous volatility modeling.* Mathematics 11(19).
- J. Gatheral (2006). *The Volatility Surface: A Practitioner's Guide.* Wiley.
- C. Bayer, P. Friz, M. Fukasawa, J. Gatheral, A. Jacquier, M. Rosenbaum, eds. (2023). *Rough Volatility.* SIAM. *(the field's reference volume)*

---

### Appendix: corrections to the note's own reference list (worth checking yourself)

While verifying the above I noticed the note's bibliography has a few slips you may want to fix when you revise it:
- **Ref [4]** (quadratic Hawkes) is listed as "Blanc, Donier, Bouchaud (2014), Quantitative Finance 14(10), 1705–1720." The correct publication is **Blanc, Donier, Bouchaud (2017), Quantitative Finance 17(2), 171–188** (the 2014 is the arXiv preprint).
- **Ref [1]** (signature volatility) is listed as "(2024), SIAM J. Financial Mathematics." It appeared as **Abi Jaber & Gérard (2025), *Signature volatility models: pricing and hedging with Fourier*, SIAM J. Financial Mathematics 16(2), 606–642** (arXiv 2024). Worth giving the full title and pages.
- **Ref [9]** (Zumbach) is listed as "Zumbach (2010), *The empirical properties of financial market series*, Quantitative Finance 10(4), 451–460." The standard reference for the *Zumbach effect / time-reversal asymmetry* — which is what the note's §5.3 actually uses — is **Zumbach (2009), *Time reversal invariance in finance*, Quantitative Finance 9(5), 505–515.** Consider citing that one (the cited 2010 paper is a different Zumbach article).
- **Ref [5]** (smile dynamics) is dated 2022; the SSRN version of Bourgey–Delemotte–De Marco, *Smile dynamics and rough volatility*, is generally cited as **2024**.
