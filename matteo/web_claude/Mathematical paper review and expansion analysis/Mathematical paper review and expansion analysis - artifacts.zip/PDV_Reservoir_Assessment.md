# Rigorous Assessment of *Path-Dependent Volatility via Randomized Signatures and Reservoir Computing* (Pallavicini, May 2026) and its First Review

**Scope of this report.** I audit (i) the mathematical content of the note, (ii) the correctness of the first review, and (iii) the gaps that *neither* document addresses, from both a financial-mathematics and a machine-learning standpoint. I then give a corrected/strengthened theorem set to build the paper around, comment on journal fit, and close with a future-development programme together with its mathematical consequences. Throughout, I distinguish clearly between what is *proved*, what is a *proposition needing standard work*, and what is a *heuristic/mechanism* argument.

Notation follows the note: reservoir $R_t\in\mathbb{R}^N$, $dR_t=AR_t\,dt+\Sigma(R_t)\,dW_t$ with $W$ an $N$-dimensional Brownian motion; variance readout $V_t=\eta(t)\,f(w^\top R_t+\beta)$ with $f$ the Softplus; asset $dS_t/S_t=\sqrt{V_t}\,dZ^S_t$.

---

## 1. Summary verdict

The note contains a genuinely good idea — *a finite-dimensional, trainable, Markovian reservoir as a compressed surrogate for path-dependent / rough volatility, jointly calibrated to SPX and VIX with pathwise gradients* — but in its present form it is a technical prototype, not a theorem-driven manuscript. The first review is **high quality and substantially correct**: its four critical objections are all valid, and its eight proposed theorems are sound up to two minor formal slips (Theorem 3's transpose, Theorem 8's loose statement of the limit). I confirm each below.

However, the review stops short on the two points that matter most for the paper's identity:

1. **Financial-mathematics:** the construction is, mathematically, a *nonlinear, trainable version of the Markovian "lift" of rough volatility* (Abi Jaber–El Euch, Carmona–Coutin–Montseny, Bayer–Breneis). Neither document makes this connection, yet it is simultaneously the correct positioning, the source of the strongest provable theorem, and the place where the "roughness" claim must be repaired.
2. **Machine-learning:** the note invokes *randomized signatures* (Cuchiero et al.) as theoretical backing, but the reservoir is driven by an **exogenous Brownian motion**, not by the price path. A randomized signature of a *path* is a different object with different (and much stronger) universal-approximation guarantees. The model as written is a **latent stochastic-volatility reservoir**, not a randomized signature of price; the cited universality theorems do not apply to it.

Both points are correctness issues as much as positioning issues, and both have clean fixes. With the review's corrections plus the additions in §4–§6, the paper has a defensible SIFIN contribution.

---

## 2. The model, restated cleanly

The instantaneous variance is a positive nonlinear readout of a hidden multivariate Ornstein–Uhlenbeck-type reservoir whose diffusion is itself state-dependent:
$$
dR_t = A R_t\,dt + \Sigma(R_t)\,dW_t,\qquad
V_t=\eta(t)\,f\!\big(w^\top R_t+\beta\big),\qquad f(x)=\log(1+e^x).
$$
Five architectures differ only in $(A,\Sigma)$: Lightweight (diagonal $A$, $\tanh$ diffusion), Blockwise (sparse Erdős–Rényi blocks), Rough (orthogonal blocks with fractional modulus, loading $D_{jj}\propto\kappa_j^{1/2-H}$), Cascade (upper-bidiagonal $A$, same loading), Unified (diagonal $A$, bimodal loading, **Softplus** diffusion). Pricing is by Monte Carlo with exact pathwise sensitivities; a deterministic multiplier $\eta(t)$ rescales variance to the VIX-futures curve; VIX options use the KC/RN estimator
$$
\widehat{\mathbb{E}_T[\mathrm{VIX}_T^2]}=C_{\mathrm{KC}}(R_T)\exp\!\big(\xi^\top\Phi(R_T)\big),\qquad
C_{\mathrm{KC}}\ \text{Nadaraya–Watson},\ \ \Phi\ \text{random features}.
$$

Two structural facts govern everything that follows. **(a)** With each architecture's $\Sigma$ *diagonal*, node $j$ is driven by its **own** noise $W^{(j)}$; inter-node coupling enters only through the off-diagonal drift $A$ (Cascade/Blockwise/Rough) and through the nonlinear argument $BR$ (or $CR$) inside the diffusion. **(b)** The reservoir is **autonomous** — it is not fed the price path; price-dependence enters *only* through the leverage correlation between $Z^S$ and $W$. Keep both in mind.

---

## 3. Where the review is correct (and how I would sharpen it)

### 3.1 The leverage specification is invalid as written — confirmed, with a better fix

The note imposes $d\langle Z^S,W^{(j)}\rangle_t=\rho\,dt$ for **all** nodes $j$ and reports $\rho\approx-1$. For $W$ an $N$-dimensional Brownian motion with identity covariance, the instantaneous covariance of $(Z^S,W)$ is
$$
M=\begin{pmatrix}1&\rho\mathbf{1}^\top\\ \rho\mathbf{1}&I_N\end{pmatrix}.
$$
Since $I_N\succ0$, $M\succeq0$ iff its Schur complement is nonnegative: $1-\rho^2\,\mathbf{1}^\top I_N^{-1}\mathbf{1}=1-N\rho^2\ge0$, i.e.
$$
\boxed{\;|\rho|\le N^{-1/2}\;}
$$
For $N=24$ this caps the leverage at $|\rho|\le 1/\sqrt{24}\approx0.204$, so $\rho\approx-1$ is **infeasible** under the stated reading. The review's catch and its remedy — a correlation vector $\varrho\in\mathbb{R}^N$, $\|\varrho\|\le1$, with $dZ^S_t=\varrho^\top dW_t+\sqrt{1-\|\varrho\|^2}\,dB_t$ ($B\perp W$) — are correct, and $\rho=-1$ then means perfect anti-correlation with the *aggregate* direction $u^\top W$, $\varrho=\rho u$, $\|u\|=1$.

**Sharper fix.** Because variance is one-dimensional, the *economically meaningful* leverage is the correlation between the return shock and the martingale part of $dV_t$, which by Itô is $\eta(t)f'(w^\top R_t+\beta)\,w^\top\Sigma(R_t)\,dW_t$. The natural unit direction is therefore the **state-dependent**
$$
u_t=\frac{\Sigma(R_t)^\top w}{\|\Sigma(R_t)^\top w\|},\qquad dZ^S_t=\rho\,u_t^\top dW_t+\sqrt{1-\rho^2}\,dB_t,
$$
which delivers a *single* scalar leverage $\rho\in[-1,1]$ that genuinely controls $d\langle Z^S,V\rangle_t$ and is always admissible. A fixed $\varrho$ (the review's version) is the constant-direction special case; the variance-gradient direction is the principled choice and is what the calibrated $\rho\approx-1$ should be interpreted against. Note also that the SSR proxy (note, eq. 24) perturbs $W_0$ by $h\rho$ and so silently assumes the *scalar-all-node* convention; under either correct convention it must read $\sigma(W_0+h\,\varrho)$ (or $h\rho\,u_0$).

**Consequence to flag in the paper:** under the corrected spec, $\rho=-1$ is achievable but forces $B\equiv0$ — the asset is driven *entirely* by the reservoir's aggregate direction, i.e. **pure endogenous volatility with zero idiosyncratic spot noise**. The note in fact embraces this reading; it should be stated as a deliberate (and strong) modelling assumption, not as an incidental calibration outcome.

### 3.2 A finite-dimensional Itô reservoir cannot be infinitesimally rough — confirmed, and central

This is the single most important conceptual point, and it is correct. If $V_t=g(R_t)$ with $g\in C^2$ and $dR_t=b(R_t)\,dt+\Sigma(R_t)\,dW_t$, then by Itô
$$
dV_t=\Big[\nabla g^\top b+\tfrac12\mathrm{Tr}\big(\Sigma\Sigma^\top D^2g\big)\Big](R_t)\,dt+\nabla g(R_t)^\top\Sigma(R_t)\,dW_t,
$$
so the increment's drift contributes $O(\Delta^2)$ to the second moment and, by the Itô isometry,
$$
\mathbb{E}\big[(V_{t+\Delta}-V_t)^2\mid\mathcal{F}_t\big]=\big\|\Sigma(R_t)^\top\nabla g(R_t)\big\|^2\,\Delta+o(\Delta).
$$
Hence $m_2(\Delta)=\mathbb{E}[(V_{t+\Delta}-V_t)^2]\sim C\Delta$, i.e. the **true infinitesimal Hurst exponent is $H=1/2$** for *every* finite $N$ (the diffusion coefficient is non-degenerate). The estimated $H\approx0.207$ (note, Fig. 4) is therefore a *finite-scale / pre-asymptotic* effect, not a small-time limit. (The review writes $\|\Sigma\nabla g\|^2$ where it should be $\|\Sigma^\top\nabla g\|^2$; immaterial for the diagonal $\Sigma$ used here, but state it with the transpose.)

This is not a weakness to hide — it is the honest framing, and it connects directly to §4.1. **Two internal diagnostics in the note already corroborate it:**

- The note reports **two mutually inconsistent** roughness estimates: $H\approx0.207$ from variance scaling (Fig. 4) versus $H\approx0.289$ from the skew term structure (Fig. 7). In a genuine fractional model these must coincide. Their disagreement is precisely what Theorem 3 predicts — there is no single underlying $H$, only observable-dependent *effective* exponents.
- The SSR plot (Fig. 6) rises toward $\approx2$ at the shortest maturities. If the canonical short-maturity limit $3/2+H$ held with $H\approx0.2$ one would expect $\approx1.7$; the observed approach to $2$ is the signature of the true $H=1/2$ infinitesimal limit. The model's own SSR diagnostic is evidence for its semimartingale nature.

**Recommendation:** replace "generates rough fractional asymptotics" by "reproduces apparent rough scaling over a market-relevant band of lags, with a semimartingale $\Delta\!\downarrow\!0$ limit; genuine roughness is recovered only in the infinite-reservoir / continuum limit (§4.1)." Report the two $H$-estimates side by side *as a feature* and explain the scale separation.

### 3.3 "Exact integration" is an exponential-Euler scheme — confirmed, with the order made precise

The exact-OU update with Gaussian variance $(1-e^{-2\kappa\Delta})/(2\kappa)$ is exact **only** when $\Sigma$ is frozen/deterministic on the step. For state-dependent $\Sigma(R_t)$ the stochastic convolution $\int_t^{t+\Delta}e^{A(t+\Delta-s)}\Sigma(R_s)\,dW_s$ is **not** Gaussian conditional on $\mathcal{F}_t$. The scheme is a *stochastic exponential Euler* (exponential integrator): exact in the linear OU drift, frozen-coefficient in the diffusion.

I would add the precise characterisation, which is favourable to the paper:
- **Strong order $1/2$** for multiplicative noise (general $\Sigma(R)$); strong order $1$ if $\Sigma$ were additive. So the variance formula is exact for the *additive part of each step* but the freezing of $\Sigma$ over $[t,t+\Delta]$ is the $O(\sqrt\Delta)$ approximation.
- **Unconditional ($A$-) stability** for stiff mean-reversion. This is the real value: with $\kappa_{\max}=250$ and $dt=1/252$, $\kappa_{\max}\,dt\approx1$, a regime where explicit Euler–Maruyama is unstable (the genuine source of "volatility collapse"). The exponential integrator handles arbitrary stiffness with no step restriction and preserves the invariant Gaussian exactly (review's Theorem 5).

So the claim should be *"a stable exponential integrator, exact in the linear drift and unconditionally stable for stiff decay, of strong order $1/2$ in the frozen diffusion,"* with a one-line strong-error proposition.

### 3.4 VIX-futures auto-calibration is nonlinear across maturities — confirmed, with two additions

The review is right that variance-swap matching is linear in $\eta$ but VIX matching is not, because $\mathrm{VIX}_T=\sqrt{\tfrac1\tau\,\mathbb{E}_T[\int_T^{T+\tau}V_s\,ds]}$ involves a square root. For a *single* window with $\eta\equiv\lambda$ constant on $[T,T+\tau]$, $\mathrm{VIX}_T(\lambda)=\sqrt\lambda\,\mathrm{VIX}_T(1)$ and the exact multiplier is $\lambda^\star=(F_{\mathrm{mkt}}(T)/\mathbb{E}[\mathrm{VIX}_T(1)])^2$ (review's Theorem 6, correct). Two refinements:

- **Overlapping windows couple the multipliers.** Distinct futures expiries $T_1<T_2$ have overlapping averaging windows $[T_i,T_i+\tau]$, so a piecewise-constant $\eta$ on a fine grid is *shared* across expiries. Exact matching of the whole curve is a triangular nonlinear system, solvable by forward substitution if the $\eta$-grid is aligned to the expiry/window lattice, by fixed point otherwise. State this; do not claim a closed form for the term structure.
- **Idealised vs. listed VIX.** The note uses the continuous-monitoring variance-swap definition $\mathrm{VIX}_T^2=\mathbb{E}_T[\tfrac1\tau\int V]$. The listed VIX is a *log-strip* (replication of the log-contract); for a pure-diffusion model the two agree up to discretisation, but the discrepancy is non-negligible for precise calibration and should be acknowledged. Relatedly, "arbitrage-free pricing of VIX options" is unjustified: matching futures via $\eta$ does **not** imply absence of static arbitrage in the VIX *option* surface, nor joint SPX–VIX no-arbitrage (§4.1, point 4). Downgrade to "dynamically consistent within the calibrated model; static no-arbitrage checks reported separately."

### 3.5 The eight proposed theorems — correctness audit

- **T1 (admissible leverage):** correct (Schur complement, as above).
- **T2 (well-posedness):** correct in substance — linear drift is globally Lipschitz with linear growth; $\Sigma$ globally Lipschitz with linear growth gives a unique non-explosive strong solution; $f>0,\eta>0\Rightarrow V_t>0$; $S$ is the stochastic exponential, positive; true-martingale via Novikov. But the martingale clause is **architecture-dependent** and the note's blanket statement is too strong — see §4.1, point 3, where I split it into a clean unconditional result for bounded ($\tanh$) diffusions and a genuine caveat for the Unified (Softplus) diffusion.
- **T3 (semimartingale roughness):** correct (transpose slip noted in §3.2). This should be a headline theorem, not an aside.
- **T4 (log-spaced reservoirs approximate rough Volterra kernels):** correct, and the strongest result. I verify the Laplace representation below and then explain a subtlety the review glosses (shared vs. independent driving noise) in §4.1, point 1.
- **T5 (exponential-OU stability):** correct; reframe as *unconditional stability + exact invariant measure* (§3.3).
- **T6 (one-window VIX rescaling):** correct; multi-window coupling as in §3.4.
- **T7 (positivity of KC/RN):** correct and worth keeping — positive weighted average of positive $Y^{(p)}$ times a positive exponential. Positivity is not cosmetic; negative conditional-variance estimates are the standard failure of polynomial regressions for VIX.
- **T8 (consistency of KC/RN):** the *substance* — a Jensen/log bias — is correct and important, but the statement is loose. I give the precise version and a clean correction in §4.2.

**Verification of the T4 Laplace representation** (used repeatedly below). For $H\in(0,\tfrac12)$ set $\alpha=\tfrac12-H\in(0,\tfrac12)$. The Riemann–Liouville kernel $K_H(t)=t^{H-1/2}/\Gamma(H+\tfrac12)=t^{-\alpha}/\Gamma(1-\alpha)$ is completely monotone, and using $\int_0^\infty e^{-\kappa t}\kappa^{\alpha-1}\,d\kappa=\Gamma(\alpha)t^{-\alpha}$,
$$
K_H(t)=\int_0^\infty e^{-\kappa t}\,\mu_H(d\kappa),\qquad
\mu_H(d\kappa)=\frac{\kappa^{\alpha-1}}{\Gamma(\alpha)\Gamma(1-\alpha)}\,d\kappa,\qquad \Gamma(\alpha)\Gamma(1-\alpha)=\frac{\pi}{\sin\pi\alpha}.
$$
On a logarithmic node grid, $d\kappa=\kappa\,d\log\kappa$, so the quadrature mass is $\kappa^{\alpha-1}d\kappa=\kappa^{\alpha}\,d\log\kappa=\kappa^{1/2-H}\,d\log\kappa$. **This is exactly the note's loading $D_{jj}\propto\kappa_j^{1/2-H}$.** The fractional weighting is therefore not a heuristic — it is the log-grid quadrature weight of the fractional spectral measure. This deserves to be the paper's mathematical centrepiece.

---

## 4. What the review misses

### 4.1 Financial-mathematics

**1) The construction is a (nonlinear, trainable) Markovian lift of rough volatility — and the kernel theorem needs the right noise structure.**
The exponential-mixture approximation of $K_H$ is the **multifactor / lifted** representation of rough volatility (Abi Jaber–El Euch 2019; Bayer–Breneis 2023; Carmona–Coutin–Montseny; Cuchiero–Teichmann for the affine/Volterra view). The honest one-line positioning is: *a randomized reservoir is a trainable, nonlinear, finite-dimensional Markovian lift of a rough/path-dependent volatility, with the log-grid spectral design supplying the fractional kernel.* Citing this literature both fixes the "roughness" overclaim and *strengthens* the contribution (the novelty is the nonlinearity and the joint SPX/VIX/Zumbach/SSR fit, not the lift itself).

But there is a subtlety the review's T4 setup hides. T4 proves, by Itô isometry,
$$
\sup_{t\le T}\mathbb{E}\big|X_t-X_t^N\big|^2\le\int_0^T\big|K_H(u)-K_N(u)\big|^2\,du,\qquad
X_t=\int_0^t K_H(t-s)\,dB_s,\ \ X_t^N=\int_0^t K_N(t-s)\,dB_s,
$$
for a **single shared** Brownian motion $B$ — the moving-average / lifted representation. The note's architectures instead drive each OU node with an **independent** $W^{(j)}$ and use a **nonlinear, state-dependent** $\Sigma$. These differ:
- *Independent noise, linear $\Sigma$:* $w^\top R_t=\sum_j w_j R^{(j)}_t$ is a sum of *independent* OU processes; its stationary autocovariance $\sum_j w_j^2\frac{\sigma_j^2}{2\kappa_j}e^{-\kappa_j\tau}$ is a completely monotone mixture that can match the fractional **autocovariance** over a finite band (Bernstein), but the process is *not* the fractional moving average — multi-time and pathwise laws differ.
- *Shared noise, linear $\Sigma$ (the true lift):* recovers $X^N\to X$ pathwise in $L^2$ with explicit rate.

So the clean statement is **covariance-level** approximation for the as-written architecture, and **pathwise** approximation only for a *shared-noise linear variant*. I recommend introducing exactly such a linear variant, proving T4 for it (covariance and, with shared noise, pathwise), then treating the nonlinear $\Sigma$ and readout as a Lipschitz perturbation whose propagation is controlled by Grönwall (§6, Theorem D). Be explicit that the model is **not** a pathwise approximation of fBm; it matches second-order roughness and adds non-Gaussian features.

*Bonus that supports the Cascade/Rough designs.* For non-normal $A$ (Cascade is upper-bidiagonal; Rough has rotational blocks), $e^{Au}$ contains confluent terms $u^k e^{-\kappa u}$ (Jordan/Laguerre-type), a *richer* basis than pure exponentials and a known accelerator of rational/Laplace approximation of $s^{-\alpha}$. So non-normality serves double duty — better kernel approximation per node *and* broken time-reversibility (next point). Worth stating as a remark.

**2) Where does the Zumbach asymmetry come from? It is leverage-driven, and it is the antisymmetric ("area") part of the dynamics.**
Because the reservoir is autonomous (driven by $W$, not by price), the time-reversal asymmetry $\mathcal Z(\Delta)=\mathbb{E}[r_{t+\Delta}^2 r_t]-\mathbb{E}[r_{t+\Delta}r_t^2]$ cannot come from price→vol feedback (there is none). A leading-order computation in $dt$, with $r_t\approx\sqrt{V_t}\,\epsilon_t\sqrt{dt}$, gives
$$
\mathcal Z(\Delta)=\rho\,G(\Delta)+o(\cdot),
$$
where $G$ encodes the asymmetric transmission of a past return shock (correlated, via $\rho$, with the vol innovation) into future variance through the memory operator $A$, minus the time-reversed term. **Consequences:** (a) at $\rho=0$ the model produces *no* Zumbach effect at leading order — a purely orthogonal-vol-noise reservoir is Zumbach-silent; (b) the *sign* of $\mathcal Z$ is governed by $\mathrm{sign}(\rho)$, so the empirically required $\rho\approx-1$ is exactly what generates strongly negative $\mathcal Z$ (note, Fig. 5); (c) this ties the headline Zumbach result to the *corrected* leverage parametrisation of §3.1 — the very value ($\rho\approx-1$) that the broken spec could not realise. I would present this as a *Proposition (mechanism)* (honest about being a leading-order expansion) rather than overclaiming a theorem; it transforms the Zumbach plot from "the network learned it" into "here is precisely why." (Conceptually: $\mathcal Z$ is an *area*-type, time-irreversible statistic — see §7 on the $K=S+A$ decomposition.)

**3) Martingality: clean for bounded diffusion, genuinely delicate for the Unified architecture.** This sharpens T2.

> **Theorem A (unconditional true martingale, bounded-diffusion architectures).** Let $A$ be stable ($\mathrm{Re}\,\mathrm{spec}(A)<0$), $f$ Softplus, $\eta$ deterministic and locally bounded, and $\Sigma$ **bounded** and globally Lipschitz (the $\tanh$ architectures: Lightweight, Blockwise, Rough, Cascade). Then $S$ is a true martingale on $[0,T]$ for every $T<\infty$, with **no** parameter restriction.
>
> *Proof.* $w^\top R_t=\int_0^t\!\big(w^\top e^{A(t-s)}\Sigma(R_s)\big)\,dW_s+w^\top e^{At}R_0$ is a continuous martingale (plus deterministic part) whose quadratic variation is bounded uniformly in $t$: $\int_0^t\|w^\top e^{A(t-s)}\Sigma(R_s)\|^2\,ds\le \|w\|^2\Sigma_{\max}^2\!\int_0^\infty\|e^{Au}\|^2du=:C_\infty<\infty$ by stability. Hence $w^\top R_t$ is uniformly sub-Gaussian. Softplus obeys $f(x)\le|x|+\log2$, so $0<V_s\le\eta_{\max}(|w^\top R_s+\beta|+\log2)$. By Jensen (convexity of $\exp$, viewing $T^{-1}ds$ as a probability measure),
> $$\exp\!\Big(\tfrac12\!\int_0^T\! V_s\,ds\Big)\le \tfrac1T\!\int_0^T\!\exp\!\big(\tfrac{T}{2}V_s\big)\,ds,$$
> and $\mathbb{E}\exp(\tfrac{T}{2}V_s)<\infty$ uniformly by sub-Gaussianity. Thus Novikov's condition $\mathbb{E}\exp(\tfrac12\int_0^T V_s\,ds)<\infty$ holds and $\mathcal E(\int\!\sqrt V\,dZ)$ is a true martingale. $\square$

> **Caveat / Proposition B (Unified architecture).** With the Softplus *diffusion* $\Sigma(r)=D\,\mathrm{diag}(\log(1+\exp(Cr+b)))$, $\Sigma$ has **linear growth**, so $R_t$ has all polynomial moments but, generically, *no* exponential moments: the dynamics are geometric-type, with potentially power-law (Kesten-type) stationary tails. Then $V_t=f(w^\top R_t+\beta)$ inherits heavy tails and Novikov can **fail** — $S$ may be a strict local martingale, with the usual consequences (call–put parity violation, mispriced forwards). *Sufficient conditions for true martingality:* (i) a spectral/growth condition forcing sub-exponential stationary tails (effectively $\min_j\kappa_j$ large relative to $\|C\|\,\|D\|$); or, cleanly, (ii) **cap the diffusion** with a saturating Softplus $\sigma_{\max}\tanh(\mathrm{softplus}(\cdot)/\sigma_{\max})$, restoring boundedness and hence Theorem A. I would adopt (ii) and reserve the uncapped Unified for a remark — this is exactly the kind of point a SIFIN referee will press.

**4) The joint SPX–VIX no-arbitrage problem is not engaged.** This is Guyon's home turf (Guyon 2020; Acciaio–Guyon; De Marco). There exist hard *model-free* no-arbitrage constraints linking SPX and VIX smiles. The note claims joint calibration but never positions the model inside (or relative to) this frontier. A *dynamic* model such as this has a structural advantage — joint arbitrage-freeness is automatic *within* the model if $S$ is a true martingale and $\mathrm{VIX}^2$ is a genuine conditional expectation of forward variance — but that is precisely the chain that Theorem A/Proposition B make conditional. I would add: a proposition that, under Theorem A and the *exact* (not regressed) conditional expectation, the model produces SPX and VIX prices consistent by construction, and then a numerical static-arbitrage audit of the *calibrated* surfaces (butterfly/calendar for SPX; the SPX–VIX duality bounds for VIX). Without this, "joint calibration" reads as "fit two surfaces," not "respect their coupling."

**5) Two minor but checkable overstatements.** (a) The Lightweight equalisation $\nu_j\propto\sqrt{\kappa_j}$ equalises stationary variance *only in the constant-diffusion (linearised) regime*; with $\tanh$ it is an approximation, so "strictly equalized" should be "equalized to leading order." (b) The same linear-vs-nonlinear gap recurs wherever stationary moments are quoted; one paragraph acknowledging that closed-form stationary statistics hold for the linear skeleton and approximately for the nonlinear model would pre-empt referee friction.

### 4.2 Machine-learning

**1) "Randomized signature" is the wrong label for a noise-driven reservoir.** A randomized signature (Cuchiero–Gonon–Grigoryeva–Ortega–Teichmann 2020) is a random projection of the iterated-integral signature of a *path* $X$, realised by a controlled reservoir **driven by the signal**:
$$
d\widehat S_t=\sum_i \sigma\!\big(A_i\widehat S_t+b_i\big)\,dX^i_t .
$$
Its universal-approximation guarantee is over *path functionals* (Johnson–Lindenstrauss applied to signature universality). The note's reservoir is driven by an **exogenous Brownian motion** $W$, with no price channel. It is therefore **not** a randomized signature of the price; it is a *latent stochastic-volatility reservoir* / Echo State Network, and the signature-universality theorems do **not** transfer. This is a genuine misattribution, not just wording. Two clean resolutions:
- *Keep it latent* and invoke the correct theory: reservoir computing / Echo State Property and the universality of *fading-memory filters* (Grigoryeva–Ortega; Gonon–Ortega). But note even this requires an **input signal**; an autonomous noise-driven reservoir is a *generative* model, for which the relevant question is *which laws of $(V_t)$ it can generate*, a weaker and different notion than functional universality. Be precise about which statement is being claimed.
- *Make it a true randomized signature of PDV* by driving the reservoir with augmented **price-path** channels (time, log-price, lead-lag, running averages); then genuine path-dependence and the signature-universality guarantees are recovered (§7).

State explicitly which route the paper takes. As written, no universal-approximation theorem is actually available to the model.

**2) Random-features identifiability and seed variance.** With $A,B,C$ random-but-fixed and only $\{w,\beta,\rho,\eta\}$ trained, this is a *random-features* model: the expressivity is that of the (fixed) random nonlinear feature space, and the calibration is conditional on the draw. The ML-specific reproducibility concern is therefore **variance across reservoir seeds**, distinct from Monte Carlo error. Report calibration RMSE distribution over $\ge20$ seeds; otherwise a referee cannot tell whether the fit reflects the architecture or a lucky draw. (The note also *designs* parts of $A$ — fractional spectrum, cascade — so it is a designed+random hybrid; say so.)

**3) The KC/RN estimator has a systematic log/Jensen bias — and a clean correction.** This is the review's T8 made precise.

The Nadaraya–Watson baseline $C_{\mathrm{KC}}$ consistently estimates the conditional arithmetic mean *given the univariate projection* $v(R)=f(w^\top R+\beta)$, i.e. $C_{\mathrm{KC}}(r)\to m_0(v(r)):=\mathbb{E}[Y\mid v(R)=v(r)]$. The residual regressed is $\log Y-\log C_{\mathrm{KC}}\to \log Y-\log m_0(v(R))$, whose conditional mean given $R=r$ is $\mathbb{E}[\log Y\mid R=r]-\log m_0(v(r))$. Therefore the ridge fit satisfies $\xi^\top\Phi(r)\to \mathbb{E}[\log Y\mid R=r]-\log m_0(v(r))$ and
$$
\widehat g(r)=C_{\mathrm{KC}}(r)\exp(\xi^\top\Phi(r))\ \longrightarrow\ \exp\!\big(\mathbb{E}[\log Y\mid R=r]\big)\ \le\ \mathbb{E}[Y\mid R=r]=\mathrm{VIX}_T^2(r),
$$
the inequality by Jensen. **The estimator targets the conditional *geometric* mean and is biased low by the conditional variance of $\log Y$.** For VIX, whose payoff and Vega are convex in variance, a downward variance bias is exactly the wrong direction (it flattens the call-side convexity the note is trying to capture). Two fixes:

- **Lognormal smearing (preferred — keeps variance stabilisation):** if $\log Y\mid R$ is approximately Gaussian with conditional variance $s^2(r)$, then $\mathbb{E}[Y\mid R]=\exp(\mathbb{E}[\log Y\mid R]+\tfrac12 s^2(r))$, so use
$$
\widehat g_{\mathrm{corr}}(r)=C_{\mathrm{KC}}(r)\exp\!\big(\xi^\top\Phi(r)+\tfrac12\,\widehat s^2(r)\big),
$$
with $\widehat s^2$ a (kernel or random-feature) estimate of the residual conditional variance. This is the Duan/Cox "smearing" correction; it is consistent for the arithmetic mean under the lognormal-residual assumption.
- **Multiplicative retargeting (assumption-free):** regress the *ratio* $Y/C_{\mathrm{KC}}$ rather than its log, so the conditional mean of the target is arithmetic; $\widehat g(r)=C_{\mathrm{KC}}(r)\cdot\frac{\sum_p K_r^{(p)}\,Y^{(p)}/C_{\mathrm{KC}}(R_T^{(p)})}{\sum_p K_r^{(p)}}\to \mathbb{E}[Y\mid R=r]$. Unbiased without distributional assumptions, at some cost in variance.

Additionally: the baseline and the residual are computed on the **same** paths (plug-in, not leave-one-out), which inflates finite-sample bias; use **leave-one-out** Nadaraya–Watson for $C_{\mathrm{KC}}$ at the training points. And the *fast in-calibration* random-network regressor (used for gradient tractability) should be checked against the KC/RN estimator for consistency — otherwise the surface used to *fit* and the surface used to *report* differ, which a referee will notice.

**4) No dynamic test.** The reference the note builds on (Abi Jaber–Gérard, "Pricing *and Hedging*") sets the bar: the selling point is *realistic dynamics*, which is proved not by static smile fits but by (a) out-of-sample *temporal* generalisation (calibrate on $t_0$, price/hedge on $t_0+\delta$) and (b) **hedging P&L**. The model already delivers pathwise Greeks, so a delta–vega(–vanna) hedging backtest, and a deep-hedging comparison, are low-marginal-cost and high-value. As stands the empirics are entirely in-sample cross-sectional.

**5) Five architectures, one used.** Only the Unified ($N=24$) is benchmarked. Either run the **ablation** (Lightweight vs Blockwise vs Rough vs Cascade vs Unified; with/without fractional loading; with/without KC/RN; with/without $\eta$), which is the natural ML contribution and directly tests every design claim, or demote the unused four to a remark.

---

## 5. Consolidated correctness verdict

| Claim in the note | Status | Action |
|---|---|---|
| Positive variance via Softplus readout | Correct | Keep (Thm 2/A) |
| Leverage $\rho$ with all nodes; $\rho\approx-1$ | **Incorrect as stated** | Correlation vector / variance-gradient direction (§3.1) |
| "Exact SDE integration" | Overstated | Exponential-Euler, strong order $1/2$, $A$-stable (§3.3) |
| "Rough fractional asymptotics" (true $H<1/2$) | **False for finite $N$** | Finite-scale roughness + continuum limit (§3.2, §4.1.1) |
| Fractional loading $\kappa^{1/2-H}$ | Correct & principled | Promote: log-grid quadrature of $\mu_H$ (§3.5) |
| VIX-futures exactly matched by $\eta$ | One window only | Coupled nonlinear system; log-strip caveat (§3.4) |
| "Arbitrage-free VIX options" | Unjustified | Dynamic consistency + separate static checks (§3.4, §4.1.4) |
| KC/RN positive | Correct | Keep (Thm 7) |
| KC/RN estimates $\mathbb{E}[Y\mid R]$ | **Biased (geometric mean)** | Smearing or multiplicative retarget (§4.2.3) |
| Reproduces Zumbach | Correct empirically | Explain mechanism: leverage-driven, $\propto\rho$ (§4.1.2) |
| "Randomized signature" of PDV | **Misattributed** | Latent SV reservoir, or drive with price path (§4.2.1) |
| Martingale property of $S$ | Architecture-dependent | Thm A (bounded) vs Prop B (Unified) (§4.1.3) |

The arithmetic and figure numbers internal to the note are self-consistent (slope $0.4135\Rightarrow H=0.207$; skew slope $-0.211\Rightarrow H=0.289$); the *inconsistency between* the two $H$ estimates is itself diagnostic and correct to report.

---

## 6. The corrected mathematical core to build the paper around

I would frame the contribution as five theorems. T1–T5 below are the review's, corrected; D is new (and the linchpin connecting the linear theory to the actual nonlinear model); A/B (§4.1.3) and the Zumbach mechanism (§4.1.2) round it out.

1. **Admissible leverage (T1, corrected §3.1).** Existence of a leverage Brownian structure iff $\|\varrho\|\le1$; constant-correlation $\Rightarrow|\rho|\le N^{-1/2}$; variance-gradient direction gives an always-admissible scalar $\rho$.
2. **Well-posedness + martingality split (T2 → Theorem A / Proposition B).** Strong existence/uniqueness, positivity; **unconditional** true martingale for bounded diffusions; explicit sufficient conditions (or diffusion capping) for the Unified architecture.
3. **Semimartingale infinitesimal scaling (T3).** $H=1/2$ for every finite $N$; roughness is a finite-scale/continuum-limit phenomenon. Corroborated by the model's own $m_2$-vs-skew $H$ discrepancy and SSR$\to2$.
4. **Rough-kernel approximation (T4, corrected §4.1.1).** Log-grid OU mixtures approximate $K_H$ via $\mu_H$; *covariance-level* for independent-noise architectures, *pathwise $L^2$* for a shared-noise linear variant, with the Itô-isometry rate $\sup_{t\le T}\mathbb{E}|X_t-X_t^N|^2\le\int_0^T|K_H-K_N|^2$.
5. **Exponential integrator (T5, reframed §3.3).** Exact in the linear drift, $A$-stable for stiff $\kappa$, exact invariant Gaussian; strong order $1/2$ in the frozen diffusion.

> **Theorem D (propagation of the kernel approximation through the nonlinear readout — new).** Let $X^N\to X$ in the sense of Theorem 4 (covariance, resp. pathwise $L^2$), and let the variance be $V^N_t=\eta(t)f(X^N_t+\beta)$, $V_t=\eta(t)f(X_t+\beta)$ with $f$ globally Lipschitz (Softplus, or capped Softplus). Then for every $T$, $\sup_{t\le T}\mathbb{E}|V^N_t-V_t|^2\le \eta_{\max}^2\,\mathrm{Lip}(f)^2\,\sup_{t\le T}\mathbb{E}|X^N_t-X_t|^2\to0$; and if option payoffs are Lipschitz in the variance path (true for variance swaps, and for VIX under the bounded-diffusion regime), the corresponding price errors are $O(\sup_t\mathbb{E}|X^N_t-X_t|)$. *Proof.* Lipschitz $f$ and Cauchy–Schwarz for the variance bound; for prices, Lipschitz payoff + the variance bound, with a Grönwall step for $S$ in the multiplicative case. $\square$
>
> Theorem D is what licenses the chain *"log-grid weights $\Rightarrow$ kernel $\Rightarrow$ variance $\Rightarrow$ prices"* for the *trainable nonlinear* model, not merely the Gaussian skeleton. It is the natural bridge the review did not provide.

**Title.** Either of the review's suggestions works; I prefer *"Randomized Markovian Reservoirs for Path-Dependent Volatility: Lifted Rough Kernels, Admissible Leverage, and Positive Joint SPX/VIX Calibration."* Avoid "signatures" in the title unless the price-driven version (§7) is adopted.

**Journal fit.** I concur with the review's ranking. **SIFIN** is the right primary target *after* the rewrite (it explicitly covers rigorous financial mathematics and computational implementation). **Mathematical Finance / Finance & Stochastics** would demand the joint no-arbitrage theory (§4.1.4) and the continuum limit (§7) — viable but a longer road. **Quantitative Finance** is the natural home if the empirical/practitioner angle (joint calibration speed, hedging) leads. **Neural Networks** only if the KC/RN estimator + reservoir-learning benchmarks become the *centre* and the model is benchmarked against neural-SDE / DeepONet / LSTM / signature baselines; given that the genuine novelty is mathematical-finance, SIFIN is the more defensible claim.

---

## 7. Future developments and their mathematical consequences

I order these by mathematical payoff. The first three are, in my view, what would turn the paper from "a good calibration engine, made rigorous" into "a new model class."

**(I) Drive the reservoir with the augmented price path — recover genuine PDV *and* universality.**
Replace the autonomous $dR_t=AR_t\,dt+\Sigma(R_t)\,dW_t$ by a *signal-driven* reservoir
$$
dR_t=\sigma\!\big(A R_t+b\big)\,d\widehat X_t,\qquad
\widehat X_t=\big(t,\ \log S_t,\ \text{lead-lag}(\log S)_t,\ \overline{\mathrm{RV}}_t,\ \dots\big),
$$
i.e. a **randomized signature of the price path**. *Mathematical consequences:* (a) $V_t$ becomes a genuine functional of $\{S_u:u\le t\}$ — true path-dependent volatility, not latent SV with leverage; (b) the Cuchiero et al. universal-approximation theorem now *applies*, so one can state and prove that the model approximates any continuous PDV functional as $N\to\infty$ (with high probability over the random projection); (c) the leverage is no longer a free parameter but is *induced* by the shared $\log S$ channel — eliminating the §3.1 pathology by construction. The cost is the loss of the closed exponential-OU update (the drift is now nonlinear in $X$); one trades it for rough-path-stable numerics (point IV).

**(II) The $K=S+A$ decomposition as the design principle — and the Zumbach effect as an *area* phenomenon.**
The reservoir's generator splits into a symmetric (metric) part $S$ and an antisymmetric (bivector/area) part $A$. Two precise correspondences emerge, and they are the right way to *parametrise* the model rather than leave it to a random draw:
- The **symmetric part** controls the *size* of variance moves and hence the realized-variance / roughness layer. Constraining its spectrum to the log-grid quadrature weights $\kappa_j^{1/2-H}$ (Theorem 4) bakes the target $H$ into the metric by construction.
- The **antisymmetric part** controls *rotation/orientation* and hence time-reversal asymmetry. By §4.1.2, $\mathcal Z\propto\rho\times(\text{asymmetric memory transmission})$; in signature language, time-irreversibility lives in the **Lévy area** between price and time (and between price and its running average). So the Zumbach effect is, structurally, a *second-level antisymmetric signature coefficient*. *Mathematical consequence:* a geometric-algebra parametrisation in which (i) the metric eigenvalues fix roughness, and (ii) a single bivector orientation fixes $\mathrm{sign}(\mathcal Z)=\mathrm{sign}(\rho)$ — a model where roughness and Zumbach asymmetry are *separately and provably* controlled, rather than emergent. This is the natural fusion of the lifted-rough-vol theory with geometric deep learning, and it is, to my knowledge, unexplored.

**(III) Signature/expected-signature VIX — a bias-free, closed-form conditional expectation.**
Replace KC/RN entirely. If $V_t$ is a linear functional of the (randomized) signature of $R$, then the conditional forward variance $\mathbb{E}_T[\tfrac1\tau\int_T^{T+\tau}V_s\,ds]$ becomes a **linear functional of the time-$T$ expected signature** of the reservoir's future, computable in closed form (signature-payoff calculus; Lyons–Nejad–Perez-Arribas; Bayer et al.). *Mathematical consequences:* (a) the §4.2.3 Jensen bias vanishes — the target is the arithmetic conditional mean by construction; (b) VIX prices and their Greeks become differentiable closed-form functionals, removing the regression noise the note works hard to suppress; (c) it unifies SPX and VIX under one signature-linear pricing operator, which is the cleanest route to the joint no-arbitrage statement of §4.1.4.

**(IV) Rough-path numerics and the genuinely rough regime.**
The continuum limit ($N\to\infty$, point V) lands in $H<1/2$, where Itô calculus and the frozen-diffusion error analysis (§3.3) break down. Use the Itô–Lyons continuity of the solution map in rough-path metric to obtain **pathwise** (not merely $L^2$) error bounds for the exponential-Euler scheme, and to define and simulate the limiting low-regularity dynamics rigorously. *Mathematical consequence:* a numerical scheme with provable pathwise convergence uniformly in the stiffness, valid across the whole $H\in(0,\tfrac12]$ range — the rigorous version of the note's stability claim, and the right tool for the rough limit.

**(V) The nonlinear continuum (infinite-reservoir) limit — a *nonlinear rough volatility* model.**
Take $N\to\infty$ with the log-grid quadrature and prove convergence of the *nonlinear* reservoir to a stochastic Volterra equation with fractional kernel,
$$
V_t=\xi_0(t)+\int_0^t K_H(t-s)\,\Phi(V_s)\,dW_s\ \ (\text{schematically}),
$$
i.e. a nonlinear/rough-Bergomi-type limit. *Mathematical consequences:* (a) genuine roughness $H<\tfrac12$ as the limit object — making the note's claim *true* in the right asymptotic; (b) the well-posedness theory becomes a nonlinear stochastic Volterra problem (Abi Jaber–Larsson–Pulido; affine Volterra processes for tractable subclasses), which is open/hard for general $\Phi$ and is itself a publishable theorem; (c) a quantitative rate $\sup_t\mathbb{E}|V^N_t-V_t|^2=O(\text{quadrature error})$ via Theorem D plus the Volterra-approximation rate (geometric node placement can give exponential rates in the number of distinct scales). This is the natural sequel paper.

**(VI) Ergodicity, stationary tails, and arbitrage-free wings.**
Prove geometric ergodicity for the bounded-diffusion architectures (Foster–Lyapunov; the stable $A$ and bounded $\Sigma$ make this routine) and characterise the heavy-tailed stationary law of the Unified architecture (Kesten-type tail index as a function of vol-of-vol vs. mean-reversion). *Mathematical consequence:* the stationary tail index of $w^\top R$ pins down the *wing slopes* of the implied-vol surface through Lee's moment formula, giving an explicit, checkable **no-arbitrage constraint on the wings** (and an explanation of why the uncapped Unified can over-steepen wings precisely when Proposition B's martingality fails). This closes the loop between the ML design choice (bounded vs. unbounded activation) and a hard arbitrage property.

**(VII) Dynamic hedging and model risk.**
With pathwise Greeks already available, develop the hedging theory: a hedging-error bound under the calibrated model, a delta–vega–vanna backtest, and a deep-hedging comparison that uses the model as a market simulator. *Mathematical consequence:* a quantitative statement of *what the realistic dynamics buy you* (reduced hedging variance vs. Black–Scholes / Heston / classical PDV), which is the empirical claim a referee on the Abi Jaber–Gérard lineage will actually want, and the most direct evidence that the reservoir's Zumbach/SSR/roughness features are economically meaningful rather than decorative.

---

### Closing

The note's core is publishable; its present prose oversells (exact integration, true roughness, arbitrage-freeness, randomized signatures) and under-proves. The first review correctly identifies the four load-bearing problems and supplies a sound theorem skeleton. The decisive additions are: position the model as a **nonlinear, trainable Markovian lift of rough volatility** (fixing the roughness claim and yielding Theorem 4 + the new Theorem D); **correct the KC/RN Jensen bias**; **split martingality** into the clean bounded case (Theorem A) and the delicate Unified case (Proposition B); **explain the Zumbach effect** as a leverage-driven, antisymmetric/area phenomenon; and either **stop calling it a signature** or **drive it with the price path** to earn that name and its universality. Build the SIFIN version around T1–T5(corrected) + A/B + D; develop directions (I)–(III) for the sequel, where the genuinely new mathematics — geometric ($K=S+A$) parametrisation of roughness vs. asymmetry, signature-linear bias-free VIX, and the nonlinear continuum limit — lives.
