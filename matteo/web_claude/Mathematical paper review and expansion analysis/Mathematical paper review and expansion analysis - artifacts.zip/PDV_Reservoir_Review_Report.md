# Mathematical Review Report

**Subject:** *Mathematical Formulations of Path-Dependent Volatility via Randomized Signatures and Reservoir Computing* (A. Pallavicini, 29 May 2026), together with its first review (*Paper Review and Insights*, 30 May 2026).

**Scope of this report.** A rigorous audit of mathematical correctness, an assessment of which claims in the note and in the first review hold up, the weak points and improvable aspects from both a *mathematical-finance* and a *machine-learning* angle, a refined view of the selling point and target venue, an actionable revision checklist, and a closing section on future developments with their mathematical consequences.

---

## 0. Verdict in one paragraph

The note contains a genuinely good idea — a finite-dimensional, trainable, Markovian reservoir whose positive readout is the instantaneous variance, used as a *single* engine for joint SPX/VIX calibration, VIX conditional-expectation regression, and the standard stylized-fact diagnostics. The first review correctly identifies the four most visible defects (the leverage specification, the "true roughness" overclaim, the "exact integration" overclaim, and the VIX auto-calibration), and its proposed Theorems 1, 3, 5, 6, 7 are essentially correct. However, the review's strongest proposed theorem (Theorem 4, the rough-kernel approximation) is stated for a **different model than the one in the note**, its Theorem 2 is too glib on the **martingale property** of the discounted asset, and several deeper issues are missed entirely: the construction is **not a path-signature / endogenous-PDV model** in the sense it claims; the **roughness mechanism** is a covariance superposition, not a kernel quadrature; the **Unified (softplus) architecture** is the one configuration where well-posedness of *prices* (true-martingale property and reservoir ergodicity) is genuinely at risk; and the empirical roughness diagnostics are **internally inconsistent** ($H\approx 0.21$ from variance scaling vs. $H\approx 0.29$ from skew decay). As written it is a strong internal technical note, not a submission-ready mathematical paper. With the corrections below it is a credible SIFIN/Quantitative Finance paper; the most novel standalone morsel (the positive VIX conditional-expectation estimator, properly reformulated) could anchor a more ML-oriented paper.

---

## 1. What is mathematically sound (so it survives the rewrite)

To keep the critique balanced, the following are correct and worth promoting rather than cutting:

- **The exponential OU update is a sound scheme for stiff systems.** Solving the linear drift exactly and using the closed-form conditional variance $\frac{1-e^{-2\kappa\Delta}}{2\kappa}$ gives an A-stable integrator that does *not* suffer the explosive/oscillatory behaviour of explicit Euler–Maruyama when $\kappa\Delta>2$. The stationary-variance preservation (review Thm 5) is correct and worth stating as a proposition. The numerical claim is real; only the word "exact" is wrong (see §2.3).
- **Positivity of the variance readout and of the KC/RN estimator** (review Thm 7) is correct and not cosmetic — negative conditional-variance estimates are the standard failure mode of polynomial regression for VIX, and a positivity guarantee is a genuine advantage.
- **Pathwise sensitivities for vanilla SPX payoffs are valid.** For Lipschitz payoffs and a differentiable SDE flow, pathwise (Broadie–Glasserman) Greeks are correct; the BFGS calibration on these gradients is well-founded *for the readout/leverage parameters* (the auto-calibration multiplier needs the extra argument in §4.4).
- **The architecture taxonomy and the fractional-loading idea are well-motivated.** Log-spaced mean-reversion speeds with a $\kappa^{1/2-H}$ loading is the *right* heuristic; it just needs to be attached to the correct approximation theory (see §3.3).
- **The diagnostic battery is the right set of things to check** (smiles, VIX futures term structure, $m_2$ roughness scaling, Zumbach asymmetry, SSR, skew power-law). The problem is rigour and internal consistency, not coverage.

---

## 2. Audit of the first review

The four critical issues raised by the first review are **all correct**. I record them briefly and then point out where its *proposed theorems* are not yet rigorous.

### 2.1 Leverage specification (review §2.1, Thm 1) — correct and essential

Requiring $d\langle Z^S,W^{(j)}\rangle_t=\rho\,dt$ for *all* $j$, with $W$ an $N$-dimensional standard BM, forces the cross-covariance matrix
$$
C=\begin{pmatrix}1 & \rho\mathbf 1^\top\\ \rho\mathbf 1 & I_N\end{pmatrix}\succeq 0
\;\Longleftrightarrow\; 1-\rho^2\mathbf 1^\top I_N^{-1}\mathbf 1=1-N\rho^2\ge 0
\;\Longleftrightarrow\; |\rho|\le \tfrac{1}{\sqrt N}.
$$
For $N=24$ this caps $|\rho|\le 0.204$, so the reported $\rho\approx-1.0$ is **infeasible**. The fix — a leverage *vector* $\varrho\in\mathbb R^N$, $\|\varrho\|\le 1$, with $dZ^S_t=\varrho^\top dW_t+\sqrt{1-\|\varrho\|^2}\,dB_t$ and $B\perp W$ — is correct, and Theorem 1 (Schur complement) is a clean, correct result. **This is the single most important fix before any submission.** But it does not go far enough; see §3.2.

### 2.2 Finite-dimensional Itô reservoir cannot be infinitesimally rough (review §2.2, Thm 3) — correct

With $V_t=g(R_t)$, $g\in C^2$, and $dR=b(R)\,dt+\Sigma(R)\,dW$,
$$
\lim_{\Delta\downarrow 0}\frac1\Delta\,\mathbb E\!\left[(V_{t+\Delta}-V_t)^2\mid\mathcal F_t\right]=\big\|\Sigma(R_t)^\top\nabla g(R_t)\big\|^2,
$$
so $m_2(\Delta)\sim C_t\Delta$ and the true infinitesimal Hurst exponent is $H=\tfrac12$ wherever the diffusion coefficient of $V$ does not vanish. The "rough fractional asymptotics" claim must be reframed as a **finite-scale (pre-asymptotic) effect** or as an **infinite-reservoir limit**. Theorem 3 is correct. This is standard in the Markovian-approximation-of-rough-volatility literature (Carmona–Coutin–Montseny; Abi Jaber–El Euch; Bayer–Breneis; Harms), which the note should cite explicitly.

### 2.3 "Exact integration" needs qualification (review §2.3) — correct

The stochastic convolution $\int_t^{t+\Delta}e^{A(t+\Delta-s)}\Sigma(R_s)\,dW_s$ is Gaussian conditional on $\mathcal F_t$ **only if $\Sigma$ is frozen/deterministic over the step**. For state-dependent $\Sigma(R_t)$ it is not. The scheme is an *exponential-Euler / frozen-diffusion* integrator: exact for the linear drift, left-point-frozen for the diffusion, hence strong order $\tfrac12$ generically. The phrase to use is "exponential integrator, exact for the OU drift, with frozen-coefficient diffusion." The "no volatility collapse" benefit is **A-stability of the stiff drift**, not exactness.

### 2.4 VIX auto-calibration is a nonlinear fixed point (review §2.4, Thm 6) — correct, and worth sharpening

The futures contract is $F(T)=\mathbb E^{\mathbb Q}[\mathrm{VIX}_T]$ with $\mathrm{VIX}_T=\sqrt{\mathbb E_T[\tfrac1\tau\int_T^{T+\tau}V_s\,ds]}$. A multiplier $\eta$ is linear at the *variance* level but the futures price involves the **concave** map $x\mapsto\sqrt x$. Theorem 6 (one window, constant $\eta=\lambda$ on $[T,T+\tau]$) is correct because $\sqrt\lambda$ factors through the square root: $\mathbb E[\mathrm{VIX}_T(\lambda)]=\sqrt\lambda\,\mathbb E[\mathrm{VIX}_T(1)]$. The genuine difficulty is the **term structure with overlapping 30-day windows**, where a single piecewise-constant $\eta$ piece enters several futures and the matching becomes a coupled nonlinear system $g(\eta)=F^{\mathrm{mkt}}$.

*Sharper framing to add.* By Jensen, $\mathbb E[\mathrm{VIX}_T]=\mathbb E[\sqrt{X_T}]\le\sqrt{\mathbb E[X_T]}$, $X_T=\tfrac1\tau\int_T^{T+\tau}V_s\,ds$, so matching the *forward-variance curve* $\xi_t(u)=\mathbb E_t[V_u]$ (linear, hence matching variance swaps exactly) does **not** match VIX futures: the gap is the convexity adjustment, which is itself a functional of the model vol-of-variance. This is precisely why $\eta$ couples to the model's own dynamics and is a fixed point, not a closed form. Existence/uniqueness follows from monotonicity ($\mathrm{VIX}_{T_i}$ is increasing in each $\eta$-piece it touches, since $V\ge 0$) plus invertibility of the system's Jacobian — this should be *stated and proven*, not asserted.

### 2.5 Where the review's proposed theorems are not yet rigorous

- **Theorem 2 (well-posedness) is fine for existence but glib on martingality.** For the tanh-based architectures $\Sigma$ is bounded and globally Lipschitz, so existence/uniqueness/non-explosion and the true-martingale property are routine (Novikov is trivially satisfied because $R$ is sub-Gaussian and $V=f(w^\top R)$ has at most linear growth in a sub-Gaussian state). For the **Unified architecture the diffusion $\Sigma(r)=D\,\mathrm{diag}(\log(1+e^{Cr+b}))$ has linear growth**, the multiplicative noise can produce heavy (up to power-law) tails in $R$, $V$ is asymptotically linear in $w^\top R$, and **Novikov generically fails** ($\mathbb E[\exp(\tfrac12\int_0^TV_s\,ds)]$ need not be finite — recall that even a log-normal $V$ has no finite exponential moment). "Martingality may need an explicit condition" is an understatement: it is a genuine, possibly negative result. See §3.4.
- **Theorem 4 is stated for the wrong model.** Its driving process $X_t=\int_0^tK_H(t-s)\,dB_s$ uses a *single, common* Brownian $B$; realizing $X^N$ as a reservoir requires OU factors that **share the same Brownian**, $dY^j=-\kappa_jY^j\,dt+dB$. The note's reservoirs all use a **diagonal** $\Sigma$, i.e. **independent** Brownians $dW^j$ per node. The theorem therefore does not justify the note's roughness. See §3.3.
- **Theorem 4's bound conflates $\sup\mathbb E$ with $\mathbb E\sup$.** The proof correctly gives, by Itô isometry, $\mathbb E[|X_t-X_t^N|^2]\le\int_0^T|K_H-K_N|^2$ for each fixed $t$, i.e. $\sup_{t\le T}\mathbb E[\cdot]\le\int_0^T|K_H-K_N|^2$. The *stated* conclusion $\mathbb E[\sup_{t\le T}|\cdot|^2]\le\int_0^T|K_H-K_N|^2$ is strictly stronger and is **not** delivered by that computation: $X-X^N$ is a Volterra process, not a martingale in $t$, so Doob does not apply directly. State it as $\sup_t\mathbb E$, or supply a Garsia–Rodemich–Rumsey / Kolmogorov-type argument for the supremum.
- **Theorem 8 identifies the right problem but the wrong fix is easy to write.** The log-residual estimator targets the *geometric-mean* conditional expectation, not the arithmetic one. See §4.2 for the precise statement and a principled (GLM) correction.

---

## 3. Foundational issues the review missed (mathematical-finance)

These are, in my view, the points that most affect whether the paper can be sold as a *signature / path-dependent-volatility* contribution rather than a generic Markovian stochastic-volatility model.

### 3.1 The construction is not a path-signature model, and not endogenous PDV

The note frames the reservoir as a "randomized signature" of the driving paths and, in §5.1, interprets $\rho\approx-1$ as agreement with **pure endogenous PDV à la Guyon–Lekeufack**, "where volatility is strictly driven by the historical price path." These two framings are mutually inconsistent with the actual dynamics.

A *randomized signature* of a path $X$ is the solution of a (random, linear) controlled differential equation **driven by $X$ itself**,
$$
dR_t=\Big(AR_t+\textstyle\sum_i B_i R_t\Big)\,dX^i_t,
$$
and a *genuine* PDV volatility is a deterministic functional of the price path, $V_t=F(\{S_u\}_{u\le t})$, with **no independent volatility noise**. The note's reservoir is instead driven by **exogenous Brownians $W$**, with the asset coupled only through a scalar leverage. This is the Abi Jaber–Gérard "signature of an independent background process" tradition, **not** the Guyon endogenous tradition; the note tries to claim the endogeneity benefit while using an independent-reservoir construction. With $V_t=f(w^\top R_t)$ and $R$ driven by $W$, $V$ is a functional of $W$, *not* of the price path, except to the extent that $W$ and $Z^S$ are correlated.

### 3.2 $\rho=-1$ cannot mean "endogenous PDV" for $N>1$ — a stronger statement than the review's

Even after the review's vector fix, take the extremal admissible case $\|\varrho\|=1$, i.e. $Z^S=u^\top W$ with $u=\varrho/\|\varrho\|$. The asset is then driven by a **single one-dimensional projection** $u^\top W$, while the reservoir is driven by **all $N$ components of $W$**. The variance $V_t=f(w^\top R_t)$ therefore depends on the $N-1$ directions of $W$ orthogonal to $u$, which are **independent of the asset's noise**. Hence $V$ is *not* a functional of the $S$-path, and the model is **not** endogenous PDV, for any value of the scalar leverage. Endogeneity in this architecture would require either $N=1$ (degenerate) or the reservoir to be driven *only* by $u^\top W=Z^S$.

There is a second, related subtlety the report should make explicit: with a single scalar $\rho$, the *instantaneous spot–variance correlation* is **state-dependent**,
$$
\mathrm{corr}_t\!\left(\frac{dS_t}{S_t},dV_t\right)=\frac{\varrho^\top\Sigma(R_t)^\top\nabla g(R_t)}{\|\Sigma(R_t)^\top\nabla g(R_t)\|},
$$
so the calibrated "$\rho\approx-1$" is at best an *effective/aggregate* leverage and equals $-1$ only if $\varrho$ stays aligned with $\Sigma^\top\nabla g$ persistently — a non-trivial geometric condition that is generically false. The economic interpretation in §5.1 should be rewritten accordingly: "near-maximal aggregate leverage along the reservoir direction $u$," not "pure endogenous PDV."

**Consequence for the paper.** Either (i) keep the exogenous-reservoir framing and drop the endogenous-PDV claim (then it is an honest, well-posed Markovian SV model with leverage), or (ii) commit to a *price-driven* reservoir to earn the PDV interpretation — which is a substantial and interesting change with real mathematical consequences (see §9.1).

### 3.3 The roughness mechanism: covariance superposition, not kernel quadrature

This is the technical heart of the matter and the place where the note, the review, and the design choices do not line up.

Because every architecture uses a **diagonal** $\Sigma$, the readout is a sum of integrals against **independent** Brownians:
$$
w^\top R_t=\sum_{j=1}^N w_j\int_0^t e^{-\kappa_j(t-s)}\sigma_j(R_s)\,dW^j_s .
$$
This is **not** a single Volterra integral $\int_0^tK_N(t-s)\,dB_s$ against a common Brownian. The two constructions produce different objects:

- **Common-Brownian superposition (kernel quadrature).** $Y^j_t=\int_0^t e^{-\kappa_j(t-s)}\,dB_s$ with shared $B$ gives $X_t^N=\sum_j a_j Y^j_t=\int_0^t K_N(t-s)\,dB_s$, $K_N(u)=\sum_j a_j e^{-\kappa_j u}$. Then $K_N\to K_H$ in $L^2$ produces a **pathwise $L^2$ approximation** of Riemann–Liouville fBM. This is the Abi Jaber–El Euch route, and it is what the review's Theorem 4 actually proves.
- **Independent-Brownian superposition (covariance).** With independent $W^j$, the *autocovariance* of $w^\top R$ is a sum of exponentials,
$$
\mathrm{Cov}(w^\top R_t,\,w^\top R_{t+h})=\sum_j w_j^2\,\frac{D_{jj}^2\,\bar\sigma_j^2}{2\kappa_j}\,e^{-\kappa_j h},
$$
which can approximate a power-law autocovariance (the Barndorff-Nielsen "superposition of OU = long memory" mechanism), but the process is **not** a pathwise approximation of fBM — only its second-order structure is rough-like.

The note's fractional loading $D_{jj}\propto\kappa_j^{1/2-H}$ is exactly the **common-Brownian quadrature weight**. Indeed, from the Laplace representation
$$
K_H(t)=\int_0^\infty e^{-\kappa t}\,\mu_H(d\kappa),\qquad \mu_H(d\kappa)=\frac{\kappa^{-H-1/2}}{\Gamma(\tfrac12-H)\,\Gamma(\tfrac12+H)}\,d\kappa,
$$
a logarithmic grid ($d\kappa\approx\kappa\,d\log\kappa$) gives mass per node $\propto\kappa^{1/2-H}$, hence $a_j\propto\kappa_j^{1/2-H}$. But in the note this is applied as a **diffusion loading on independent Brownians**, where its effect on the stationary variance is $\propto D_{jj}^2/\kappa_j\propto\kappa_j^{-2H}$ — a *different* role (it tilts the covariance toward slow nodes), not a kernel quadrature.

**Net assessment.** The empirical roughness in Figure 4 is therefore a numerical/covariance artifact of the chosen grid and loading, *not* something either the note or the review has justified. To repair this rigorously the paper must choose one of:
1. **Switch the linear part to a common (or low-rank) Brownian.** Then the review's Theorem 4 applies verbatim and one earns *pathwise* rough approximation with convergence rates (the optimal-quadrature/Gaussian-quadrature rates of Bayer–Breneis; geometric in $N$ for well-placed nodes). This is the cleanest route and I recommend it.
2. **Keep independent Brownians and prove a covariance-level theorem.** State and prove $\mathrm{Cov}_N(h)\to C_H(h)$ as $N\to\infty$ (a fractional-Gaussian-noise autocovariance), explicitly labelling the result as a *second-order / in-distribution* approximation. Weaker, but honest for the current model.

In either case there is a further, non-trivial step the review omits: the variance is a **nonlinear** readout of a **multiplicatively** driven state, $V_t=f(w^\top R_t)$ with state-dependent $\Sigma$. The linear kernel/covariance approximation governs $w^\top R$; transferring roughness through $f$ and the multiplicative noise to $V$ requires a perturbative argument (locally $V_t-V_0\approx f'(\cdot)\,w^\top(R_t-R_0)$ with frozen $\Sigma$) plus control of the nonlinear remainder. For large vol-of-vol the nonlinearity reshapes the scaling. A clean statement here would materially strengthen the paper.

### 3.4 Martingality of the discounted asset — the Unified architecture is the dangerous one

Prices are only well-defined if $S$ is a true $\mathbb Q$-martingale; otherwise put–call parity fails and the "arbitrage-free" claim is void. As noted in §2.5:

- **tanh architectures (Lightweight, Blockwise, Rough, Cascade):** $\Sigma$ bounded $\Rightarrow R$ sub-Gaussian $\Rightarrow V=f(w^\top R)$ at most linear in a sub-Gaussian state $\Rightarrow \mathbb E[\exp(\tfrac12\int_0^T V_s\,ds)]<\infty$ (Novikov) $\Rightarrow S$ is a true martingale. Safe.
- **Unified architecture (softplus diffusion):** linear-growth multiplicative noise can give $R$ heavy/log-normal-type tails, $V$ asymptotically linear in $w^\top R$, and **Novikov generically fails**. Whether $\mathbb E[S_T]=S_0$ then holds is a genuine, model-specific question that must be settled by a Sin / Lions–Musiela / Andersen–Piterbarg-type argument, and **the sign of the leverage is decisive**: as in Heston, non-positive correlation tends to *preserve* the martingale property while positive correlation can break it. Since the calibrated leverage is strongly negative, there is hope — but it must be proven, not assumed.

**Recommendation.** Either (a) prove a true-martingale theorem for the Unified architecture with an explicit admissible-parameter region (likely $\varrho\cdot(\text{vol-of-vol direction})\le 0$ plus a growth bound), or (b) use a **capped softplus** or bounded readout to guarantee martingality unconditionally, at minor cost to expressiveness. The "apex configuration" is precisely the one whose pricing well-posedness is least clear; this should be confronted head-on.

### 3.5 Ergodicity / Echo State Property is assumed, not proven

The Lightweight architecture sets $\nu_j\propto\sqrt{\kappa_j}$ "so the unconditional stationary variance is equalized across timescales," which presupposes a **stationary** reservoir. For a reservoir-computing model the Echo State Property (fading memory / unique stationary law) is essential and, with multiplicative noise, not automatic. A Lyapunov/Meyn–Tweedie drift condition with $\mathcal V(r)=|r|^2$ gives
$$
\mathcal L\,\mathcal V(r)=2\,r^\top A r+\operatorname{tr}\!\big(\Sigma\Sigma^\top(r)\big),
$$
and for $A=-\mathrm{diag}(\kappa)$ with the Unified softplus diffusion ($\operatorname{tr}\Sigma\Sigma^\top(r)\lesssim \|D C\|_F^2\,|r|^2$ at large $r$) one needs roughly
$$
2\kappa_{\min}\;>\;\lambda_{\max}\!\big(C^\top D^2 C\big)
$$
for $\mathcal L\mathcal V\le -c|r|^2+d$ outside a compact set, hence geometric ergodicity and finite stationary variance. This condition can **fail**: the slow nodes have weak mean reversion ($\kappa_{\min}=0.5$) while the fractional loading inflates $D$ on fast nodes ($D_{jj}\propto\kappa_j^{1/2-H}$, with $\kappa_{\max}=250$). The paper should state and check a drift condition; it is the same growth-vs-mean-reversion balance that governs the martingale property in §3.4, so the two analyses can be unified.

---

## 4. VIX, calibration, and gradients

### 4.1 VIX auto-calibration

See §2.4 — the multiplier is a nonlinear fixed point, not a deterministic closed form, once the VIX windows overlap; existence/uniqueness needs monotonicity + Jacobian invertibility.

### 4.2 KC/RN estimates the geometric-mean conditional expectation — and the principled fix

This is the most consequential machine-learning point. With $C_{KC}(r)=\hat m_0(v(r))$ the Nadaraya–Watson estimator on the *scalar* spot variance $v(r)$, the residual (Eq. 20) is
$$
E^{(p)}_{\log}=\log Y^{(p)}-\log C_{KC}\!\big(R^{(p)}_T\big),
$$
and the random-feature ridge fit converges to $\hat\xi^\top\Phi(r)\to\mathbb E[\log Y\mid R=r]-\log C_{KC}(r)$ (the kernel baseline is a function of $R$ through $v$, hence deterministic given $R$). The final estimator (Eq. 22) therefore converges to
$$
g(r)=C_{KC}(r)\,e^{\hat\xi^\top\Phi(r)}\;\longrightarrow\;\exp\big(\mathbb E[\log Y\mid R=r]\big),
$$
i.e. the **conditional geometric mean** — the kernel baseline *cancels asymptotically*, so it is a pure control variate and does not remove the bias. But VIX pricing needs the **arithmetic** conditional expectation $\mathbb E[Y\mid R]=\mathbb E[\mathrm{VIX}_T^2\mid R]$, and by Jensen
$$
\exp\big(\mathbb E[\log Y\mid R]\big)\;\le\;\mathbb E[Y\mid R],
$$
with multiplicative gap $\exp\!\big(\tfrac12\operatorname{Var}(\log Y\mid R)\big)$ for log-normal-type $Y$. The KC/RN estimator therefore **systematically under-prices the conditional variance**, with a bias that grows precisely where the conditional vol-of-variance is largest — i.e. in the wings of the VIX smile, which is exactly the region the note claims to fit well.

**Principled fix (cleaner than the review's two options).** Keep the positive, low-dimensional baseline times a random-feature correction, but fit it as a **log-link generalized linear model** (gamma or quasi-Poisson deviance) rather than log-residual least squares:
$$
\log\mu(r)=\log C_{KC}(r)+\xi^\top\Phi(r),\qquad \hat\xi=\arg\min_\xi\sum_p \mathrm{Dev}\big(Y^{(p)},\mu(R^{(p)})\big).
$$
The first-order condition of a log-link GLM is $\sum_p\Phi(R^{(p)})\big(Y^{(p)}-\mu(R^{(p)})\big)=0$, so the fit targets the **arithmetic** conditional mean $\mathbb E[Y\mid R]$ while keeping $\mu>0$ by construction. This gives positivity *and* (asymptotic) unbiasedness for the pricing target, and it generalizes immediately to any nested-Monte-Carlo conditional expectation (XVA, American/Bermudan continuation values, nested risk). This single reformulation is, in my opinion, the most publishable idea in the note.

### 4.3 Train/test estimator mismatch

The note calibrates with a *fast* random-network regression but evaluates the displayed smiles with the *more sophisticated* KC/RN. Because the two estimators have different bias/variance (and, per §4.2, different probability limits), **the parameters are optimal for the in-sample estimator while the figures use a different one** — the displayed fit is not the fit that was optimized. A referee will object. Calibrate and evaluate with the *same* (ideally GLM-corrected, unbiased) estimator, or demonstrate empirically that the two agree on the calibration set.

### 4.4 Differentiating through the auto-calibration fixed point

The note claims "exact path-wise derivatives w.r.t. the multipliers $\eta(t)$" are folded into the gradient chain. Since $\eta$ is determined *implicitly* by the VIX-futures matching (a fixed point; §2.4), the sensitivity $\partial\eta/\partial\Theta$ is governed by the **implicit function theorem**: it exists and is given by $-J_\eta^{-1}J_\Theta$ provided the Jacobian $J_\eta=\partial g/\partial\eta$ of the matching system is invertible at the solution. For one window this is the scalar derivative of Theorem 6; for the overlapping-window term structure it is a genuine linear solve. The paper should (i) state the regularity (invertibility) hypothesis, and (ii) either use adjoint/implicit differentiation or unroll the fixed-point iteration with the corresponding bias controlled. As written, "fully integrated into the gradient chain" is plausible but unproven.

---

## 5. Machine-learning perspective

### 5.1 Reservoir universality vs. $N=24$ — expressiveness and identifiability

In the reservoir-computing philosophy the reservoir ($A,B/C,\kappa,D,\nu,c,b$) is **fixed/random** and only the readout and leverage $\Theta=\{w,\beta,\rho\}$ are trained — about $N+2=26$ free parameters, almost all in the linear map $w\in\mathbb R^N$. The bet is that a *random* nonlinear reservoir provides features rich enough that a *linear* readout fits the joint SPX/VIX surface. This is exactly the Cuchiero–Gonon–Grigoryeva–Ortega–Teichmann universality of randomized signatures / ESNs — but that universality is **asymptotic in $N$**, with approximation error decaying like $O(1/\sqrt N)$ (random-feature rate). $N=24$ is small for a universality argument, and the paper currently offers no error-vs-$N$ analysis. Two things are needed:
- an **approximation-rate statement**: how does calibration RMSE scale with $N$, and is $N=24$ on the plateau or still improving?
- an **identifiability / stability** discussion: is $w$ identified from the surface, and is the calibration well-posed (the inverse problem of vol calibration is classically ill-posed; ridge/Tikhonov on $w$ and stability estimates would be appropriate)?

### 5.2 Random-feature consistency — sharpening review Theorem 8

Theorem 8's "density of the feature span" is the right idea but under-specified. The rigorous version is a Rahimi–Recht / Rudi–Rosasco statement: if the target correction lies in the RKHS $\mathcal H$ of the random-feature kernel (arc-cosine kernel for ReLU-type features; Gaussian RKHS for random Fourier features), then with $m$ features and $n$ samples the ridge estimator achieves $\|\hat g-g\|_{L^2}=O_{\mathbb P}\!\big(n^{-1/2}+m^{-1/2}\big)$ under coordinated $\lambda_n\downarrow 0$. The two-stage estimator also has **two different rates**: the scalar Nadaraya–Watson baseline converges at the 1-D nonparametric rate (fine), while a full $N$-dimensional kernel would suffer the curse of dimensionality — which is exactly why the *scalar baseline + random-feature correction* design is sensible. Make this explicit; it is a selling point of the architecture if stated correctly. (And combine it with the GLM reformulation of §4.2, which changes the loss but not the random-feature approximation theory.)

### 5.3 KC/RN as positive conditional-expectation learning — the standalone ML contribution

Framed as "a positivity-preserving, variance-stabilized estimator of a conditional expectation via a low-dimensional sufficient statistic plus a random-feature correction, fitted with a log-link exponential-family loss," KC/RN is a clean and general method. For the *Neural Networks* venue this, not the calibration engine, is the core. It should be benchmarked against the obvious competitors for conditional expectations / nested MC: regress-later / regress-now polynomial schemes, deep BSDE / deep optimal stopping continuation-value networks, signature regression, and a plain MLP — on bias (especially the Jensen bias of §4.2), variance, positivity violations, and runtime.

### 5.4 What a *Neural Networks* submission would additionally require

Reframe the contribution as a *neural/reservoir learning method* and add ML benchmarks the note currently lacks entirely: comparisons to neural-SDE volatility, LSTM/transformer sequence models, DeepONet-style operator learning, signature models, and standard ESNs, on calibration accuracy, generalization (out-of-sample dates), and compute. Without these the note is a financial-mathematics paper wearing ML vocabulary.

---

## 6. Empirical / numerical rigour

### 6.1 The two Hurst estimates are mutually inconsistent — concrete evidence against "true roughness"

For a genuine single-$H$ rough model the Hurst exponent inferred from *variance roughness* and from *skew decay* must coincide: rough Bergomi has variance Hölder regularity $H$ **and** ATM skew $\sim\tau^{H-1/2}$. The note reports
- Figure 4: $m_2(\Delta)\sim\Delta^{2H}$ with slope $0.4135\Rightarrow H\approx 0.207$;
- Figure 7: skew $\sim\tau^{H-1/2}$ with slope $-0.211\Rightarrow H\approx 0.289$.

A ~40% discrepancy ($0.21$ vs $0.29$) is hard to reconcile with a single fractional parameter and is exactly what one expects from a **multi-scale / pre-asymptotic** mechanism rather than true roughness — independent corroboration of §2.2/§3.3. The paper should either reconcile the two (with error bars, and matched lag ranges) or, better, embrace the finite-scale story and report the *range of lags* over which each effective exponent holds, tying it to $[\,1/\kappa_{\max},\,1/\kappa_{\min}\,]$.

### 6.2 Zumbach: a diagonal reservoir is time-reversible, so the signal must (and barely does) come from leverage

The Lightweight/Unified architectures use a **diagonal** $A$. A stationary Ornstein–Uhlenbeck process is the canonical *time-reversible* diffusion, and reversibility is preserved under instantaneous functions of the state, so the variance process $V_t=f(w^\top R_t)$ alone has **no time-reversal asymmetry** — it cannot, by itself, generate a Zumbach effect. The reported $\mathcal Z(\Delta)$ must therefore arise *entirely* from the price–variance leverage coupling, and consistently with this its reported magnitude is $\sim 10^{-8}$ (Figure 5) — possibly too small to be economically meaningful. The **Cascade** architecture, with its upper-bidiagonal (non-normal, non-reversible) drift $A_{j,j+1}=\gamma\kappa_j$, is the structurally correct choice for time-reversal asymmetry, yet it is *not* the architecture used for the headline calibration. Recommendation: either use/benchmark Cascade for Zumbach and report the magnitude on an economically interpretable scale, or prove that the leverage-induced asymmetry of the diagonal model is sufficient. This connects to a genuinely novel theoretical question (§9.6): relate the *non-normality* of $A$ (e.g. $\|AA^\top-A^\top A\|$) to the sign and size of $\mathcal Z$.

### 6.3 SSR: fix the perturbation direction and reconcile $H$

Equation (24) perturbs the initial driver by $h\rho$, inheriting the scalar-leverage bug of §2.1/§3.2; under the corrected parametrization the shock must be along the leverage *vector* $\varrho$ (perturb $W_0\to W_0+h\varrho$). Separately, the note quotes the canonical rough-vol short-maturity limit $\mathrm{SSR}\to \tfrac32+H$ (De Marco and co-authors). I would not independently certify the exact constant, but the paper should: (i) state precisely which SSR (ATM-option vs variance-swap) is being compared to which theoretical limit, and (ii) check that the SSR-implied $H$ agrees with the two estimates of §6.1 — at present there are *three* potentially different effective Hurst values floating around. The note's careful distinction between the ATM-option SSR and the variance-swap SSR is good and worth keeping: the **VS SSR** (stickiness of the fair variance-swap strike $\sigma_{VS}=\sqrt{\mathbb E_0[\tfrac1T\int_0^T V_s\,ds]}$) strips the option-pricing convexity and is the cleaner object, so the comparison to the theoretical $\tfrac32+H$ limit should be made for the VS SSR, with the option SSR reported separately and not conflated with it.

### 6.4 The joint SPX/VIX fit is the crown jewel — and therefore needs the most evidence

Joint calibration of SPX and VIX is a famously hard problem: the steep, upward-sloping VIX-call smile and the short-dated SPX skew impose conflicting constraints, and for a *purely diffusive* model (no jumps, as here) fitting both simultaneously is non-trivial (cf. Guyon's joint-calibration program; De Marco). If the note genuinely achieves this in minutes, that is a strong, marketable result — *but* it is exactly the claim referees will probe hardest, so it must be backed by:
- numerical **error tables** (SPX IV RMSE by maturity/strike bucket; VIX future absolute errors; VIX option IV RMSE), not just overlay plots;
- **Monte-Carlo standard errors** and confidence bands on every diagnostic (currently absent);
- explicit **dataset date(s)**, the option-filtering rules, the rates/dividend treatment, the VIX-window interpolation, and the calibration weights $\omega$;
- **static no-arbitrage checks** (calendar and butterfly) on the fitted surfaces, reported separately from the dynamic-consistency claim. The note's phrase "arbitrage-free pricing of VIX options" should be softened to "dynamically consistent pricing within the calibrated model; static no-arbitrage verified numerically."

A purely diffusive model also has *no* mechanism for the very short-dated explosive SPX skew except enormous vol-of-vol; the paper should report how steep the short end actually fits and acknowledge the known limitation (this is also the motivation for the jump extension in §9.8).

### 6.5 Ablations the paper needs

The five architectures are presented but never *compared*. A serious empirical section requires ablations: Lightweight vs Blockwise vs Rough vs Cascade vs Unified on identical data; with/without fractional loading $D$; with/without KC/RN (and KC/RN vs the GLM version of §4.2); with/without the $\eta$ auto-calibration; and the error-vs-$N$ curve of §5.1. Without these, the choice of "Unified, $N=24$" for the headline result looks arbitrary.

---

## 7. Selling point, positioning, and venue

### 7.1 The defensible selling point

I largely agree with the first review's one-line pitch but would sharpen it. The novelty is *not* "a Markovian approximation of rough volatility" — that exists and is rigorous (Carmona–Coutin–Montseny; Abi Jaber–El Euch; Bayer–Breneis; Harms), and a referee in this area will know it cold. The defensible, distinctive contributions are:

1. **A single low-dimensional Markovian reservoir that *jointly* fits SPX + VIX futures + VIX options and simultaneously reproduces the finite-scale roughness, the Zumbach asymmetry, and the SSR** — with minutes-scale calibration and pathwise Greeks. The "one calibrated object, many stylized facts, fast" claim is the practitioner-facing selling point.
2. **A positivity-preserving, variance-stabilized conditional-expectation estimator for VIX** (KC/RN), which — once corrected to the GLM/log-link form of §4.2 — is a genuine and *transferable* methodological contribution (nested MC, XVA, American options). This is the ML-facing selling point.
3. **A clean nonlinear-readout reservoir framework** that interpolates the Abi Jaber–Gérard signature-volatility and the multifactor-Markovian-approximation literatures, with the fractional loading given a precise approximation-theoretic meaning (§3.3).

The honest framing — and the one most likely to survive refereeing — is therefore: *"a finite-dimensional, trainable, Markovian reservoir representation of stochastic volatility that approximates rough behaviour over market-relevant scales while retaining fast Monte-Carlo pricing, pathwise gradients, joint SPX/VIX calibration, and a positive VIX conditional-expectation estimator."* Note the deliberate retreat from "path-dependent/endogenous" to "stochastic volatility" unless the model is changed per §9.1.

### 7.2 Positioning against the literature (do not skip this)

The related-work section must explicitly situate the model against: (i) multifactor/Markovian approximations of rough volatility; (ii) Abi Jaber–Gérard signature volatility (the note's own ref [1]); (iii) Cuchiero et al. randomized signatures / reservoir computing (ref [6]); (iv) Guyon–Lekeufack PDV (ref [8]); (v) the Baschetti–Bormetti–Rossi deep-PDV calibration (ref [2]); and (vi) the joint SPX/VIX calibration literature. The contribution is the *combination* and the *speed*, not any single ingredient — say so.

### 7.3 Venue ranking (with my nuance on the review's)

- **SIAM J. Financial Mathematics (SIFIN):** best *theory* target, but only after the corrected Theorems 1–6, the martingale/ergodicity results (§3.4–3.5), the corrected roughness theorem (§3.3), and rigorous numerics with tables. The current note is a long way from this bar.
- **Quantitative Finance:** in my view a *stronger near-term fit* than the review implies, given the empirical/practitioner strengths (fast joint SPX/VIX, multi-architecture, full diagnostic suite). If closing every theory gap is not feasible quickly, QF is the pragmatic route and rewards exactly what the note does well.
- **Mathematical Finance / Finance & Stochastics:** higher pure-theory bar; the approximation results here are variations on known multifactor approximations and are likely too incremental in *pure* theory. The review's ranking (harder) is correct.
- **Neural Networks (Elsevier):** viable only if KC/RN (in its GLM form) + reservoir learning is made central, *with* the ML benchmarks of §5.3–5.4. Large additional lift.
- Also reasonable: **Journal of Computational Finance** (numerics/calibration engine) or **SIAM J. Scientific Computing** (the exponential integrator + pathwise-gradient machinery).

My recommendation: aim for **SIFIN** if you are willing to add the theory and the tables; otherwise **Quantitative Finance** is the high-probability home, and carve out the GLM-corrected KC/RN as a separate, more ML-flavoured paper.

---

## 8. Concrete revision checklist

1. **Leverage.** Replace the scalar all-node correlation with an admissible leverage vector $\varrho$, $\|\varrho\|\le1$; prove Theorem 1; reinterpret "$\rho\approx-1$" as aggregate, state-dependent leverage (§2.1, §3.2). Fix the SSR perturbation to be along $\varrho$ (§6.3).
2. **Drop or earn the PDV claim.** Either remove the endogenous-PDV/signature framing, or move to a price-driven reservoir (§3.1–3.2, §9.1).
3. **Roughness.** Reframe as finite-scale; pick the common/low-rank-Brownian route (recommended) or prove a covariance-level theorem; give the fractional loading its correct approximation-theoretic meaning; address the nonlinear-readout transfer (§3.3). Reconcile the two Hurst estimates (§6.1).
4. **Integration.** Rename "exact" to "exponential integrator, exact OU drift, frozen diffusion"; add a stability/convergence proposition (§2.3, review Thm 5).
5. **Martingality & ergodicity.** Prove a true-martingale theorem and a drift/ergodicity condition; flag that the Unified architecture is the delicate case, or cap the softplus (§3.4–3.5).
6. **VIX auto-calibration.** State it as a nonlinear fixed point with monotonicity + Jacobian-invertibility existence/uniqueness; distinguish variance-swap (linear) from VIX-futures (concave) matching (§2.4).
7. **KC/RN.** Replace log-residual least squares with a log-link GLM targeting the *arithmetic* conditional mean; prove positivity + consistency with random-feature rates (§4.2, §5.2). Use the *same* estimator in calibration and evaluation (§4.3).
8. **Gradients.** Make the differentiation through the $\eta$ fixed point rigorous (implicit function theorem / adjoint) and state the regularity hypothesis (§4.4).
9. **Numerics.** Add error tables, MC standard errors, dataset dates, filtering rules, rates/dividends, VIX interpolation, calibration weights, static no-arbitrage checks, and the architecture/feature ablations (§6.4–6.5).
10. **Language & typos.** Soften "exact market smile fits" → "close calibration"; "arbitrage-free" → "dynamically consistent + static checks". Drop "scale-invariant irrespective of mesh" and "strictly equalized" (§10.1); "bimodal loading" (Eq. 12) is monotone in $\kappa$, not bimodal. Fix "propsed", "Skew-Stickiness Ration", "Erdős–Rényi", and the inconsistent notation for $\sigma_{VS}$, $\mathcal S_T$, $D$, and the skew symbol.
11. **Architecture-aware integration & stability.** Use the full matrix-exponential + Lyapunov step-covariance for the non-normal architectures (Blockwise, Cascade), report the resulting cost honestly, and replace spectral-radius stability claims with numerical-abscissa / pseudospectral bounds (§10.1).
12. **Resolve the measure question.** State explicitly that roughness is measure-invariant; then either specify a variance/equity risk premium linking the $\mathbb Q$-calibration to the $\mathbb P$-measure Zumbach/SSR diagnostics, or relabel those diagnostics as $\mathbb Q$-measure model properties rather than reproductions of empirical facts (§10.2).
13. **Objective & cross-market arbitrage.** Recast the objective in implied-vol or vega-weighted units, report per-instrument error tables, specify the weights $\omega$, and verify the cross-market SPX–VIX no-arbitrage constraints, not only per-surface checks (§10.3, §6.4).
14. **Disentangle roughness.** Add an ablation isolating whether the empirical $H$ is *forced* or merely *permitted* by price calibration — fix $w$ and measure $H$, versus constrain $H$ and measure price fit (§10.4).
15. **Convention & out-of-sample.** State the forward/rates/dividend convention behind the zero-drift asset SDE; add a through-time out-of-sample test of parameter stability and of realized-variance dynamics the model was not fit to (§10.5).

---

## 9. Future developments and their mathematical consequences

This section sketches the extensions I would prioritise, each with the concrete mathematics it forces. I have ordered them from "closes a current gap" to "opens genuinely new theory."

### 9.1 A price-driven (genuine signature / PDV) reservoir

Replace the exogenous-Brownian reservoir with a *randomized signature of the price path*: with $X_t=(t,\log S_t)$,
$$
dR_t=\Big(AR_t+\textstyle\sum_i B_i R_t\Big)\,dX^i_t,\qquad V_t=f(w^\top R_t),\qquad \frac{dS_t}{S_t}=\sqrt{V_t}\,dZ^S_t .
$$
Now $V$ is a true functional of the path, the endogenous-PDV interpretation is *earned*, and the leverage $\rho=-1$ becomes structural rather than a free parameter. **Mathematical consequence:** well-posedness becomes a *self-referential / fixed-point* problem — $R$ depends on $X=(t,\log S)$, which depends on $V=f(w^\top R)$ — i.e. a McKean–Vlasov-flavoured or path-dependent SDE whose existence/uniqueness is not covered by the linear theory. One needs the well-posedness machinery for path-dependent / Volterra SDEs (functional Itô calculus, Dupire; or the recent stochastic-Volterra-equation theory). This is the single highest-value extension because it resolves the foundational tension of §3.1–3.2 and turns the paper into a genuine PDV contribution.

### 9.2 Common / low-rank Brownian driver and provable pathwise rough approximation

Drive the linear reservoir part with a shared (or rank-$r\ll N$) Brownian so the kernel-quadrature theorem applies. **Consequence:** rigorous convergence rates $\|K_N-K_H\|_{L^2(0,T)}\to0$ with explicit dependence on $N$ and node placement — geometric for optimally placed (Gaussian-quadrature) nodes (Bayer–Breneis), algebraic for naive log-grids — yielding a *pathwise* $L^2$ rate for $V$ via the perturbative transfer of §3.3. This converts the empirical Figure 4 into a theorem.

### 9.3 Infinite-reservoir / measure-valued limit

Take $N\to\infty$ with the node speeds distributed according to a measure $\mu(d\kappa)$. The reservoir becomes a *measure-valued* (or SPDE) object — a density over mean-reversion speeds — and the model converges to a stochastic Volterra / lifted-rough-volatility equation (Abi Jaber's infinite-dimensional Markovian lift; El Euch–Rosenbaum characteristic-function approach). **Consequence:** the statement "finite-scale roughness becomes true roughness in the limit" is made precise as a *convergence-of-models* theorem (finite-$N$ reservoir $\Rightarrow$ rough/Volterra limit), with a quantitative rate. This is the rigorous home for the roughness claim and is the most "SIFIN-shaped" result available.

### 9.4 Rigorous martingale & no-arbitrage theory across architectures

Establish necessary-and-sufficient conditions for $S$ to be a true martingale under each architecture, à la Sin / Lions–Musiela / Andersen–Piterbarg, isolating the admissible $(\varrho,\text{vol-of-vol})$ region and the role of the leverage sign. **Consequence:** a precise admissible-parameter map; likely a theorem of the form "the Unified architecture admits a true-martingale price iff the leverage projection onto the vol-of-vol direction is $\le0$ and $\|DC\|$ satisfies an explicit bound," which simultaneously delivers the ergodicity condition of §3.5. Practically, it may motivate a *capped* softplus as the default.

### 9.5 KC/RN as a general positive conditional-expectation estimator

Develop the GLM/exponential-family version of §4.2 into a standalone method for positive conditional expectations in nested Monte Carlo, with consistency and rates via random-feature theory (Rahimi–Recht; Rudi–Rosasco), and benchmark it against deep-BSDE/regression-Monte-Carlo continuation-value estimators. **Consequence:** a transferable estimator with provable positivity *and* arithmetic-mean consistency, applicable to VIX, American options, XVA, and nested risk capital. This is the cleanest path to a *Neural Networks*–type contribution and is, I think, the most underexploited idea in the note.

### 9.6 Non-reversible reservoirs and a structural theory of the Zumbach effect

Use the Cascade (non-normal, upper-triangular) drift as the canonical Zumbach generator and prove a *lower bound* on the time-reversal asymmetry $\mathcal Z(\Delta)$ in terms of the cascade leakage $\gamma$, the leverage, and a measure of non-normality of $A$ (e.g. Henrici's departure from normality $\|AA^\top-A^\top A\|_F$, or the commutator $[A,A^\top]$). **Consequence:** a structural link between the *operator algebra* of the drift and a measurable stylized fact — a genuinely novel result connecting the spectral/geometric properties of $A$ to time-reversal asymmetry. (This is squarely in the geometry-of-operators direction.)

### 9.7 Signature / free-Lie-algebra design of the reservoir coupling

Interpret the reservoir state as a randomized projection of the (price-)path signature and analyse *which* signature terms — equivalently which elements of the free Lie algebra — each architecture's coupling $B/C$ captures: level-2 terms (quadratic variation, realized variance) for the variance level itself; lead-lag / area terms for time-reversal asymmetry; time-augmentation for the term structure. **Consequence:** a principled *design* of $B/C$ (rather than random) to target specified stylized facts, with the augmentation-to-Lie-algebra dictionary (lead-lag, basepoint, time, dyadic) made explicit. This both improves the model and produces a clean rough-paths/reservoir bridge. (Note: it interacts with §3.1 — to talk about the price-path signature you want the price-driven reservoir of §9.1.)

### 9.8 Jumps, second-order Greeks, and the SSR Malliavin limit

Three smaller but high-yield extensions. **(a) Jumps:** add a jump component (affine-jump reservoir, or a self-exciting Hawkes driver consistent with ref [4]) to fit the explosive short-dated SPX skew and the steep VIX-call wing that pure diffusions struggle with; consequence — pricing moves to Fourier methods if affine structure is preserved, and the SSR short-maturity limit is modified away from $\tfrac32+H$. **(b) Second-order pathwise/AAD Greeks** (Gamma, Vanna, Volga) through the auto-calibration, enabling Hessian-based (Gauss–Newton/Levenberg–Marquardt) calibration faster and more stably than BFGS; consequence — a full risk engine and a well-posed second-order inverse problem. **(c) Analytic SSR via Malliavin calculus:** derive the model's $\frac{d\langle\sigma_{\mathrm{ATM}},\log S\rangle_t}{d\langle\log S\rangle_t}$ in closed form and show under which reservoir conditions it approaches the rough limit, *reconciling* the disparate effective-$H$ estimates of §6.1/§6.3 from theory rather than from finite-difference experiments.

---

## 10. Additional points the first review missed (second pass)

A further pass over the equations and claims surfaced five more issues that neither the first review nor §§2–9 above address. They range from a concrete numerical-analysis error through a subtle measure-theoretic inconsistency to two methodological gaps.

### 10.1 The "exact" integration formula is architecture-dependent, and eigenvalue stability does not imply stability for the non-normal reservoirs

The note states a *single* per-node variance-injection formula, $\frac{1-e^{-2\kappa\Delta}}{2\kappa}$ (end of §2), and applies it across all five architectures. Its validity is architecture-dependent:

- For the **diagonal** drifts (Lightweight, Unified, $A=-\mathrm{diag}(\kappa)$) the step covariance decouples node-by-node and the formula (times $\sigma_j^2$) is correct.
- For the **Rough** ESN, $A=\mathrm{blockdiag}(Q_j\Lambda_j Q_j^\top)$ with orthogonal $Q_j$ and complex-conjugate-pair blocks is in fact **normal** (a $2\times2$ block $-\kappa I+\omega K$, $K=\big(\begin{smallmatrix}0&1\\-1&0\end{smallmatrix}\big)$, satisfies $MM^\top=M^\top M=(\kappa^2+\omega^2)I$). With *isotropic* per-block noise the rotations cancel in $\int_0^\Delta e^{As}\Sigma\Sigma^\top e^{A^\top s}\,ds$ and the formula survives; with anisotropic block loading it does not.
- For the **non-normal** drifts — **Blockwise** (sparse Erdős–Rényi) and **Cascade** (upper-bidiagonal, $A_{j,j+1}=\gamma\kappa_j$) — the exact step covariance is the full Lyapunov integral $\int_0^\Delta e^{As}\Sigma\Sigma^\top e^{A^\top s}\,ds$, which has **off-diagonal entries**: the simple per-node formula is simply incorrect. Computing it correctly requires a matrix exponential plus a Lyapunov/Sylvester solve per step ($O(N^3)$), which dents the "minutes on commercial hardware" claim.

More fundamentally, *every* stability argument in the note is **spectral** ("spectral radius bounded", "$\mathrm{Re}(\Lambda_j)=-\kappa_j$", shifting by $\lambda_{\max}$). For a **non-normal** matrix, negative eigenvalues do **not** bound $\|e^{At}\|$ over finite horizons; transient growth is governed by the *numerical abscissa* $\mu(A)=\lambda_{\max}\!\big(\tfrac12(A+A^\top)\big)$ and the pseudospectrum, and one can have $\alpha(A)<0$ (all eigenvalues stable) yet $\mu(A)>0$ (initial exponential amplification). For the Cascade with $\kappa_1=250,\ \kappa_2=0.5,\ \gamma=0.5$, the symmetric part $\big(\begin{smallmatrix}-\kappa_1&\tfrac12\gamma\kappa_1\\ \tfrac12\gamma\kappa_1&-\kappa_2\end{smallmatrix}\big)$ has top eigenvalue $\approx+14$, so $\mu(A)>0$ despite every eigenvalue equal to $-\kappa_j<0$. In a multiplicative-noise system this transient amplification of the variance feedback is exactly what the spectral analysis misses, and it is most acute precisely where the fractional loading is largest, since $D_{jj}\propto\kappa_j^{1/2-H}$ is **unbounded and increasing** in the Rough/Cascade architectures (up to $250^{0.3}\approx5$ at $\kappa_{\max}$). A rigorous treatment should replace spectral-radius arguments with numerical-abscissa / pseudospectral bounds for the non-normal architectures. (Two related overstatements: "scale-invariant integration irrespective of the chosen mesh resolution" holds only for the OU *drift* — the frozen diffusion is $O(\sqrt{\Delta t})$ strong, per §2.3 — and "the unconditional stationary variance remains strictly equalized" for the Lightweight $\nu_j\propto\sqrt{\kappa_j}$ choice is a *frozen-$\tanh$* heuristic, exact only for constant diffusion.)

### 10.2 Measure inconsistency: the model calibrates under $\mathbb Q$ but validates against $\mathbb P$-measure stylized facts

The parameters are calibrated to option prices, i.e. under the pricing measure $\mathbb Q$, and the diagnostics are then computed from simulated $\mathbb Q$-paths (the asset has zero drift). Whether each stylized fact is legitimately reproduced depends on its behaviour under the equivalent change of measure $\mathbb P\sim\mathbb Q$:

- **Roughness is measure-invariant** — a point in the paper's favour that the review also missed. Girsanov changes only the finite-variation drift, leaving the quadratic variation $d\langle V\rangle_t=\|\Sigma(R_t)^\top\nabla g(R_t)\|^2\,dt$ unchanged, so the small-scale Hölder regularity (hence the measured $H$ in Figure 4) is the same under $\mathbb P$ and $\mathbb Q$. The roughness validation is therefore well-posed despite the $\mathbb Q$-calibration.
- **The Zumbach effect and the return-based SSR are not.** The instantaneous leverage $\rho=d\langle Z^S,W\rangle/dt$ is measure-invariant, so the *sign* of $\mathcal Z(\Delta)=\mathbb E[r_{t+\Delta}^2r_t]-\mathbb E[r_{t+\Delta}r_t^2]$ is robust; but $\mathcal Z$ and the return-based SSR are genuine *expectations* over a finite lag that mix in the drift, and the drift differs between $\mathbb P$ (with its equity/variance risk premia) and $\mathbb Q$ (zero). Comparing the model's $\mathbb Q$-measure $\mathcal Z$ to *empirical* ($\mathbb P$) Zumbach estimates is therefore measure-inconsistent unless a risk premium is specified — and the reported magnitude ($\sim10^{-8}$, already flagged as tiny in §6.2) is doubly uninterpretable.

The constructive fix: a model whose selling point is reproducing both option prices ($\mathbb Q$) and historical stylized facts ($\mathbb P$) must carry an **explicit market price of risk / variance risk premium** linking the two measures; the note specifies only $\mathbb Q$. Failing that, the Zumbach and return-SSR plots should be relabelled as *$\mathbb Q$-measure model properties* rather than reproductions of empirical facts.

### 10.3 The calibration objective mixes heterogeneous price scales and ignores cross-market no-arbitrage

The objective (Eq. 18) is a weighted **price**-MSE summing errors on SPX option premia (order $10^2$), VIX futures (order $20$), and VIX option premia (order of a few). Raw price-MSE is dominated by the largest-premium instruments — ATM SPX options — and systematically under-weights both the wings and the entire VIX block; standard practice is to work in **implied-volatility space** or with **vega-weighted** errors so that economically comparable mispricings carry comparable weight. The weights $\omega^{\mathrm{SPX}},\omega^{\mathrm{VIX}},\omega^{\mathrm{Fut}}$ are never specified, and no per-instrument error decomposition is given. Separately, joint SPX/VIX calibration is subject to **cross-market no-arbitrage constraints** (Guyon): because $\mathrm{VIX}_T^2$ is the expected forward variance, the SPX ATM-variance term structure and the VIX-futures curve are linked, and there are model-free bounds relating the two smiles. A rigorous joint-calibration claim should verify these *cross-market* constraints on the fitted surfaces, not only the *per-surface* calendar/butterfly checks requested in §6.4.

### 10.4 Roughness is an emergent, readout-dependent, post-calibration property — not an architectural guarantee

Because $V_t=f(w^\top R_t)$ with $f$ smooth and strictly monotone, the Hölder regularity of $V$ equals that of $w^\top R_t$, which depends on **which nodes $w$ weights**: weight the slow nodes and $V$ is smooth; weight the fast nodes and $V$ is rough. Since $w$ is **calibrated to option prices**, the roughness exhibited in Figure 4 is whatever the price-fit happens to produce. The calibration therefore *permits* the empirically plausible $H$; it does not *enforce* it. The note presents roughness as a property of the reservoir architecture, but it is a property of the calibrated readout — and the paper never disentangles whether matching SPX/VIX prices *forces* the right roughness or merely *allows* it. The clean test is an ablation in two directions: fix $w$ and measure $H$, versus constrain $H$ (e.g. via a penalty on the spectral tilt of $w$) and measure the price fit. This compounds §3.3 (transfer through the nonlinear readout) and §6.1 (the inconsistent $H$ estimates) and is, I think, the most important unstated caveat on the headline "generates rough asymptotics" claim.

### 10.5 Unspecified forward / rates–dividends convention, and no through-time validation

The asset SDE $dS_t/S_t=\sqrt{V_t}\,dZ^S_t$ has **zero drift**, i.e. it implicitly works under the forward measure (or assumes zero rates and dividends). The note never states this, yet Figure 1 plots **absolute** strikes (5000–10000) at maturities up to $0.8$y, where the SPX forward differs from spot by a non-trivial carry; without an explicit forward/discounting convention the smile is mislocated in strike and the SPX calibration is not reproducible. Second — and more importantly for a paper whose selling point is realistic **dynamics** — every diagnostic is a single in-sample snapshot. There is no demonstration of *out-of-sample* behaviour: no parameter stability across consecutive calibration dates, and no test of whether the calibrated reservoir reproduces realized-variance dynamics it was not fit to. Absent this, the dynamic stylized facts (roughness, Zumbach, SSR) are in-sample artifacts of one calibration rather than evidence of a faithful data-generating process.

---

### Closing assessment

The note's core is publishable, but the current document is an internal technical note, not a journal manuscript. The mathematics is mostly fixable rather than wrong: the leverage bug, the "exact"/"true-roughness"/"arbitrage-free" overclaims, and the VIX auto-calibration are correctable, and the first review caught these. The deeper work — earning (or dropping) the PDV/signature framing, getting the *right* roughness theorem for the *actual* (independent-Brownian) model or changing the model to a common driver, settling martingality/ergodicity for the softplus architecture, and reformulating KC/RN as an unbiased positive estimator — is what separates "a fast calibration engine" from "a rigorous financial-mathematics paper." Done well, item §9.1 (price-driven reservoir) plus §9.3 (infinite-reservoir limit) plus the GLM-corrected §9.5 (KC/RN) would constitute a strong, coherent SIFIN paper, with a natural Quantitative-Finance fallback for the empirical story and a separable Neural-Networks paper for the estimator. The second-pass findings in §10 are mostly fixable too, with two exceptions that deserve early attention: the non-normal-architecture integration/stability gap (§10.1), which is a genuine numerical-analysis correction, and the $\mathbb Q$-vs-$\mathbb P$ measure question (§10.2), which is conceptual and forces the paper to decide whether it is making a pricing claim, a physical-dynamics claim, or both.
