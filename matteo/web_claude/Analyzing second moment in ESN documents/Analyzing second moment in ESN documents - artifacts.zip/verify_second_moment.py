"""
verify_second_moment.py — ground-truth battery for the second-moment block of
`esn_signature_volterra_note` (§3.4, §9.1, §9.4) and Prop A / condition (S) of the
Deep-ESN architecture audit (see second_moment_audit.md).

Checks (all seeded, exact stationary initialisation, hostile NON-NORMAL (A, Sigma)):
  1. Lyapunov solve (9.3) and C_tau = P e^{A^T tau} (9.4)
  2. Prop 9.1 (9.7): Var, Cov of the linear readout
  3. Prop 9.3 (9.11)-(9.12): quadratic readout mean and two-rate covariance
  4. Prop 5.3 (5.7): exponential readout lognormal covariance
  5. QV-slope identity: -2 b'P A' b = ||Sigma' b||^2   (Lyapunov contraction; ties (3.10) to (9.7))
  6. Windowed power-law constant: int k^{-2H-1}(1-e^{-kt}) dk = t^{2H} Gamma(1-2H)/(2H)
  7. E[sqrt(V+)] delta-method constant for the (9.13) fix
  8. Prop A on the self-excited common-driver loop: m2_X(D) = m_bar * Q_K(D), three regimes
"""
import numpy as np
from scipy.linalg import expm, solve_lyapunov, cholesky
from scipy.special import gamma as Gamma
from scipy.integrate import quad

RNG = np.random.default_rng(7)


class StationaryLinearGaussianBenchmark:
    """§9.1 benchmark: dR = A R dt + Sigma dW, stationary, with linear / quadratic /
    exponential readouts. Analytic second-order structure + exact-in-law MC cross-checks."""

    def __init__(self, N=6, seed=7):
        rng = np.random.default_rng(seed)
        A = rng.normal(size=(N, N))
        self.A = A - (np.max(np.real(np.linalg.eigvals(A))) + 1.2) * np.eye(N)  # stable, non-normal
        self.Sig = rng.normal(size=(N, N)) * 0.7
        self.N = N
        self.P = solve_lyapunov(self.A, -self.Sig @ self.Sig.T)          # (9.3)
        self.P = 0.5 * (self.P + self.P.T)
        self.b = rng.normal(size=N)

    # ---------- analytic ----------
    def C(self, tau):                       # (9.4)
        return self.P @ expm(self.A.T * tau)

    def cov_linear(self, tau):              # (9.7)
        return self.b @ self.C(tau) @ self.b

    def cov_quadratic(self, Q, tau):        # (9.12)
        Ct = self.C(tau)
        return self.b @ Ct @ self.b + 2.0 * np.trace(Q @ Ct @ Q @ Ct.T)

    def cov_exponential(self, tau, xi0=1.0):  # (5.7)
        return xi0**2 * (np.exp(self.b @ self.C(tau) @ self.b) - 1.0)

    def qv_slope_identity(self):            # A1: -2 b'PA'b == ||Sig' b||^2
        lhs = -2.0 * self.b @ self.P @ self.A.T @ self.b
        rhs = self.b @ self.Sig @ self.Sig.T @ self.b
        return lhs, rhs

    # ---------- Monte Carlo (exact stationary start, matrix-exponential stepping) ----------
    def simulate_pair(self, tau, n_paths=400_000, dt=1e-3, seed=11):
        rng = np.random.default_rng(seed)
        steps = int(round(tau / dt))
        grid = np.linspace(0, dt, 21)
        Qdt = np.zeros((self.N, self.N))
        for i in range(20):
            s = 0.5 * (grid[i] + grid[i + 1])
            E = expm(self.A * s)
            Qdt += E @ self.Sig @ self.Sig.T @ E.T * (grid[i + 1] - grid[i])
        L = cholesky(Qdt + 1e-14 * np.eye(self.N), lower=True)
        Ed = expm(self.A * dt)
        R = cholesky(self.P + 1e-12 * np.eye(self.N), lower=True) @ rng.normal(size=(self.N, n_paths))
        R0 = R.copy()
        for _ in range(steps):
            R = Ed @ R + L @ rng.normal(size=(self.N, n_paths))
        return R0, R


def check_benchmark():
    B = StationaryLinearGaussianBenchmark()
    tau, a0 = 0.37, 2.0
    R0, Rt = B.simulate_pair(tau)
    V0, Vt = a0 + B.b @ R0, a0 + B.b @ Rt
    print("[1] Lyapunov residual:", np.max(np.abs(B.A @ B.P + B.P @ B.A.T + B.Sig @ B.Sig.T)))
    print("[2] (9.7)  Var  an %.5f  mc %.5f" % (B.b @ B.P @ B.b, V0.var()))
    print("    (9.7)  Cov  an %.5f  mc %.5f" % (B.cov_linear(tau), np.cov(V0, Vt)[0, 1]))
    Q = np.random.default_rng(3).normal(size=(B.N, B.N)); Q = 0.5 * (Q + Q.T)
    W0 = a0 + B.b @ R0 + np.einsum('ip,ij,jp->p', R0, Q, R0)
    Wt = a0 + B.b @ Rt + np.einsum('ip,ij,jp->p', Rt, Q, Rt)
    print("[3] (9.11) mean an %.5f  mc %.5f" % (a0 + np.trace(Q @ B.P), W0.mean()))
    print("    (9.12) Cov  an %.5f  mc %.5f" % (B.cov_quadratic(Q, tau), np.cov(W0, Wt)[0, 1]))
    v = B.b @ B.P @ B.b
    E0, Et = np.exp(B.b @ R0 - 0.5 * v), np.exp(B.b @ Rt - 0.5 * v)
    print("[4] (5.7)  Cov  an %.5f  mc %.5f" % (B.cov_exponential(tau), np.cov(E0, Et)[0, 1]))
    lhs, rhs = B.qv_slope_identity()
    print("[5] QV slope identity: -2b'PA'b = %.6f  ||S'b||^2 = %.6f" % (lhs, rhs))
    # [7] (9.13) fix: E[sqrt(V+)] delta method, regime a >> sd
    a, s = 2.0, np.sqrt(v) * 0.25
    Vs = a + s * np.random.default_rng(5).normal(size=2_000_000)
    print("[7] E[sqrt(V+)] mc %.6f  delta %.6f" % (np.mean(np.sqrt(np.clip(Vs, 0, None))),
                                                   np.sqrt(a) * (1 - s**2 / (8 * a**2))))


def check_window_constant(H=0.1, t=0.5):
    I, _ = quad(lambda k: k**(-2 * H - 1) * (1 - np.exp(-k * t)), 0, np.inf, limit=400)
    print("[6] window const: integral %.6f  vs  t^{2H} G(1-2H)/(2H) %.6f"
          % (I, t**(2 * H) * Gamma(1 - 2 * H) / (2 * H)))


# ---------------- Prop A on the self-excited common-driver loop ----------------
def softplus(x):
    return np.log1p(np.exp(-np.abs(x))) + np.maximum(x, 0.0)


def check_prop_A(H=0.15, N=6, sig_min=0.10, n_paths=4000, dt=1e-3, seed=23):
    """Layer 1 with feedback: dr = -Lam r dt + c sigma(u) dW, u = a'Y + b0 (z frozen into b0).
    Prop A: E[(X_{t+D}-X_t)^2] = m_bar * Q_K(D) exactly at stationarity."""
    rng = np.random.default_rng(seed)
    kap = np.geomspace(1.0, 50.0, N)
    a = kap**(0.5 - H)                                   # Laplace-quadrature profile (Cor 3.3)
    # enforce condition (S): 2||K||^2 < 1, with margin
    K2 = np.sum(np.outer(a, a) / np.add.outer(kap, kap))
    a *= np.sqrt(0.30 / (2 * K2)); K2 = 0.15
    b0 = -1.35                                           # sets typical sigma ~ 0.2-0.3
    Fu = lambda u: np.sqrt(sig_min**2 + softplus(u)**2)
    ek = np.exp(-kap * dt)
    r = np.zeros((N, n_paths))
    warm, rec = 8000, 20000
    X = np.empty((rec, n_paths)); S2 = np.empty((rec, n_paths))
    for t in range(warm + rec):
        u = a @ r + b0
        s = Fu(u)
        dW = rng.normal(size=n_paths) * np.sqrt(dt)
        r = ek[:, None] * r + np.outer(np.ones(N), s * dW)      # dr_j = -k_j r_j dt + s dW (c_j = 1 folded into a)
        if t >= warm:
            X[t - warm] = a @ r; S2[t - warm] = s**2
    m_bar = S2.mean()
    print(f"[8] Prop A feedback test:  m_bar = {m_bar:.5f},  2||K||^2 = {2*K2:.3f} (subcritical)")
    QK = lambda D: np.sum(np.outer(a, a) / np.add.outer(kap, kap)
                          * ((1 - np.exp(-np.add.outer(kap, kap) * D))
                             + np.outer(1 - np.exp(-kap * D), 1 - np.exp(-kap * D))))
    print("     D        m2_mc        m_bar*Q_K     ratio")
    for k in (2, 10, 50, 200, 1000, 4000):
        D = k * dt
        inc = X[k:] - X[:-k]
        m2 = (inc**2).mean()
        print("  %7.3f   %.6e   %.6e   %.3f" % (D, m2, m_bar * QK(D), m2 / (m_bar * QK(D))))


if __name__ == "__main__":
    check_benchmark()
    check_window_constant()
    check_prop_A()
