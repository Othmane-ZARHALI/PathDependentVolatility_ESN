# Second-moment audit — `esn_signature_volterra_note.pdf` (§3.4, §9.1, §9.4) and `Deep_ESN_Volatility_Architecture.pdf`

*14 July 2026 — reconstruction + fresh verification (5th attempt; recovered conclusions from the two interrupted sessions, then re-derived and re-checked everything from scratch against the PDFs). Numerical companion: `verify_second_moment.py` (seeded, exact stationary OU simulation, non-normal $(A,\Sigma)$).*

**Scope (stated assumption).** "The 2nd moment" is read as the *second-order-structure* content of the manuscript — §3.4 (eqs (3.8)–(3.11) and caveats (i)–(iii)), §9.1 (linear-Gaussian benchmark T6: (9.2)–(9.13), Lemma 9.0, Props 9.1–9.3), Prop 5.3's covariance (5.7), and §9.4 (Prop 9.10) — audited jointly with the second-moment claims of the Deep-ESN architecture note. Fourth-order material (§9.2, Zumbach proper) is deliberately out of scope until requested.

---

## Part I — Manuscript: verdict on the second-moment block

**Everything displayed is correct except one object.** Each formula was re-derived by hand and cross-checked by Monte Carlo on a random *non-normal* stable $(A,\Sigma)$ with exact stationary initialisation:

| Item | Statement | Verdict |
|---|---|---|
| (9.3)–(9.4) | Lyapunov $AP+PA^\top+\Sigma\Sigma^\top=0$; $C_\tau=P e^{A^\top\tau}$ | ✓ (convention $C_\tau=\mathbb E[R_tR_{t+\tau}^\top]$; for $\tau<0$ it transposes) |
| Lemma 9.0 | Wick–Isserlis | ✓ standard |
| Prop 9.1 (9.7) | $\mathrm{Var}=b^\top Pb$, $\mathrm{Cov}=b^\top Pe^{A^\top\tau}b$ | ✓ (MC: 1.22825 vs 1.22608; 0.61245 vs 0.61098) |
| Prop 9.2 (9.8) | $m_T(r)=a+b^\top\big(\tfrac1\tau A^{-1}(e^{A\tau}-I)\big)r$ | ✓ ($A$ stable ⇒ invertible; conditional OU mean) |
| Prop 9.2 (9.9) | $\mathrm{Var}\big(\int_0^T V\big)=2\int_0^T(T-\tau)\,b^\top Pe^{A^\top\tau}b\,d\tau$ | ✓ (uses $\gamma(\tau)=\gamma(-\tau)$ for the scalar autocovariance) |
| (9.10) | exponential-readout forward variance, $q(v)=b^\top\!\int_0^v e^{Aw}\Sigma\Sigma^\top e^{A^\top w}dw\,b$ | ✓ (conditional lognormal mean) |
| Prop 9.3 (9.11)–(9.12) | $\mathbb E V=a+\mathrm{tr}(QP)$; quadratic part $2\,\mathrm{tr}(QC_\tau QC_\tau^\top)$ | ✓ by Isserlis: two connected pairings each give $\mathrm{tr}(QC_\tau QC_\tau^\top)$ (needs $Q=Q^\top$, as stated). MC: 2.484 vs 2.500 |
| Prop 5.3 (5.7) | $\mathrm{Cov}(V_t,V_{t+\tau})=\xi_0^2(e^{c(\tau)}-1)$, $c(\tau)=b^\top Pe^{A^\top\tau}b$ | ✓ bivariate-lognormal identity; MC: 0.8450 vs 0.8356. The Stein step $\mathrm{Cov}(e^G,H)=e^{\frac12\mathrm{Var}G}\mathrm{Cov}(G,H)$ (zero-mean $G$) ✓ |
| (3.8) | Bernstein / Laplace representation of $K_H$, $\mu_H(dx)\propto x^{-H-1/2}dx$ | ✓ classical |
| (3.9) | $\sup_{t\le T}\mathbb E|Z^N_t-Z_t|^2\le\|K_N-K_H\|^2_{L^2(0,T)}$ | ✓ — and stated as $\sup\mathbb E$, **not** $\mathbb E\sup$: the manuscript correctly avoids the trap the first Pallavicini review fell into (upgrading to $\mathbb E\sup$ needs Kolmogorov/GRR, since $Z-Z^N$ is Volterra, not a martingale in $t$) |
| (3.10) | infinitesimal $H=\tfrac12$: $\lim_{\Delta\downarrow0}\tfrac1\Delta\mathbb E[(V_{t+\Delta}-V_t)^2\,|\,\mathcal F_t]=\|\Sigma^\top\nabla g\|^2$ | ✓ with a hypothesis to add (below) |
| (3.11) | independent drivers ⇒ covariance-level only: $\sum_n c_n^2 e^{-\kappa_n|\tau|}/(2\kappa_n)$ | ✓ (BNS superposition-of-OU) |
| Prop 9.10 (9.31), (i)–(iii) | memory structure across the three readouts | ✓ modulo two hypotheses (below) |

**Internal-consistency identity (worth adding as a lemma).** (3.10) and Prop 9.1/9.10(iii) agree *exactly*: for the linear readout,
$$\lim_{\tau\downarrow0}\frac{m_2(\tau)}{\tau} \;=\; -2\,b^\top P A^\top b \;=\; b^\top\Sigma\Sigma^\top b \;=\;\|\Sigma^\top b\|^2,$$
the second equality being the Lyapunov equation contracted with $b$ (using $b^\top APb=b^\top PA^\top b$ as scalars). Verified numerically to machine precision (5.30819 = 5.30819). This is a one-line proof that the QV rate of (3.10) *is* the slope of the structure function — a clean consistency check to state in §9.1 or §9.4(iii).

### I.1 The one outright error: $\mathbb E[\sqrt{V_t}]$ in (9.13)

The *derivation* of the leverage function is correct — I re-did it: with $r_t=\int_t^{t+\delta}\sqrt{V_s}\,dZ_s$, the $\mathcal F_t$-measurable piece kills against the martingale increment, the Itô product rule over the overlap $[t,t+\delta]$ gives $\int_t^{t+\delta}\mathbb E[\sqrt{V_s}]\,b^\top e^{A(t+\tau-s)}\Sigma\varrho\,ds$, and stationarity + $\delta\ll\tau,\kappa_{\max}^{-1}$ yields $\delta\,\mathbb E[\sqrt{V_t}]\,b^\top e^{A\tau}\Sigma\varrho$; the one-sidedness $L(\tau)=0$ for $\tau<0$ is exact (tower property), and $\rho_{ZV}=b^\top\Sigma\varrho$ is the correct covariation rate.

**But under the linear readout of the benchmark, $V_t=a+b^\top R_t\sim\mathcal N(a,\,b^\top Pb)$, so $\mathbb P(V_t<0)>0$ and $\sqrt{V_s}$, hence $\mathbb E[\sqrt{V_t}]$, is not a well-defined real object.** The return $r_t$ itself is ill-defined in the same benchmark. One-line fixes, pick one:

1. Replace $\sqrt{V_s}$ by $\sqrt{V_s^+}$ throughout §9.1's return definition, and $\mathbb E[\sqrt{V_t}]\to\mathbb E[\sqrt{V_t^+}]$ in (9.13); add the delta-method constant $\mathbb E[\sqrt{V^+}] = \sqrt a\,\big(1-\tfrac{b^\top Pb}{8a^2}\big)+O\!\big((b^\top Pb)^2/a^{7/2}\big)$, valid in the regime $a\gg\sqrt{b^\top Pb}$ where the benchmark is anyway meant to live.
2. Or state (9.13) under the quadratic / exponential readouts (where $\sqrt V$ is unconditionally defined) and remark that the linear-readout version is the $a\gg\sqrt{b^\top Pb}$ limit. For the exponential readout the prefactor changes to the lognormal one via the note's own $\mathrm{Cov}(e^G,H)$ identity.

Either way the sentence "at stationarity, to first order in $\delta$" should carry the positivity qualification explicitly.

### I.2 Missing hypotheses (all one-liners, no substantive damage)

1. **Prop 9.10(i): "$b\neq0$" is not enough.** Long-lag decay at $e^{-\kappa_{\min}\tau}$ requires $b$ to load the *slowest mode* (nonzero component in the corresponding left/right-eigenvector direction). If $b$ is orthogonal to it, decay is at the slowest *loaded* rate. Say "if $b$ loads the slowest mode".
2. **Prop 9.10, "the stationary mode weights being positive" is a genuine hypothesis, not a fact.** It holds in the diagonal benchmark ($b_n^2p_n\ge0$), but for non-normal $A$ the modal residues of $b^\top Pe^{A^\top\tau}b$ can be negative or complex — the autocovariance need not be completely monotone, and non-diagonalisable $A$ adds $\tau^k e^{-\kappa\tau}$ Jordan factors. This is *consistent with* (indeed, it is) the manuscript's own non-normality theme in §9.2; a cross-reference would turn a gap into a feature.
3. **(3.10) as a conditional limit needs an integrability hypothesis** — e.g. $g\in C^2$ with derivatives of polynomial growth and $R_t$ with all moments (true in §9.1 and for bounded-diffusion reservoirs); otherwise the drift/cross remainder terms ($O(\Delta^2)$, $O(\Delta^{3/2})$) are not dominated. One clause: "for $g\in C^2$ with polynomially bounded derivatives and $\sup_t\mathbb E|R_t|^p<\infty$ for all $p$".
4. **(9.4) convention.** State $C_\tau:=\mathbb E[R_tR_{t+\tau}^\top]$ once; $C_{-\tau}=C_\tau^\top$ is what makes (9.9)'s $|s-u|$ collapse legitimate.

### I.3 Suggested additions (provable, each ~½ page)

- **A1 (QV-slope identity).** The lemma of the box above: $-2b^\top PA^\top b=\|\Sigma^\top b\|^2$, tying (3.10) to (9.7).
- **A2 (windowed power law with explicit constant).** Continuum identity behind Cor 3.3 / Prop 9.10(iii): with weights $w(\kappa)\,d\kappa \propto \kappa^{-2H-1}d\kappa$ (i.e. $b_n^2p_n\propto\kappa_n^{-2H}$ on a log-grid, which is exactly Cor 3.3's loading $c_n\propto\kappa_n^{1/2-H}$ with $p_n=\sigma_n^2/2\kappa_n$),
  $$\int_0^\infty \kappa^{-2H-1}\big(1-e^{-\kappa\tau}\big)\,d\kappa=\tau^{2H}\,\frac{\Gamma(1-2H)}{2H},$$
  (verified numerically: 5.067604 = 5.067604 at $H=0.1,\tau=0.5$), so $m_2(\tau)=C_H\tau^{2H}\big(1+\varepsilon_N(\tau)\big)$ on $[\kappa_{\max}^{-1},\kappa_{\min}^{-1}]$ with $\varepsilon_N$ the log-grid quadrature error and the micro/macro crossovers of Prop 9.10(iii). This turns "approximates a power law across the band" (Prop 9.1) into a quantitative statement with an explicit constant and error term.
- **A3 (exact second-moment identity for the *input-driven* reservoir)** — see Part II Prop A; it belongs in the manuscript because it is the second-moment face of the common-driver side of (3.11)'s dichotomy *with self-excitation included*.
- **A4 (moment subcriticality for the floored-softplus readout)** — Part II, condition (S).

---

## Part II — `Deep_ESN_Volatility_Architecture.pdf`: second-moment claims

Model as written (notation normalised): $dS_t/S_t=\mu_S\,dt+\sigma_t\,dW_t$ with **scalar** $W$; $dM_t=\sigma_t\,dW_t$; layer 1 $dr_t=-\Lambda r_t\,dt+c\,dM_t$ ($\Lambda=\mathrm{diag}(\kappa_j)$, geometric grid); layer 2 $dz_t=\big(-Az_t+\phi(W_{zr}r_t+W_{zz}z_t)\big)dt+\dots$ (diffusion unspecified); readout $\sigma_t=F(u_t)$, $F(u)=\sqrt{\sigma_{\min}^2+\mathrm{sp}(u)^2}$, $u_t=w_r^\top r_t+w_z^\top z_t+b_{\text{out}}$. Note $F$ is $C^\infty$, strictly increasing, $0<F'<1$ (so the full system is globally Lipschitz), $F(u)\to\sigma_{\min}$ as $u\to-\infty$, $F(u)\sim u$ as $u\to+\infty$.

**Two structural facts that are *right* and worth keeping:**
- **Genuine endogenous PDV, provably.** Since $M_t=\int_0^t(dS_s/S_s-\mu_S\,ds)$ is recoverable from the price path, $r_t=\int e^{-\Lambda(t-s)}c\,dM_s$ and hence $V_t=\sigma_t^2$ is a measurable functional of $\{S_u\}_{u\le t}$. Unlike the Pallavicini exogenous-reservoir construction (review §3.1–3.2), this one *earns* the PDV label; the self-referential well-posedness fear (review §9.1) dissolves because $(\log S,r,z)$ is a plain finite-dimensional SDE with globally Lipschitz coefficients ⇒ unique global strong solution, no fixed-point machinery needed.
- **Single-noise consequence:** the instantaneous spot–vol correlation is identically $\mathrm{sign}(w_r^\top c)$ ($\pm1$), since $d\langle\log S,\sigma\rangle_t=F'(u_t)\,(w_r^\top c)\,\sigma_t^2\,dt$ and $z$ carries no quadratic variation. Leverage is *structural*, as in Guyon–Lekeufack; it also means the model cannot decorrelate spot and vol even instantaneously (their "mostly" qualifier — exogenous noise — is the remedy if needed).

### Prop A (exact stationary second-moment identity — the honest version of "the exact Hurst is preserved")

Let $X_t=w_r^\top r_t=\int_{-\infty}^t K(t-s)\,dM_s$, $K(u)=\sum_j a_j e^{-\kappa_j u}$, $a_j=w_{r,j}c_j$. If $(r,z)$ has a stationary law $\pi$ with $\bar m:=\mathbb E_\pi[\sigma^2]<\infty$, then for every $\Delta>0$
$$\mathbb E\big[(X_{t+\Delta}-X_t)^2\big]=\bar m\,Q_K(\Delta),\qquad Q_K(\Delta)=\int_0^\Delta K(v)^2dv+\int_0^\infty\big(K(v+\Delta)-K(v)\big)^2dv.$$
*Proof.* Split at $t$; the cross term vanishes by conditioning (the post-$t$ integral is a martingale increment); Itô isometry gives $\int K^2\,\mathbb E[\sigma^2_\cdot]$, and stationarity replaces $\mathbb E[\sigma_s^2]$ by $\bar m$. ∎

*Numerically confirmed on the actual feedback loop* (script check [8]): with $2\|K\|^2=0.30$ (subcritical), the ratio $m_2^{\rm MC}(\Delta)/(\bar m\,Q_K(\Delta))$ is flat at $1.01$–$1.02$ across three decades $\Delta\in[2\times10^{-3},4]$ — micro through macro — the residual $+1\text{–}2\%$ being the $O(dt)$ weak bias of the Euler step at $dt=10^{-3}$, not a failure of the identity.

**The entire self-excitation enters the second-order structure only through the scalar $\bar m$.** So the deterministic kernel theory (manuscript §3.4, Step 2) transfers *verbatim* — and, crucially, the architecture sits on the **common-driver / pathwise side of the (3.11) dichotomy** (all nodes share the one Brownian through $dM$), unlike Pallavicini's diagonal-$\Sigma$ independent-noise design. Explicitly,
$$Q_K(\Delta)=\sum_{j,k}\frac{a_ja_k}{\kappa_j+\kappa_k}\Big[\big(1-e^{-(\kappa_j+\kappa_k)\Delta}\big)+\big(1-e^{-\kappa_j\Delta}\big)\big(1-e^{-\kappa_k\Delta}\big)\Big],$$
giving the three provable regimes:
- **micro** $\Delta\lesssim\kappa_{\max}^{-1}$: $Q_K(\Delta)=K(0)^2\Delta+O(\Delta^2)$, $K(0)=w_r^\top c$ ⇒ infinitesimal $H=\tfrac12$ whenever $w_r^\top c\neq0$ — manuscript (3.10) verbatim. (Curiosity: if $w_r^\top c=0$ the martingale parts cancel at leading order and the readout is micro-smooth while still window-rough.)
- **band** $[\kappa_{\max}^{-1},\kappa_{\min}^{-1}]$: with $a_j\propto\kappa_j^{1/2-H}$ (Laplace quadrature of $\mu_H$, all $a_j>0$): $\bar m\,c_H\Delta^{2H}(1+\varepsilon_N(\Delta))$, error = $L^2$ kernel-quadrature error (Carmona–Coutin–Montseny; Abi Jaber–El Euch; Bayer–Breneis / Alfonsi–Kebaier rates: geometric in $N$ for optimised nodes, algebraic for the naive log-grid).
- **macro** $\Delta\gtrsim\kappa_{\min}^{-1}$: saturation at $2\,\mathrm{Var}_\pi(X)=2\bar m\|K\|_{L^2}^2$.

### Claim-by-claim verdicts on the architecture note

**(a) "Because there is no cross-talk, the exact target Hurst parameter is preserved" — false as stated, true in the Prop-A form.** Three separate corrections: (i) at fixed $N$ the infinitesimal exponent is $\tfrac12$ ((3.10)); $\Delta^{2H}$ holds only on the band and becomes exact only as $N\to\infty,\kappa_{\max}\to\infty$; (ii) $H$ is encoded in the **weights** $a_j=w_{r,j}c_j\propto\kappa_j^{1/2-H}$, *not* in $\Lambda$: "Roughness is tuned by the diagonal matrix $\Lambda$" (§4) is wrong in emphasis — $\Lambda$ sets the band, the weight profile sets the slope; the document never specifies the weights at all; (iii) "no cross-talk" is not true dynamically — $z$ modulates layer 1 through $\sigma_t$ in the common driver. What *is* exactly preserved is the kernel factorisation $r=\int e^{-\Lambda\cdot}c\,dM$ (the filter applied to returns is unpolluted); Prop A is the precise, provable surrogate. Note also that since $w$ is calibrated, the design **permits** the target $H$ rather than **enforcing** it — the review's §10.4 ablation (fix $w$, measure $H$ / constrain $H$, measure fit) applies here unchanged.

**(b) The "$+\dots$" in Eq (4) is load-bearing.** If $z$ is drift-only, $z\in C^1$ pathwise with bounded derivative ($\phi$ bounded, $A$ stable ⇒ $|z_t|\le e^{-a_z t}|z_0|+\|\phi\|_\infty/a_z$ deterministically, using the log-norm $a_z=\lambda_{\min}\big(\tfrac12(A+A^\top)\big)>0$ — the *numerical abscissa*, not just eigenvalues, per review §10.1), so $z$ contributes $O(\Delta^2)$ to squared increments and $O(\Delta^{1+H})$ to the cross term — both subleading to $\Delta^{2H}$: **exponent decoupling is then a theorem**, $m_2^u=m_2^X(1+o(1))$ on the band. If instead $z$ carries $dM$-noise, it adds its own semimartingale floor $K_z(0)^2$-type term in the micro regime and the decoupling claim changes. The second-moment analysis cannot be closed until Eq (4) is completed.

**(c) "A single dense matrix smears the relaxation spectrum" — imprecise.** A dense *normal* $A$ can carry any prescribed spectrum. The genuine risks are (i) with nonlinear drift the spectrum is not the controlling object, and (ii) non-normal $A$ has transient amplification governed by the numerical abscissa / pseudospectrum, not eigenvalues. The block-triangular structure *does* provably preserve the map $M\mapsto r$ exactly — that part is fine.

**(d) "Prevents numerical explosions through bounded self-exciting mechanisms" — half right, wrong adjective.** Softplus is linear-growth, not bounded. What is true: global Lipschitz coefficients ⇒ **pathwise non-explosion in finite time, unconditionally** (this *is* the genuine advantage over exponential readouts). What is not delivered: moment stationarity. Closing the loop through Prop A: $\mathrm{Var}_\pi(X)=\bar m\|K\|^2_{L^2}$ exactly, and $\mathrm{sp}(x)^2\le 2\ln^2 2+2x^2$ gives, for any $\varepsilon>0$, $\bar m\le C_\varepsilon+2(1+\varepsilon)\|K\|^2_{L^2}\,\bar m$, hence the **subcriticality condition**
$$\textbf{(S)}\qquad 2\,\|K\|^2_{L^2(0,\infty)}<1,\qquad \|K\|^2_{L^2}=\sum_{j,k}\frac{a_ja_k}{\kappa_j+\kappa_k},$$
sufficient for $\sup_t\mathbb E[\sigma_t^2]<\infty$ (Grönwall/comparison in the non-stationary case; existence of $\pi$ then via Lyapunov + hypoellipticity — Hörmander holds generically since $\{\Lambda^k c\}$ spans by Vandermonde when the $\kappa_j$ are distinct and $c_j\neq0$, with the drift coupling $W_{zr}$ propagating noise into $z$). The architecture document silently needs (S). If (S) fails, second moments can grow exponentially even though paths never explode — calibration diagnostics would then be non-stationary artefacts.

**(e) The readout is monotone, not even — Hermite rank 1.** $\mathrm{sp}(w^\top h+b)^2$ is increasing in its argument: it does **not** implement sign-folding, so the readout by itself supplies a leverage-type (odd, signed) channel, not the ARCH/magnitude ($R_2$-type) channel the surrounding text implies. In the manuscript's language: sign-folding needs a quadratic readout (§4, Cor 5.2) or the even part of $\phi$ acting on $r$ inside layer 2 — which puts the entire strong-Zumbach burden on the truncated Eq (4). "Directly generating … the asymmetric Zumbach effect" is therefore a design intention, not a theorem; the provable route is the manuscript's own four-point machinery (Prop 9.4 / Cor 9.9), applied with returns in the control path (the strong regime, consistent with the three-arm experiment). What layer 1 + monotone readout *do* deliver provably is the one-sided leverage function — the (9.13) object, now with $\sqrt V$ well-defined since $\sigma\ge\sigma_{\min}$.

**(f) Two smaller points.** (i) "Without killing optimization gradients": $F'(u)\to0$ *exponentially* as $u\to-\infty$, so gradients do vanish in the low-vol regime; also $d\langle\sigma\rangle_t=F'(u_t)^2(w_r^\top c)^2\sigma_t^2\,dt$, so vol-of-vol switches off near the floor — a "sticky floor" (the state keeps moving since the driver has $\sigma\ge\sigma_{\min}$, so it is not absorbing, but the claim needs the qualifier). (ii) $d\langle V\rangle_t=4F'(u_t)^2(w_r^\top c)^2\sigma_t^4\,dt$: in the linear regime vol-of-variance $\propto V$ — lognormal-type scaling, the right ingredient for upward-sloping VIX-call smiles. (iii) "Autonomous" in the abstract clashes with the manuscript's taxonomy: this model is the *input-driven / return-driven* regime (the opposite of Pallavicini's autonomous reservoir); rename to "endogenous". (iv) Martingality of $S$ is untouched by the soft floor: $V$ has quadratic growth in $h$ with linear-growth multiplicative noise, so Novikov fails generically (manuscript §3.4 caveat (iii), T7); the conjectured sufficient condition is the leverage sign $w_r^\top c\le0$ plus a growth bound, via a Sin / Lions–Musiela / Andersen–Piterbarg argument — worth stating as an open item, not assuming.

---

## References touched by this audit

Already in the manuscript's bibliography and used as-is: Carmona–Coutin–Montseny; Abi Jaber–El Euch, *Multifactor approximation of rough volatility models*, SIAM J. Fin. Math. 10(2), 309–349 (2019); Bayer–Breneis; Alfonsi–Kebaier; Barndorff-Nielsen–Shephard (superposition of OU); Gatheral–Jusselin–Rosenbaum (quadratic rough Heston); Grigoryeva–Ortega / Gonon–Grigoryeva–Ortega; Guyon–Lekeufack, QF 23(9), 1221–1258 (2023); Blanc–Donier–Bouchaud, QF 17(2), 171–188 (2017); Zumbach, *Time reversal invariance in finance*, QF 9(5), 505–515 (2009).

Added by this audit (verify exact bibliographic data before citing in the manuscript — flagged, not silently assumed):
- Sin (1998), *Complications with stochastic volatility models*, Adv. Appl. Probab. 30, 256–268 — martingality via auxiliary-diffusion explosion.
- Lions–Musiela (2007), *Correlations and bounds for stochastic volatility models*, Ann. IHP (C) 24(1), 1–16.
- Andersen–Piterbarg (2007), *Moment explosions in stochastic volatility models*, Finance Stoch. 11(1), 29–50.
- El Euch–Gatheral–Radoičić–Rosenbaum (2020), *The Zumbach effect under rough Heston*, QF 20(2), 235–241 — [verify volume/pages] — relevant to (e) and §9.2, weak vs strong regimes.
- McCullagh–Nelder (1989), *Generalized Linear Models*, 2nd ed. — already implicit in §5's GLM paragraph.

## Open items / next steps

1. Patch (9.13) (choose fix 1 or 2 above) and add the four one-line hypotheses of §I.2.
2. Decide the "$+\dots$" in the architecture note's Eq (4) — everything in Part II(b)/(e) branches on it.
3. Candidate LaTeX additions for the manuscript: A1 (QV-slope identity), A2 (windowed power law with $\Gamma(1-2H)/2H$), A3 (Prop A: exact input-driven second-moment identity + condition (S)).
4. Deferred by scope: fourth-order material (§9.2, Props 9.4–9.9 / Cor 9.9) — the Zumbach block proper.
