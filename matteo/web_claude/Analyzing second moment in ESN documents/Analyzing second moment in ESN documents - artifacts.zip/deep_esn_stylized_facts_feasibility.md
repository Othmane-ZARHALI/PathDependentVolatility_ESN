# Can the Case-A Deep ESN cover the full stylized-facts panel?

*14 July 2026. Companion to `deep_esn_architecture_audit.md` (notation defined there, §1.2; recapped below). Scope fixed by the user: **(U1) resolved as Case A** — Layer 2 is drift-only, so $z$ has $C^1$, deterministically bounded paths. Question addressed: can a layered ("deep") ESN, with layers responsible for different stylized facts, jointly deliver (i) roughness of volatility, (ii) volatility clustering, (iii) the Zumbach effect, (iv) the Taylor effect, (v) fat-tailed log-returns?*

**Short answer.** Yes — all five are reachable inside the Case-A construction, **provided two amendments** that the analysis forces: **(M1)** $\phi$ must contain a nonzero even component (Proposition Z of the audit is now binding: with odd $\phi$, Case A has *no* magnitude channel, hence no strong Zumbach, for any parameter choice); **(M2)** the diagnostics must be chosen moment-aware (log-volatility structure functions and $|r|$-based autocorrelations), because the mechanism that produces the fat tails makes high moments infinite — and, pleasingly, this "tension" is precisely the empirical reason the Taylor effect exists. The honest refinement of the design philosophy is that stylized facts map onto **axes of the architecture**, not one-to-one onto layers; the layers' role is to make the axes *independently addressable*.

---

## 1. Notation recap and new objects

From the audit (§1.2): driver $dM_t=\sigma_t dW_t$; Layer-1 feature $X_t=w_r^\top r_t=\int_{-\infty}^t K(t-s)\,dM_s$ with kernel $K(v)=\sum_j a_je^{-\kappa_jv}$, $a_j=w_{r,j}c_j$; $\rho_c=K(0)=w_r^\top c$; readout $\sigma_t=F(u_t)$, $u_t=X_t+w_z^\top z_t+b_{\rm out}$, $F(u)=\sqrt{\sigma_{\min}^2+\mathrm{sp}(u)^2}$; $\bar m=\mathbb E_\pi[\sigma^2]$; subcriticality **(S)**: $\|K\|_{L^2}^2<1$; structure function $m_2^Y(\Delta)=\mathbb E[(Y_{t+\Delta}-Y_t)^2]$.

New objects used here:

| Symbol | Definition |
|---|---|
| $r_{t,\delta}$ | return over window $\delta$: $r_{t,\delta}=M_{t+\delta}-M_t$ (martingale normalization $\mu_S=0$) |
| $\nu$ | tail index of $\sigma$ under $\pi$: $\mathbb P_\pi(\sigma>x)=x^{-\nu}\ell(x)$, $\ell$ slowly varying (when regular variation holds) |
| $\rho_\theta(\tau)$ | power ACF: $\rho_\theta(\tau)=\mathrm{Corr}\big(\lvert r_{t,\delta}\rvert^\theta,\,\lvert r_{t+\tau,\delta}\rvert^\theta\big)$ |
| $m_q^{\log}(\Delta)$ | log-vol structure function $\mathbb E\big[\lvert\log\sigma_{t+\Delta}-\log\sigma_t\rvert^q\big]$ (the Gatheral–Jaisson–Rosenbaum diagnostic) |
| **Taylor effect** | the empirical fact that $\tau\mapsto\rho_\theta(\tau)$ is largest (pointwise, over moderate lags) for $\theta\approx1$, and in particular $\rho_1>\rho_2$ (Taylor 1986; Ding–Granger–Engle 1993) |
| **clustering** | slow (power-law over a wide lag range) decay of $\rho_\theta(\tau)$, $\theta\in\{1,2\}$ (Cont 2001) |

---

## 2. The coverage map

| Stylized fact | Generating mechanism in this model | Architectural locus (the "dial") | Status |
|---|---|---|---|
| No linear autocorrelation of returns | martingale structure of $M$ | — (free) | ✓ exact under $\mathbb Q$-normalization |
| Leverage + **weak Zumbach** | monotone readout of signed trend, $\rho_c<0$ | Layer 1 + readout **sign** | ✓ proved (audit §7.2): one-sidedness exact, sign $=\mathrm{sign}(\rho_c)$ |
| **Roughness** ($H\!\approx\!0.1$, band) | common-driver kernel quadrature | Layer 1 grid $\Lambda$ (window) + weight **shape** $a_j\propto\kappa_j^{1/2-H}$ (slope) | ✓ proved at 2nd-moment level (Prop A + Corollary); log-vol transfer below |
| **Clustering** (mid lags) | same kernel, slow end of the Laplace measure | weight shape at **small $\kappa$** | ✓ same object as roughness, other asymptotic (§3.2) |
| **Clustering** (long horizon) | slow nonlinear integrals | Layer 2 rates $A$ slower than $\kappa_{\min}$ | ✓ mechanism; quantitative ACF = linearized computation |
| **Fat tails** of returns | multiplicative closure of the loop ($\sigma\!\sim\!u$ branch) near criticality | loop **gain** $\Vert K\Vert^2\uparrow1$; balance $\kappa_{\rm eff}$ vs $\rho_c^2$ | ✓ scalar caricature exact (§3.5); multi-node = conjecture + numerics |
| **Taylor effect** | fat tails × persistence, through the Gaussian mixture | corollary of the two rows above | ✓ qualitative theorem (§3.6); "max at $\theta\!\approx\!1$" is calibration |
| **Strong Zumbach** / ARCH magnitude channel | even features of past trends feeding $\sigma$ | Layer 2 **parity**: even component of $\phi$ (amendment M1) | ◑ mechanism clear; theorem = four-point computation (roadmap R3) |

Facts *not* on the list that the construction cannot reach without further surgery: imperfect instantaneous spot–vol correlation (single noise ⇒ $|\mathrm{corr}|\equiv1$, audit P3) and jump-type gap risk at the shortest horizons.

---

## 3. Fact-by-fact analysis

### 3.1 Roughness — settled, with one diagnostic amendment

Prop A + Corollary (audit §4) give $m_2^X(\Delta)=\bar m\,c_H\Delta^{2H}(1+\varepsilon_N)$ on the window, feedback entering only through $\bar m$. Two additions needed once fat tails (§3.5) are in play:

- **Measure roughness on $\log\sigma$, not on $V$.** With return tail index $\nu\in(3,5)$ (empirical), $\mathbb E_\pi[\sigma^4]=\infty$, so $m_2^V$ *does not exist in the model* — matching the data, where fourth-moment-based statistics are unstable. The GJR diagnostic $m_q^{\log}$ is the right object, and it transfers cleanly:

**Lemma L (log-vol transfer).** $u\mapsto\log F(u)$ is globally Lipschitz with constant $\le1/\sigma_{\min}$ (since $F'<1$, $F\ge\sigma_{\min}$). Hence $m_2^{\log\sigma}(\Delta)\le\sigma_{\min}^{-2}m_2^u(\Delta)$, which needs only $\bar m<\infty$, i.e. (S) — valid even when $\sigma$ is heavy-tailed. Lower bounds and slope transfer as in audit Prop T3, with $F'/F$ in place of $F'$ (same localization hypothesis (H2), same sticky-floor exclusion).

### 3.2 Clustering — the other end of the same Laplace measure

Roughness and mid-range clustering are **one second-order object read at two asymptotics**: $m_2 = 2(\mathrm{Var}-\mathrm{Cov})$, so $\mathrm{ACF}(\tau)\approx1-(\tau/\tau_*)^{2H}$ over the rough band. Beyond the band, the ACF decay is governed by the weight mass at **slow** $\kappa$: for the linearized (frozen-Gaussian, audit §7.2) variance ACF, $\mathrm{Cov}\sim\sum_j\frac{a_j^2\bar m}{2\kappa_j}e^{-\kappa_j\tau}$, and a profile $a_j^2/\kappa_j\propto\kappa_j^{\beta-1}\cdot(\text{grid mass})$ on the slow end produces $\mathrm{ACF}(\tau)\sim\tau^{-\beta}$ across the slow band (same superposition mechanism, [MS Prop 9.1/9.10]). **Consequence:** roughness constrains the weight profile at *fast* $\kappa$, clustering at *slow* $\kappa$ — the Laplace measure has room for both (a broken power law in $a_j$), so there is **no conflict**, and finite banks give the usual exponential cutoff beyond $\kappa_{\min}^{-1}$ unless Layer 2 takes over:

- **Layer 2 as the long-horizon clustering bank.** With decay rates of $A$ chosen *slower* than $\kappa_{\min}$, the (bounded, $C^1$) channel $w_z^\top z$ adds persistence at horizons Layer 1 cannot reach — cheap, because slow *drift* channels do not disturb the micro/band regimes (audit Prop T1: $z$ contributes $O(\Delta^2)$ to increments). This is the first genuine "layer owns a fact-cluster" assignment that survives scrutiny.

### 3.3 Leverage and weak Zumbach — settled

Audit §7.2: under the martingale normalization the Zumbach statistic reduces to the leverage channel; one-sidedness is exact; sign $=\mathrm{sign}(\rho_c)$. Layer 1 + readout sign own this fact. Nothing more needed.

### 3.4 Strong Zumbach — amendment (M1), now unavoidable

Case A closed the alternative route (a $dM$-driven $z$), so by Proposition Z the even component of $\phi$ is the **only** entry point for the magnitude/ARCH channel. Concrete minimal proposal, preserving (A1) (bounded, Lipschitz) and the tunability of the parity:
$$\phi(x)\;=\;\alpha\,\tanh(x)\;+\;\beta\,\tanh(x)^2,\qquad \alpha,\beta\in\mathbb R,$$
(componentwise; any bounded Lipschitz even part works, e.g. $\tanh^2$, $1-\mathrm{sech}$, $x\tanh(x)$ capped). Mechanism: $z$ then integrates even functionals of the smoothed trends $W_{zr}r$, i.e. $|{\rm trend}|^2$-type features. By Itô, the square of an exponentially-weighted trend contains the exponentially-weighted **realized variance** $\int e^{-2\kappa(t-s)}\,d[M]_s$ plus a martingale part — so the even channel spans both trend-magnitude and realized-variance features: a strict superset of the Guyon–Lekeufack $(R_1,R_2)$ pair, with $R_1$ carried by Layer 1 and $R_2$-type content by Layer 2. This is the quadratic-feedback class known to generate the strong effect (quadratic Hawkes, Blanc–Donier–Bouchaud 2017; quadratic rough Heston, Gatheral–Jusselin–Rosenbaum 2020; rough Heston alone has only the weak effect, El Euch–Gatheral–Radoičić–Rosenbaum 2020 ⚑).

*Status:* mechanism identified and consistent with the three-arm experimental finding (returns in the control path activate the strong regime); a **theorem** requires the four-point computation of [MS §9.2] applied to this architecture at first order in $\beta$ — roadmap item R3. Note the channel *saturates* in extremes ($\tanh^2$ bounded, $z$ bounded): the strong effect is produced in the bulk, not in the far tail — arguably realistic, and it protects (S).

### 3.5 Fat-tailed returns — the loop itself is the tail generator

This is the point where the construction is quietly powerful. The feedback closure makes the readout argument a **multiplicative-noise** process on its linear branch: heuristically, along the excursion direction,
$$du\;\approx\;-\kappa_{\rm eff}\,u\,dt\;+\;\rho_c\,F(u)\,dW,\qquad F(u)\sim u\ \ (u\to+\infty).$$

**Proposition F (scalar caricature — exact).** For the one-node model $du=-\kappa u\,dt+\rho_c F(u)\,dW$ with $F(u)=u$ for $u\ge u_0>0$ (linear branch) and uniformly elliptic, mean-reverting behavior below $u_0$: the stationary density solves the Fokker–Planck equation, whose power ansatz $p(x)\propto x^{-\alpha-1}$ on the linear branch gives
$$-\kappa\alpha+\tfrac12\rho_c^2\,\alpha(\alpha-1)=0\;\Longrightarrow\;\boxed{\ \nu=\alpha=1+\frac{2\kappa}{\rho_c^2}\ }$$
— a *tunable* Pareto tail for $\sigma\ (\sim u)$, the continuous-time analogue of Nelson's (1990) GARCH-diffusion inverse-gamma tail and of Kesten-type recursions (Kesten 1973; Buraczewski–Damek–Mikosch 2016).

**Transfer to returns (Breiman).** Returns are a Gaussian mixture, $r_{t,\delta}\approx\sigma_t\sqrt\delta\,Z$: if $\sigma$ is regularly varying with index $-\nu$ and $Z$ has all moments, then $\mathbb P(|r|>x)\sim\mathbb E|Z|^\nu\,\mathbb P(\sigma\sqrt\delta>x)$ (Breiman 1965): **the return tail index equals $\nu$.** Empirical $\nu\in(3,5)$ (the "cubic law" range, Gopikrishnan–Plerou–Amaral–Meyer–Stanley 1999 ⚑) is reached by choosing $\rho_c^2/\kappa_{\rm eff}\in(\tfrac12,1)$.

**The beautiful consistency check.** In the scalar caricature, $\|K\|_{L^2}^2=\rho_c^2/(2\kappa)$, so
$$\textbf{(S)}\ \Big(\|K\|^2<1\Big)\;\Longleftrightarrow\;\rho_c^2<2\kappa\;\Longleftrightarrow\;\nu>2:$$
the subcriticality condition of the audit **is exactly the finite-variance condition on the tail index** (up to one-sided corrections from $\mathrm{sp}^2$ acting on $u^+$ only). One dial, $1-\|K\|^2$: its size is simultaneously the moment-stability margin and the (inverse) tail heaviness — the model is *designed* to live near criticality, which is precisely the quadratic-Hawkes reading of why markets have fat tails (Blanc–Donier–Bouchaud 2017).

*Status:* scalar case exact; **multi-node exponent is a conjecture** — it is a Lyapunov-exponent/Kesten-type problem (conditional on a large excursion, the state aligns with the growth-maximizing direction; heuristically the slowest heavily-loaded mode dominates, $\nu\approx1+2\kappa_{\rm eff}/\rho_c^2$ with $\kappa_{\rm eff}$ between $\kappa_{\min}$ and a weight-averaged rate). Numerically estimable with a Hill estimator on long simulations — roadmap R4.

### 3.6 Taylor effect — a corollary, not a separate design target

With returns $r=\sigma\sqrt\delta Z$ conditionally Gaussian, tails of index $\nu$, and persistent $\sigma$ (§3.2), the power-ACF decomposes as
$$\rho_\theta(\tau)=A_\theta\cdot\mathrm{Corr}\big(\sigma_t^\theta,\sigma_{t+\tau}^\theta\big),\qquad A_\theta=\frac{(\mathbb E|Z|^\theta)^2\,\mathrm{Var}(\sigma^\theta)}{\mathbb E|Z|^{2\theta}\,\mathrm{Var}(\sigma^\theta)+\big(\mathbb E|Z|^{2\theta}-(\mathbb E|Z|^\theta)^2\big)(\mathbb E\sigma^\theta)^2}.$$
Rigorous pieces, immediate from this and regular variation: (i) $\rho_\theta$ **exists iff $\theta<\nu/2$** — with $\nu<4$ the squared-return ACF does not exist in population (its sample version is unstable), while $\rho_1$ is well-defined: Taylor's original ordering $\rho_1>\rho_2$ is reproduced *structurally*; (ii) the Gaussian attenuation factor is bounded by $(\mathbb E|Z|^\theta)^2/\mathbb E|Z|^{2\theta}$, strictly decreasing in $\theta$ (log-convexity of moments), degrading large-$\theta$ ACFs even when they exist. The precise location of the maximum near $\theta\approx1$ is then a quantitative outcome of the calibrated $(\nu,\ \text{persistence})$ pair — consistent with the GARCH-literature treatments of the Taylor property (Ding–Granger–Engle 1993; He–Teräsvirta 1999 ⚑ and successors). **No new architectural element is needed**: the Taylor effect is the joint signature of §3.2 and §3.5, and serves as a free out-of-sample diagnostic of the tail/persistence balance.

---

## 4. The corrected design philosophy: axes, not layers

The one-layer-per-fact picture does not survive the analysis, but a sharper and more defensible version of the same idea does. The stylized facts map onto **four (near-)orthogonal axes**, and the layered architecture is what makes each axis independently addressable:

1. **Kernel shape** ($a_j$ profile across the $\Lambda$-grid): roughness (fast end) and mid-band clustering (slow end) — one Laplace measure, two asymptotics.
2. **Loop gain and balance** ($\|K\|^2$ vs 1; $\kappa_{\rm eff}$ vs $\rho_c^2$): tail index $\nu$, hence fat tails — and, jointly with axis 1, the Taylor effect.
3. **Nonlinearity parity** (odd part of $\phi$ + readout monotonicity vs even part of $\phi$): leverage/weak Zumbach vs magnitude channel/strong Zumbach. The odd channel lives in Layer 1 + readout; the even channel *must* live in Layer 2 (Prop Z, Case A).
4. **Layer-2 timescales** ($A$, $W_{zr}$, $W_{zz}$): long-horizon clustering and the *lag structure* of the strong asymmetry.

This extends the manuscript's orthogonality principle (expressivity structure ⊥ control identity, [MS]): the deep ESN adds the parity axis and the slow-drift axis, and its layering is valuable exactly because it decouples the dials — not because layer $k$ "produces" fact $k$. Two facts are produced by no layer at all: fat tails and the Taylor effect belong to the **closed loop**.

---

## 5. Tensions and hard limits (what "yes" does not include)

1. **Moment regime forces the diagnostics** (amendment M2): with $\nu\in(3,5)$, $\mathbb E\sigma^4=\infty$ ⇒ use $m_q^{\log}$ for roughness, $\rho_1$ (not $\rho_2$) for clustering. Not a defect — it is the data's own moment regime — but every claim must be stated for objects that exist.
2. **Tails vs martingality:** the near-critical regime that generates $\nu\in(3,5)$ is exactly where Conjecture M (audit §9) matters most; the negative structural leverage $\rho_c<0$ is the favorable case but remains to be proven. Any pricing use is conditional on resolving it (or capping the readout for pricing runs).
3. **Single noise:** instantaneous spot–vol correlation $\equiv\pm1$ (audit P3). SSR and skew-dynamics diagnostics inherit this rigidity; if data demand imperfect correlation, an exogenous vol factor must be added (Guyon–Lekeufack's residual noise), at the cost of diluting endogeneity.
4. **Everything is window-limited:** roughness, power-law ACFs, and Pareto tails all hold over ranges set by $(\kappa_{\min},\kappa_{\max},N_r,A)$, with semimartingale micro-behavior and exponential/Gaussian far ends. This matches finite-sample data but must be stated (the audit's (S1) lesson generalizes).
5. **$\mathbb P/\mathbb Q$:** the tail/Taylor/Zumbach facts are $\mathbb P$-statistics; calibration to derivatives is $\mathbb Q$. The teacher-forcing route (audit Prop R(i)) fits the $\mathbb P$-facts; using the same reservoir for pricing requires an explicit risk-premium link (audit §7.5).

---

## 6. Theorem roadmap (what to prove, in order of value/effort)

- **R1 (done + one lemma).** Roughness & mid-band clustering: Prop A + Corollary; add Lemma L (log-vol transfer). *Effort: half a page.*
- **R2 (done).** Leverage/weak Zumbach: audit §7.2. *Formalize the frozen-linearized $L(\tau)$ as a proposition: one page.*
- **R3.** Strong Zumbach: with $\phi=\alpha\tanh+\beta\tanh^2$, compute $\mathcal Z(\Delta)$ at first order in $\beta$ (four-point machinery of [MS §9.2] on the linearized loop); target: $\mathcal Z=\mathcal Z_{\rm lev}+\beta\,\mathcal Z_{\rm mag}+O(\beta^2)$ with explicit kernels and signs. *Effort: the substantial one; reuses the manuscript's Prop 9.4-style computation.*
- **R4.** Tails: (a) rigorous scalar Proposition F (boundary classification + stationary density: standard 1-D diffusion theory); (b) multi-node conjecture + Hill-estimator numerics; (c) Breiman transfer lemma. *Effort: (a),(c) short; (b) numerics an afternoon, theory open.*
- **R5.** Taylor: moment-existence proposition + attenuation monotonicity (both proved sketch-level in §3.6); calibrate $(\nu,\text{persistence})$ and exhibit the $\theta$-profile numerically. *Effort: short.*
- **R6 (background).** Conjecture M (martingality, $\rho_c\le0$) — unchanged from the audit; becomes more urgent in the near-critical tail regime.

## 7. Direct answer

**Yes — with the two amendments.** All five facts on the list are reachable in the Case-A deep ESN, most of them with proofs already in hand or within reach (R1, R2, R4a/c, R5); the strong Zumbach is the one requiring both a design change (M1: even component in $\phi$ — non-negotiable, by Prop Z) and real work (R3). The deep/layered idea survives in corrected form: layers buy *addressability of orthogonal dials* (§4), and two of the five facts (tails, Taylor) are properties of the closed loop rather than of any layer — which is a feature: they come for free from the same near-critical regime, with (S) as the single stability/heaviness dial.

## 8. References (⚑ = verify exact bibliographic data before citing)

Cont (2001), *Empirical properties of asset returns: stylized facts and statistical issues*, QF 1(2), 223–236. Taylor (1986), *Modelling Financial Time Series*, Wiley. Ding–Granger–Engle (1993), *A long memory property of stock market returns and a new model*, J. Empirical Finance 1(1), 83–106. Gatheral–Jaisson–Rosenbaum (2018), QF 18(6), 933–949. Guyon–Lekeufack (2023), QF 23(9), 1221–1258. Blanc–Donier–Bouchaud (2017), QF 17(2), 171–188. El Euch–Gatheral–Radoičić–Rosenbaum (2020), QF 20(2), 235–241 ⚑. Gatheral–Jusselin–Rosenbaum (2020), *The quadratic rough Heston model and the joint S&P 500/VIX smile calibration problem*, Risk (Cutting Edge) / arXiv:2001.01789 ⚑. Nelson (1990), *ARCH models as diffusion approximations*, J. Econometrics 45, 7–38. Kesten (1973), Acta Math. 131, 207–248. Buraczewski–Damek–Mikosch (2016), *Stochastic Models with Power-Law Tails*, Springer. Breiman (1965), Theory Probab. Appl. 10(2), 323–331. Gopikrishnan–Plerou–Amaral–Meyer–Stanley (1999), Phys. Rev. E 60, 5305 ⚑. He–Teräsvirta (1999), *Properties of moments of a family of GARCH processes*, J. Econometrics 92, 173–192 ⚑ (Taylor-property GARCH literature). Internal: `deep_esn_architecture_audit.md` (Props A, S, Z, T1–T3, R, Conjecture M); [MS] §3.4, §9.1–9.2.
