# Full mathematical audit of `Deep_ESN_Volatility_Architecture.pdf`

*14 July 2026. Standalone document: expands and supersedes "Part II" of `second_moment_audit.md`. Numerical companion: `verify_second_moment.py` (check [8] is the direct test of Proposition A below). References to the manuscript `esn_signature_volterra_note.pdf` are tagged [MS, ·]; references to the Pallavicini review report are tagged [REV, ·]; each result borrowed from them is restated here so this document is self-contained.*

---

## 0. Executive verdict

The architecture note describes a two-layer, return-driven, continuous-time reservoir with a floored-softplus volatility readout. Its **structural skeleton is sound and provable**: the system is a well-posed Markovian SDE (no self-referential pathology), it is a *genuine* endogenous path-dependent-volatility (PDV) model (unlike the exogenous-reservoir construction it descends from), and pathwise non-explosion holds unconditionally. Its **three headline claims, as literally written, are not**: (i) "the exact target Hurst parameter is preserved" is false at fixed reservoir dimension and is anyway unsupported because the note never specifies the object that actually encodes $H$ (the kernel *weights*, not the eigenvalue grid); (ii) "prevents numerical explosions through bounded self-exciting mechanisms" conflates pathwise non-explosion (true, but the mechanism is *linear-growth*, not bounded) with moment stability (which silently requires a subcriticality condition, stated and proved below as (S)); (iii) "directly generating volatility clustering and the asymmetric Zumbach effect" misattributes clustering and the weak asymmetry (both already produced by Layer 1 + the readout) and leaves the strong asymmetry unproven — indeed *impossible* for the most natural choice of activation (odd $\phi$, e.g. tanh), by Proposition Z below. Each false claim has a correct, provable surrogate, stated here with hypotheses and proof; the strongest is Proposition A: **the entire self-excitation enters the second-order structure of the Layer-1 feature only through one scalar**, so the deterministic kernel-approximation theory applies verbatim — a cleaner and stronger statement than the one the note attempted.

Two specifications are missing from the note and are load-bearing; verdicts branch on them (§1.3):
- **(U1)** the diffusion term of the Layer-2 equation, truncated as "$+\dots$" in Eq (4);
- **(U2)** the activation $\phi_\mu$ in Eq (4) — in particular whether it has a nonzero even component.

---

## 1. The model as written, and the notation used throughout

### 1.1 The note's equations (for reference)

Using the note's own symbols: asset $dS_t/S_t=\mu_S\,dt+\sigma_t\,dW_t$; reservoir state $h_t\in\mathbb R^N$ driven by the "martingale differential" $dM_t=\sigma_t\,dW_t$,

$$dh_t=\mu(h_t)\,dt+\Sigma(h_t)\,(\sigma_t\,dW_t) \tag{D1}$$

$$\sigma_t=\sqrt{\sigma_{\min}^2+\big(\ln(1+e^{\,w_{\rm out}^\top h_t+b_{\rm out}})\big)^2} \tag{D2}$$

with the state partitioned $h_t=[r_t^\top,z_t^\top]^\top$ and

$$dr_t=-\Lambda r_t\,dt+c\,(\sigma_t\,dW_t) \tag{D3}$$

$$dz_t=\big(-Az_t+\phi_\mu(W_{zr}r_t+W_{zz}z_t)\big)\,dt+\dots \tag{D4}$$

### 1.2 Notation (every symbol defined here, used consistently below)

| Symbol | Definition |
|---|---|
| $W$ | one-dimensional standard Brownian motion on a filtered space $(\Omega,\mathcal F,(\mathcal F_t),\mathbb P)$; **note: scalar** — the whole model has a single noise source |
| $S_t$ | asset price, $dS_t/S_t=\mu_S\,dt+\sigma_t\,dW_t$, $S_0>0$; $\mu_S\in\mathbb R$ a known constant (measure convention in §1.3) |
| $\sigma_t,\ V_t$ | instantaneous volatility (readout, (D2)) and instantaneous variance $V_t:=\sigma_t^2$ |
| $M_t$ | martingale part of cumulative log-return: $M_t:=\int_0^t\sigma_s\,dW_s=\int_0^t(dS_s/S_s-\mu_S\,ds)$ |
| $r_t\in\mathbb R^{N_r}$ | Layer-1 state (D3) |
| $\Lambda=\mathrm{diag}(\kappa_1,\dots,\kappa_{N_r})$ | mean-reversion rates, $0<\kappa_1<\dots<\kappa_{N_r}$; the note prescribes a geometric grid; write $\kappa_{\min}=\kappa_1$, $\kappa_{\max}=\kappa_{N_r}$ |
| $c\in\mathbb R^{N_r}$ | Layer-1 input loading (constant vector) |
| $z_t\in\mathbb R^{N_z}$ | Layer-2 state (D4) |
| $A\in\mathbb R^{N_z\times N_z}$ | Layer-2 decay matrix; assumed to have positive-definite symmetric part: $a_z:=\lambda_{\min}\!\big(\tfrac12(A+A^\top)\big)>0$ (log-norm condition — eigenvalue stability alone does **not** give the bounds below when $A$ is non-normal; cf. [REV §10.1]) |
| $\phi_\mu=:\phi$ | Layer-2 activation, applied componentwise; standing assumption **(A1)**: $\phi$ bounded and globally Lipschitz (e.g. $\tanh$); its parity is unresolved specification **(U2)** |
| $W_{zr}\in\mathbb R^{N_z\times N_r},\ W_{zz}\in\mathbb R^{N_z\times N_z}$ | Layer-2 mixing matrices |
| $w_{\rm out}=(w_r,w_z)\in\mathbb R^{N_r}\times\mathbb R^{N_z},\ b_{\rm out}\in\mathbb R$ | readout weights and bias |
| $\mathrm{sp}(x)$ | softplus $\ln(1+e^x)$; recall $\mathrm{sp}(x)-\mathrm{sp}(-x)=x$ and $\mathrm{sp}(x)\le x^++\ln 2$ |
| $F(u)$ | readout activation $F(u):=\sqrt{\sigma_{\min}^2+\mathrm{sp}(u)^2}$, so $\sigma_t=F(u_t)$ |
| $u_t$ | readout argument $u_t:=w_r^\top r_t+w_z^\top z_t+b_{\rm out}$ |
| $X_t$ | Layer-1 readout feature $X_t:=w_r^\top r_t$ |
| $K(v)$ | Layer-1 readout kernel $K(v):=\sum_{j=1}^{N_r}a_j e^{-\kappa_j v}$ with weights $a_j:=w_{r,j}c_j$; $K(0)=w_r^\top c$ |
| $\|K\|_{L^2}^2$ | $\int_0^\infty K(v)^2dv=\sum_{j,k}\dfrac{a_ja_k}{\kappa_j+\kappa_k}$ |
| $\pi,\ \mathbb E_\pi$ | stationary law of $(r,z)$ (when it exists) and expectation under it |
| $\bar m$ | stationary mean-square volatility $\bar m:=\mathbb E_\pi[\sigma_t^2]$ |
| $m_2^Y(\Delta)$ | second-order structure function of a stationary process $Y$: $m_2^Y(\Delta):=\mathbb E[(Y_{t+\Delta}-Y_t)^2]$ |
| $H$ | Hurst exponent; "the structure function scales with exponent $2H$ on a window $I$" means $m_2(\Delta)=C\,\Delta^{2H}(1+o(1))$ uniformly for $\Delta\in I$ |
| $K_H,\ \mu_H$ | Riemann–Liouville kernel $K_H(v)=v^{H-1/2}/\Gamma(H+\tfrac12)$ and its Bernstein measure: $K_H(v)=\int_0^\infty e^{-xv}\mu_H(dx)$, $\mu_H(dx)=\dfrac{x^{-H-1/2}}{\Gamma(H+\frac12)\Gamma(\frac12-H)}dx$ for $H\in(0,\tfrac12)$ [MS, eq. (3.8)] |

**Properties of the readout activation (Lemma F).** $F\in C^\infty$; $\sigma_{\min}<F(u)$ for all $u$, with $F(u)\downarrow\sigma_{\min}$ as $u\to-\infty$ and $F(u)=u+O(1)$ as $u\to+\infty$ (linear growth); $0<F'(u)<\min\{\mathrm{sp}'(u),\,\mathrm{sp}(u)/\sigma_{\min}\}<1$, so $F$ is 1-Lipschitz and $F'(u)\to0$ *exponentially* as $u\to-\infty$; $F''$ is bounded. (Direct computation: $F'=\mathrm{sp}\cdot\mathrm{sp}'/F$ with $\mathrm{sp}/F\le1$, $\mathrm{sp}'=\text{sigmoid}<1$.)

### 1.3 Standing assumptions, unresolved specifications, and measure convention

- **(A1)** $\phi$ bounded, globally Lipschitz (componentwise).
- **(A2)** $a_z>0$ (log-norm stability of Layer 2, as defined above).
- **(U1) Layer-2 diffusion.** (D4) is truncated. Two cases are carried through:
  - **Case A (drift-only $z$):** the "$+\dots$" is absent. Then $z$ has $C^1$ paths and is deterministically bounded: $|z_t|\le e^{-a_z t}|z_0|+\|\phi\|_\infty/a_z$ (variation of constants + log-norm), and $|\dot z_t|\le\|A\|\,\sup_s|z_s|+\|\phi\|_\infty=:L_z<\infty$.
  - **Case B ($z$ carries $dM$-noise, $dz=(\cdot)\,dt+\Sigma_z(h)\,dM_t$, $\Sigma_z$ Lipschitz):** $z$ is a semimartingale; several conclusions change and are flagged where they do.
- **(U2) Parity of $\phi$.** Whether $\phi$ has a nonzero even component (e.g. $\tanh$ is odd; a GELU-type or $\tanh^2$ term is not). Decisive for §7.
- **Measure convention.** All dynamics and expectations are under the measure in which the model is *simulated*; where a martingale normalization is needed (§7, §9) we set $\mu_S=0$ (equivalently work with the discounted/forward asset under a pricing measure $\mathbb Q$). The note itself writes a $\mathbb P$-style drift $\mu_S$ but never states the measure; the $\mathbb P$-vs-$\mathbb Q$ consequences are collected in §7.5.

---

## 2. Claim inventory

Every claim in the note, indexed by location. Verdicts: ✓ = correct and provable; ✓* = correct under stated hypotheses supplied here; ✗ = false as stated; ◑ = not provable as stated (under-specified or misattributed); **O** = genuinely open.

| ID | Location | Claim (paraphrase) | Verdict | Where treated |
|---|---|---|---|---|
| C1 | Abstract | ESN embedded in an SDE; reservoir = CDE driven by the martingale part of returns | ✓ | §3 (P1) |
| C2 | Abstract, §3 | "dynamically generates rough volatility signatures" | ◑→✓* | §4 |
| C3 | Abstract, §3.2, §4 | "captures the Zumbach effect" / "directly generating … the asymmetric Zumbach effect" | ◑ / ✗ for odd $\phi$ | §7 |
| C4 | Abstract, §2 | "prevents numerical explosions through **bounded** self-exciting mechanisms" | ✗ wording; ✓ pathwise; ✓* moments | §3 (P4), §5 |
| C5 | §1 | "fully **autonomous**, self-exciting volatility model" | ✗ terminology | §3.5 |
| C6 | §1 | "volatility extracted via a trained **linear** readout" | ✓* (affine readout ∘ fixed activation) | §8 |
| C7 | §1 | "endogenous feedback loop capturing path-dependence while remaining Markovian in $(S_t,h_t)$" | ✓ | §3 (P2) |
| C8 | §2 | soft floor stabilizes "without killing optimization gradients" | ✗ as absolute | §5.4 |
| C9 | §2 | unbounded upper tail avoids exponential explosion | ✓ (P1/P4) | §3, §5 |
| C10 | §2 | $\sigma\ge\sigma_{\min}$ prevents collapse "and structural freezing of the SDE" | ✓ for the price / ✗ for the vol dynamics | §5.4 |
| C11 | §3 | roughness + Zumbach "require multi-scale fractional memory and dense non-linear crosstalk" | ◑ (right instinct, wrong objects) | §4.4, §7 |
| C12 | §3 | "a single dense matrix smears the relaxation spectrum, destroying the required power-law decay" | ✗ as stated | §6.3 |
| C13 | §3 | block-triangular CDE "isomorphic to a continuous-time Deep ESN"; "forward-flowing layers" | ◑ (true at drift level only) | §6.1 |
| C14 | §3.1 | Layer 1 = "decoupled bank of **linear OU** processes" | ✗ strictly / ✓ as linear filter of $M$ | §4.1 |
| C15 | §3.1 | "Because there is no cross-talk, **the exact target Hurst parameter is preserved**" | ✗; surrogate ✓ (Prop A) | §4 |
| C16 | §3.2 | Layer 2 "extracts cross-correlations to capture the directional impact of historical shocks" | ◑ (needs (U1),(U2)) | §7 |
| C17 | §3.2 | "$W_{zr}$ facilitates the transfer of excitations from 'fast' nodes to 'slow' nodes" | ✗ wording | §7.4 |
| C18 | §3.2, §4 | Layer 2 "directly generating volatility clustering" | ✗ ("directly"/misattributed) | §7.4 |
| C19 | §4 | "independent spectral decoupling" | ◑; ✓ at second-moment level (Prop A) | §6.1 |
| C20 | §4 | "**Roughness is tuned by the diagonal matrix $\Lambda$**" | ✗ ($\Lambda$ = band; weights = slope) | §4.4 |
| C21 | §4 | "asymmetry is controlled by the dense mixing matrices $W_{zr},W_{zz}$" | ◑ | §7 |
| C22 | §4 | "Optimization is isolated entirely to the final static readout $w_{\rm out}$ … highly efficient" | ✓ under $\mathbb P$ teacher-forcing / ✗ under $\mathbb Q$ simulation | §8 |
| — | (implicit) | prices are well-defined ($S$ a true martingale under pricing measure) | **O** (conjecture + route) | §9 |

---

## 3. Structural results that hold (P1–P4)

These four propositions establish what the note gets *right*, in sharpened form.

**Proposition P1 (well-posedness; no self-referential pathology).** Under (A1), (A2) and either Case A or Case B, the system $(r,z)$ with $\sigma=F(u)$ has globally Lipschitz drift and diffusion of linear growth; hence a unique global strong solution exists for every initial condition and every horizon. Given $(r,z)$, $\log S_t=\log S_0+\int_0^t(\mu_S-\tfrac12\sigma_s^2)\,ds+M_t$ is defined pathwise and $S_t>0$.

*Proof.* Drift of $(r,z)$: linear plus $\phi\circ(\text{affine})$, globally Lipschitz by (A1). Diffusion rows: $c\,F(u)$ for $r$ (and $\Sigma_z(h)F(u)$ in Case B): $F$ is 1-Lipschitz (Lemma F), so $h\mapsto F(w_{\rm out}^\top h+b_{\rm out})$ is $\|w_{\rm out}\|$-Lipschitz with linear growth. Standard existence/uniqueness for Lipschitz SDEs applies. $\sigma$ has continuous paths, so $\int_0^t\sigma_s^2ds<\infty$ a.s. and the exponential defining $S$ is finite. ∎

*Remark (why this matters).* The construction *looks* self-referential ($\sigma$ sits inside its own driver), and for genuinely path-dependent formulations well-posedness is a real obstacle ([REV §9.1] raises exactly this for price-driven reservoirs). Here the loop is resolved for free because the closed system $(\log S,r,z)$ is a finite-dimensional Markovian SDE — this deserves to be *stated* in the note, since it is one of its genuine advantages.

**Proposition P2 (genuine endogenous PDV + Markov property) — claim C7 is true.** (i) $h=(r,z)$ is a Markov process, and so is $(S,h)$. (ii) With $\mu_S$ known, $M_t=\int_0^t dS_s/S_s-\mu_S t$ is a measurable functional of $\{S_u\}_{u\le t}$; hence
$$r_t=e^{-\Lambda t}r_0+\int_0^t e^{-\Lambda(t-s)}c\,dM_s,$$
$z_t$ (solving the ODE (D4)-Case-A driven by $r$), and therefore $V_t=F(u_t)^2$, are measurable functionals of the price path $\{S_u\}_{u\le t}$ (given $h_0$). The model is endogenous PDV in the Guyon–Lekeufack sense: volatility is a functional of the asset's own history, and the leverage is *structural*, not a free correlation parameter.

*Proof.* (i) The coefficients of $(r,z)$ depend on $(r,z)$ only. (ii) Composition of measurable maps; the stochastic integral against $dM$ is a pathwise (Riemann–Stieltjes after integration by parts, since $e^{-\Lambda(t-s)}c$ is $C^1$ in $s$) functional of $M$. ∎

*Contrast.* The Pallavicini reservoir is driven by exogenous Brownian noise and is **not** a functional of the price path ([REV §3.1–3.2]); this architecture fixes precisely that defect. This is the note's single strongest structural feature and it never states it.

**Proposition P3 (one noise ⇒ correlation is a sign, and explicit local second-order geometry; Case A).** With $\rho_c:=w_r^\top c=K(0)$:
$$d\langle u\rangle_t=\rho_c^2\,\sigma_t^2\,dt,\qquad d\langle\sigma\rangle_t=F'(u_t)^2\rho_c^2\,\sigma_t^2\,dt,\qquad d\langle V\rangle_t=4F'(u_t)^2\rho_c^2\,\sigma_t^4\,dt,$$
$$d\langle\log S,\sigma\rangle_t=F'(u_t)\,\rho_c\,\sigma_t^2\,dt,\qquad \mathrm{corr}_t(d\log S,d\sigma)\equiv\mathrm{sign}(\rho_c)\in\{-1,+1\}.$$

*Proof.* $du=(\dots)dt+\rho_c\sigma\,dW$ since $z$ contributes no quadratic variation in Case A; Itô on $\sigma=F(u)$, $V=F(u)^2$; the correlation is the ratio of the covariation to the product of the two volatilities, and $F'>0$. ∎

*Consequences worth stating explicitly.* (a) The instantaneous **lognormal vol-of-variance** is $\sqrt{d\langle V\rangle/V^2\,dt}=2F'(u_t)|\rho_c|$: bounded by $2|\rho_c|$, approximately constant in the linear regime ($F'\approx1$) — Bergomi-type variance-proportional scaling, the right ingredient for an upward-sloping VIX-call smile — and it *switches off* near the floor ($F'\to0$): see C10, §5.4. (b) Perfect instantaneous spot–vol correlation is intrinsic to any single-noise PDV; if the data demand imperfect correlation, an exogenous vol noise must be added (Guyon–Lekeufack's "mostly"). In Case B the correlation is state-dependent but still determined by the architecture, never a free $\rho$.

**Proposition P4 (unconditional pathwise non-explosion) — the true content of C4/C9.** For every parameter choice and horizon, the paths of $(r,z,\sigma,S)$ neither explode nor hit zero volatility: $\sigma_t\in[\sigma_{\min},\infty)$ and $\sup_{t\le T}(|r_t|+|z_t|)<\infty$ a.s. *Proof:* immediate from P1 (global Lipschitz ⇒ no finite-time blow-up) and $F\ge\sigma_{\min}$. ∎

*But:* "bounded self-exciting mechanism" is the wrong description — the excitation $F$ has **linear growth**, and it is exactly this (global Lipschitzness), not boundedness, that delivers P4. What linear growth does **not** deliver is moment stability; that is §5.

### 3.5 Terminology (claim C5)

"Fully autonomous" clashes with the established taxonomy in [MS]/[REV], where *autonomous* means a reservoir with **no input channel** (the Pallavicini case) and the opposite regime — the one realized here, with returns in the control path — is *input-driven*. Since the note's whole point is that the reservoir **is** driven by the return martingale, the accurate word is **endogenous** (or input-driven/self-excited). As written, the abstract claims the opposite of what the equations do.

---

## 4. The central roughness claim (C14, C15, C20, C2)

### 4.1 What the note claims, and what we set out to prove/check/disprove

The note asserts (§3.1, §4): Layer 1 is "a decoupled bank of linear OU processes"; "because there is no cross-talk, the exact target Hurst parameter is preserved"; "roughness is tuned by the diagonal matrix $\Lambda$". We formalize this as three statements:

- **(S1)** *Pathwise/small-scale:* for fixed $N_r$, the process $\sigma$ (equivalently $V$, or the feature $X$) has small-scale scaling exponent $H_{\rm target}<\tfrac12$: $m_2(\Delta)\asymp\Delta^{2H_{\rm target}}$ as $\Delta\downarrow0$.
- **(S2)** *Window/second-moment:* $m_2^X(\Delta)\propto\Delta^{2H_{\rm target}}$ on an intermediate window of lags, **unaffected by the self-excitation and by Layer 2**.
- **(S3)** *Attribution:* the exponent $H_{\rm target}$ is determined by $\Lambda$ (the eigenvalue grid).

Verdicts, proved below: **(S1) false** for any fixed $N_r$ with $\rho_c\neq0$; **(S2) true, exactly** — this is Proposition A, and it is *stronger* than what the note needed; **(S3) false** — $\Lambda$ fixes only the *window*; the exponent is encoded in the weights $a_j=w_{r,j}c_j$, an object the note never specifies.

Also on record: (C14) Layer 1 is not a bank of OU processes strictly speaking — with $\sigma_t$ state-dependent the components $r^j$ are neither Gaussian nor mutually independent. What *is* exactly true, and is the correct content of "no cross-talk": $r$ is a **linear filter of the return martingale**, $r_t=e^{-\Lambda t}r_0+\int_0^te^{-\Lambda(t-s)}c\,dM_s$, whatever Layer 2 and the feedback do. The *filter* is unpolluted; the *law of its input* is shared.

### 4.2 Proposition A (exact stationary second-moment identity)

**Hypotheses.** Case A or Case B; $(r,z)$ admits a stationary law $\pi$ with $\bar m=\mathbb E_\pi[\sigma^2]<\infty$ (sufficient conditions: §5). Work with the stationary two-sided version $r_t=\int_{-\infty}^te^{-\Lambda(t-s)}c\,dM_s$; for a finite start the statements hold up to transients $O(e^{-2\kappa_{\min}t})$.

**Statement.** For every $\Delta>0$,
$$m_2^X(\Delta)\;=\;\bar m\;Q_K(\Delta),\qquad Q_K(\Delta):=\int_0^\Delta K(v)^2\,dv+\int_0^\infty\big(K(v+\Delta)-K(v)\big)^2\,dv. \tag{A}$$
Equivalently $\mathrm{Var}_\pi(X)=\bar m\,\|K\|_{L^2}^2$ and $\mathrm{Cov}(X_t,X_{t+\Delta})=\bar m\int_0^\infty K(v)K(v+\Delta)\,dv$, with $m_2=2(\mathrm{Var}-\mathrm{Cov})$.

**Proof.** Write $X_{t+\Delta}-X_t=\int_t^{t+\Delta}K(t+\Delta-s)\,dM_s+\int_{-\infty}^t\big[K(t+\Delta-s)-K(t-s)\big]\,dM_s$. The second term is $\mathcal F_t$-measurable and square-integrable ($K\in L^2$, $\bar m<\infty$); the first has zero $\mathcal F_t$-conditional mean, so their product has zero expectation (tower property): the cross term vanishes. Itô isometry with the predictable integrand $\sigma_s$ gives, for each term, $\int f(s)^2\,\mathbb E[\sigma_s^2]\,ds$; stationarity replaces $\mathbb E[\sigma_s^2]$ by the constant $\bar m$, and the change of variables $v=t+\Delta-s$ (resp. $v=t-s$) yields (A). ∎

**Reading.** *The entire self-excitation — Layer-2 feedback included — enters the second-order structure of the Layer-1 feature only through the scalar $\bar m$.* Everything fractional therefore reduces to the deterministic kernel functional $Q_K$, i.e. to classical kernel-approximation theory. Two remarks:

1. This works **because all nodes share the single driver $dM$**. It places the architecture on the *common-driver / pathwise* side of the dichotomy in [MS, eq. (3.11) and caveat (ii) of §3.4]: a superposition of OU factors with a *common* Brownian is an $L^2$ *pathwise* approximation of the Volterra process $\int K_H\,dM$, whereas *independent* per-node noises (the Pallavicini diagonal-$\Sigma$ design) reproduce only the autocovariance in distribution. The note's design choice is the right one; the note never says why.
2. Identity (A) is measure-agnostic: it holds under whichever measure $(r,z)$ is stationary, with the corresponding $\bar m$.

### 4.3 Corollary (three regimes, explicit constants)

For $K(v)=\sum_ja_je^{-\kappa_jv}$,
$$Q_K(\Delta)=\sum_{j,k}\frac{a_ja_k}{\kappa_j+\kappa_k}\Big[\big(1-e^{-(\kappa_j+\kappa_k)\Delta}\big)+\big(1-e^{-\kappa_j\Delta}\big)\big(1-e^{-\kappa_k\Delta}\big)\Big],$$
whence, under the hypotheses of Prop A:

- **Micro** ($\Delta\lesssim\kappa_{\max}^{-1}$): $m_2^X(\Delta)=\bar m\,K(0)^2\,\Delta+O(\Delta^2)$ — the infinitesimal Hurst exponent is $\tfrac12$ whenever $K(0)=w_r^\top c\neq0$. This **disproves (S1)**: it is the input-driven instance of the general semimartingale fact restated from [MS, eq. (3.10)]: any $C^2$ readout of a finite-dimensional Itô diffusion has $\lim_{\Delta\downarrow0}\Delta^{-1}\mathbb E[(V_{t+\Delta}-V_t)^2|\mathcal F_t]=\|\Sigma^\top\nabla g\|^2$, i.e. $H_{\rm inf}=\tfrac12$. (Degenerate curiosity: if the weights are tuned so $w_r^\top c=0$, the leading martingale parts cancel and $X$ is *micro-smooth* while still window-rough.)
- **Window** ($\kappa_{\max}^{-1}\lesssim\Delta\lesssim\kappa_{\min}^{-1}$): if the weights implement the Bernstein–Laplace quadrature of $\mu_H$ — on a log-grid, $a_j\propto\kappa_j^{1/2-H}$, all positive — then
$$m_2^X(\Delta)=\bar m\,c_H\,\Delta^{2H}\big(1+\varepsilon_N(\Delta)\big),\qquad c_H=\frac{1}{2H}+\int_0^\infty\!\big((1+s)^{H-\frac12}-s^{H-\frac12}\big)^2ds,$$
(the exact identity $Q_{K_H}(\Delta)=c_H\Delta^{2H}$ holds for the ideal kernel by scaling), with $\varepsilon_N$ controlled by the kernel error $\|K-K_H\|_{L^2(0,T)}$; convergence rates are the multifactor-approximation ones — algebraic in $N_r$ for a naive log-grid, geometric for optimized nodes (Carmona–Coutin–Montseny; Abi Jaber–El Euch; Bayer–Breneis; Alfonsi–Kebaier).
- **Macro** ($\Delta\gtrsim\kappa_{\min}^{-1}$): saturation, $m_2^X(\Delta)\to2\,\mathrm{Var}_\pi(X)=2\bar m\|K\|_{L^2}^2$.

### 4.4 Where $H$ actually lives (disproof of S3 / C20), and "permitted vs enforced"

By the Corollary, the exponent on the window is the decay profile of the **weights** $a_j=w_{r,j}c_j$ across the grid ($a_j\propto\kappa_j^{1/2-H}$), while $\Lambda$ only sets the window endpoints $[\kappa_{\max}^{-1},\kappa_{\min}^{-1}]$. The note specifies "geometrically spaced eigenvalues" and says nothing about $c$ or $w_r$: **as written, nothing in the architecture selects any $H$ at all.** "Roughness is tuned by $\Lambda$" (C20) is therefore false in the operative sense; the correct sentence is: *"$\Lambda$ fixes the scaling window; the target $H$ is imposed by choosing the input/readout weight profile $a_j\propto\kappa_j^{1/2-H}$, the Laplace-quadrature weights of $\mu_H$."*

Moreover, since $w_r$ is a *trained* quantity, even a correctly specified $c_j\propto\kappa_j^{1/2-H}$ makes the architecture **permit** the target $H$ rather than **enforce** it: calibration to prices may tilt the effective weights and change the measured exponent. The clean diagnostic is the two-way ablation restated from [REV §10.4]: (fix $w_r$, measure $H$) versus (constrain the spectral tilt of $w_r$, measure the price fit). Recommended for any empirical claim built on this architecture.

### 4.5 Numerical confirmation

`verify_second_moment.py`, check [8]: the feedback loop simulated as written (Euler, $dt=10^{-3}$, $N_r=6$, log-grid $\kappa\in[1,50]$, $a_j\propto\kappa_j^{0.35}$ i.e. $H=0.15$, subcritical $2\|K\|^2=0.30$), the ratio $m_2^{\rm MC}(\Delta)/(\bar m\,Q_K(\Delta))$ across three decades:

| $\Delta$ | 0.002 | 0.010 | 0.050 | 0.200 | 1.000 | 4.000 |
|---|---|---|---|---|---|---|
| ratio | 1.023 | 1.021 | 1.018 | 1.013 | 1.012 | 1.012 |

Flat to 1–2%, micro through macro; the residual is the $O(dt)$ weak bias of the Euler step, not a failure of (A).

### 4.6 Verdict on C15/C2

"The exact target Hurst parameter is preserved" — **false three times over** ((S1) fails at fixed $N_r$; the exponent-selecting weights are unspecified; "no cross-talk" is untrue dynamically, since $z$ modulates Layer 1's driver through $\sigma$) — **but the intended content is salvageable in a stronger form**: Proposition A shows the second-order structure is *exactly* the deterministic kernel functional times $\bar m$, so the target $H$ is reproduced on $[\kappa_{\max}^{-1},\kappa_{\min}^{-1}]$ up to quadrature error, is $\tfrac12$ below the window, saturates above it, and becomes exact only in the joint limit $N_r\to\infty,\ \kappa_{\max}\to\infty$. That sentence is what the note should say.

---

## 5. Stability claims (C4, C8, C9, C10)

### 5.1 Formalization

Three different properties are conflated by "prevents numerical explosions":
- **(E-path)** no finite-time explosion of paths — **holds unconditionally** (P4);
- **(E-mom)** $\sup_t\mathbb E[\sigma_t^2]<\infty$ and existence of a stationary regime — **conditional**, see (S) below;
- **(E-mart)** the discounted price is a true martingale — **open**, §9.

### 5.2 Proposition S (moment subcriticality)

**Statement.** Case A, (A1)–(A2). If
$$\textbf{(S)}\qquad \|K\|_{L^2(0,\infty)}^2=\sum_{j,k}\frac{a_ja_k}{\kappa_j+\kappa_k}\;<\;1,$$
then $\sup_{t\ge0}\mathbb E[\sigma_t^2]<\infty$ for every initial condition, and any stationary law satisfies $\bar m\le C/(1-\theta)$ for explicit $C<\infty$, $\theta<1$.

**Proof.** (i) *A priori stationary bound.* By Prop A's isometry, $\mathbb E_\pi[X^2]=\bar m\|K\|^2$. From $\mathrm{sp}(x)\le x^++\ln2$: for any $\varepsilon>0$, $\mathrm{sp}(x)^2\le(1+\varepsilon)x^2+C_\varepsilon$. In Case A, $|w_z^\top z+b_{\rm out}|\le C_z$ deterministically, so $u^2\le(1+\varepsilon)X^2+C'_\varepsilon$. Hence
$$\bar m=\sigma_{\min}^2+\mathbb E_\pi[\mathrm{sp}(u)^2]\le C''_\varepsilon+(1+\varepsilon)^2\|K\|^2\,\bar m,$$
which is a finite bound as soon as $(1+\varepsilon)^2\|K\|^2<1$; let $\varepsilon\downarrow0$ to get the condition (S). (ii) *Non-stationary version.* With $m(t):=\mathbb E[\sigma_t^2]$, the finite-start isometry gives $\mathbb E[X_t^2]\le\text{(transient)}+\int_0^tK(t-s)^2m(s)\,ds$, hence the linear Volterra inequality $m(t)\le C+(1+\varepsilon)^2\int_0^tK(t-s)^2m(s)\,ds$ whose kernel has $L^1$-norm $(1+\varepsilon)^2\|K\|^2<1$; the resolvent kernel is then summable and $\sup_tm(t)<\infty$ (renewal/comparison). ∎

**Remarks.** (a) The cruder bound $\mathrm{sp}(x)^2\le2\ln^22+2x^2$ yields the weaker sufficient condition $2\|K\|^2<1$; (S) as stated is the sharp version of this argument. (b) (S) is *sufficient, not necessary*; the true threshold is open (heuristically, in the one-sided regime $\mathrm{sp}(u)^2\approx(u^+)^2$ the second-moment map is a linear Volterra equation with kernel $K^2$ and criticality at $\|K\|^2=1$, but the symmetric part of the law of $u$ relaxes this). (c) $p$-th-moment analogues $(\mathrm S_p)$ follow the same pattern with BDG constants; $\mathbb E_\pi[\sigma^4]<\infty$ is the hypothesis (H1) used in §6.2. (d) **The note needs (S) and never states it**: if (S)-type control fails, $\mathbb E[\sigma_t^2]$ can grow exponentially even though paths never explode (P4) — every stationarity-based diagnostic (structure functions, ACFs, calibration targets) would then be a non-stationary artifact.

### 5.3 Ergodicity (sketch, for completeness of the "stationary $\pi$" hypothesis)

Under (S), $\mathcal V(r,z)=|r|^2+|z|^2$ is a Lyapunov function (drift condition from the same computation). Irreducibility is the delicate part in Case A because the diffusion is **rank one** (the single field $g(h)=(cF(u),0)$): one checks Hörmander's condition via iterated brackets — $[b,g]$ produces the directions $\Lambda c$ (and $\phi'\cdot W_{zr}c$ in the $z$-block), and $\{\Lambda^kc\}_{k\ge0}$ spans $\mathbb R^{N_r}$ by a Vandermonde argument whenever the $\kappa_j$ are distinct and $c_j\neq0$ for all $j$; a spanning condition on $(A,W_{zr},W_{zz})$ then propagates to the $z$-block. Under these generic conditions: hypoellipticity + Lyapunov ⇒ unique invariant law and geometric ergodicity (Meyn–Tweedie/Khasminskii machinery). Stated here as a proposition-with-generic-hypotheses; a fully explicit spanning condition is routine but lengthy.

### 5.4 The floor: what it does and does not do (C8, C10)

- $\sigma\ge\sigma_{\min}$: trivially true; the *price* driver never degenerates — "structural freezing of the SDE" is prevented **for $S$**. ✓
- But by P3, $d\langle\sigma\rangle_t=F'(u_t)^2\rho_c^2\sigma_t^2\,dt$ and $F'(u)\to0$ exponentially as $u\to-\infty$: near the floor the **volatility dynamics themselves freeze** — a *sticky floor*. Not absorbing (the state $r$ keeps moving since the driver has $\sigma\ge\sigma_{\min}$, so $u$ re-emerges), but the claim "preventing structural freezing" is exactly wrong for the vol process. C10: half true.
- Same mechanism kills C8: calibration gradients through the readout carry the factor $F'(u)$, which vanishes exponentially in the low-vol regime. "Without killing optimization gradients" holds only in the operating regime $u\gtrsim0$.
- Pricing consequence worth recording: $\mathrm{VIX}_T^2=\mathbb E_T\big[\tfrac1\tau\int_T^{T+\tau}V_s\,ds\big]\ge\sigma_{\min}^2$, a hard floor $\mathrm{VIX}\ge100\,\sigma_{\min}$ — a constraint on low VIX strikes that must be checked against data before choosing $\sigma_{\min}$.

---

## 6. "Decoupling": three inequivalent meanings (C12, C13, C19) and the transfer to $\sigma$

### 6.1 What is and is not decoupled

- **Drift level:** the drift Jacobian is block-triangular ($r$-equation does not read $z$). ✓ — this is the honest content of "forward-flowing".
- **Pathwise/law level:** ✗ — $z$ enters Layer 1's *diffusion* through $\sigma$ in the common driver; the layers are dynamically coupled. What survives exactly is the *filter* $M\mapsto r$ (P2).
- **Second-moment level:** ✓ and exact — Proposition A: Layer 2 (and all feedback) touches $m_2^X$ only through $\bar m$. This is the correct formalization of C19, and it is the strongest true statement available.

"Isomorphic to a continuous-time Deep ESN" (C13) is informal but harmless once the above is stated; in CDE language, Layer 1 has a *constant* vector field on the control channel $M$ (hence commuting, level-one signature content only), and Layer 2 has *no* control channel — all higher-order path information enters via drift-mediated time integrals, not stochastic (Lévy-area) integrals. This locates the design precisely in the expressivity classification of [MS §3/§6]: it deliberately renounces bracket-generating control fields.

### 6.2 Transfer through the readout: from $X$ to $u$, $\sigma$, $V$

Definitions as in §1.2; throughout, Case A, Prop A hypotheses, and where stated **(H1)** $\mathbb E_\pi[\sigma^4]<\infty$ (a $(\mathrm S_4)$-type condition suffices).

**Lemma z ($z$ is smooth and slow).** In Case A, $z\in C^1$ pathwise with $|\dot z_t|\le L_z$, hence $\mathbb E[(w_z^\top(z_{t+\Delta}-z_t))^2]\le\|w_z\|^2L_z^2\,\Delta^2$.

**Proposition T1 (exponent decoupling for $u$).** $\big|\,m_2^u(\Delta)^{1/2}-m_2^X(\Delta)^{1/2}\big|\le\|w_z\|L_z\Delta$ (Minkowski + Lemma z). On the scaling window, where $m_2^X\asymp\Delta^{2H}$, this gives $m_2^u(\Delta)=m_2^X(\Delta)\big(1+O(\Delta^{1-H})\big)$: **Layer 2 contributes level, not small-scale structure**. (In Case B this fails: a $dM$-driven $z$ adds its own $O(\Delta)$ semimartingale term in the micro regime and modifies $K$ effectively — one more reason (U1) is load-bearing.)

**Proposition T2 (exact micro rate for $\sigma$ and $V$).** Under (H1),
$$\lim_{\Delta\downarrow0}\frac{m_2^\sigma(\Delta)}{\Delta}=\rho_c^2\,\mathbb E_\pi\big[F'(u_t)^2\sigma_t^2\big],\qquad \lim_{\Delta\downarrow0}\frac{m_2^V(\Delta)}{\Delta}=4\rho_c^2\,\mathbb E_\pi\big[F'(u_t)^2\sigma_t^4\big].$$
*Proof sketch.* Itô on $F(u)$, $F(u)^2$ (P3 gives the QV rates); the drift and cross terms are $O(\Delta^2),O(\Delta^{3/2})$ and are dominated using (H1) and boundedness of $F',F''$. ∎ — So $\sigma$ and $V$ are micro-$H=\tfrac12$ too, quantitatively.

**Proposition T3 (band slope transfer — stated with its honest hypotheses).** Assume additionally **(H2)**: there exist $f_0>0$ and $\eta\in[0,1)$ with $\pi\big(F'(u_t)\ge f_0\big)\ge1-\eta$. Then on the scaling window,
$$f_0^2\,(1-\eta')\;m_2^u(\Delta)\;\lesssim\;m_2^\sigma(\Delta)\;\le\;m_2^u(\Delta),$$
where $\eta'\to\eta$-controlled tail terms are bounded via Cauchy–Schwarz and fourth moments (H1); consequently the log-log slope of $m_2^\sigma$ on the window equals that of $m_2^X$ up to $o(1)$-in-window terms. *Proof sketch.* Upper bound: $F$ is 1-Lipschitz. Lower: second-order Taylor $F(u')-F(u)=F'(u)\delta+\tfrac12F''(\xi)\delta^2$ with $\delta=u'-u$; the remainder contributes $\mathbb E|\delta|^3\le(\mathbb E\delta^4)^{3/4}\lesssim m_2^u(\Delta)^{3/2}$ (BDG + (H1)) $=o(m_2^u)$ on the window; the main term is bounded below by restricting to $\{F'(u_t)\ge f_0\}$ and controlling the complementary event by Cauchy–Schwarz. ∎ — **What is deliberately *not* claimed:** equality of multiplicative constants (they differ: $\mathbb E[F'(u_t)^2\,\cdot\,]$ weights the increments), or anything near the floor, where (H2) fails by design (F′ collapses — the sticky-floor regime is genuinely *smoother*).

### 6.3 The "smearing" sentence (C12)

"A single dense matrix smears the relaxation spectrum, destroying the required power-law decay" — false as a statement about density: a dense **normal** $A_{\rm dense}=O\,\mathrm{diag}(-\kappa)\,O^\top$ (orthogonal $O$) carries *any* prescribed relaxation spectrum. The two true statements hiding underneath: (i) with a **random** dense matrix one controls neither eigenvalues nor (more importantly) the *residues* — the effective kernel $K(v)=w_r^\top e^{-A_{\rm dense}v}c$ is still a sum of exponentials, but its weights are no longer a targeted Laplace quadrature, so the $H$-selection of §4.4 is lost; (ii) for **non-normal** $A_{\rm dense}$, eigenvalues do not control transients — growth over finite horizons is governed by the numerical abscissa $\lambda_{\max}(\tfrac12(A+A^\top))$ and the pseudospectrum, which can be positive with all eigenvalues stable ([REV §10.1] gives an explicit $2\times2$ cascade example). The corrected sentence: *"an uncontrolled dense drift loses the weight/quadrature structure that encodes $H$, and non-normal mixing adds transient amplification; a diagonal Layer 1 keeps the kernel weights addressable."*

---

## 7. The Zumbach and clustering claims (C3, C11, C16–C18, C21)

### 7.1 Definitions (fixed before use)

For window $\delta>0$, the (martingale-part) return $r_{t,\delta}:=\int_t^{t+\delta}\sigma_s\,dW_s=M_{t+\delta}-M_t$. The **Zumbach statistic** at lag $\Delta>\delta$:
$$\mathcal Z(\Delta):=\mathbb E\big[r_{t+\Delta,\delta}^2\,r_{t,\delta}\big]-\mathbb E\big[r_{t+\Delta,\delta}\,r_{t,\delta}^2\big],$$
the time-reversal asymmetry of the (return, squared-return) cross-correlation (Zumbach 2009; the note's Eq (23)-style convention). Following the weak/strong distinction (El Euch–Gatheral–Radoičić–Rosenbaum 2020; [MS §9.2]): the **weak** effect is $\mathcal Z\neq0$ (a two-/three-point, sign-sensitive statement, producible by a leverage channel alone); the **strong** effect is the asymmetry of the *conditional law* — operationally, that past **trend magnitude** forecasts future volatility beyond past volatility, requiring a *quadratic/sign-folded* feature of past returns ($R_2$-type; quadratic-Hawkes class, Blanc–Donier–Bouchaud 2017; the sign-folding engine of [MS §4–5, Cor 5.2]).

**Sign-folding (definition).** A volatility functional exhibits sign-folding if its response to the driving trend is even around an interior minimum: both large up- and large down-trends raise volatility. Formally, for the trend feature $O$ (defined below): the map $x\mapsto$ (vol response at $O=x$) attains an interior minimum and increases in $|x-x^*|$ on both sides.

### 7.2 What the architecture provably delivers: the weak channel, from Layer 1 alone

Take the martingale normalization $\mu_S=0$ (§1.3). Then:

**(i) One-sidedness is exact.** For $\tau<0$, $\mathrm{Cov}(r_{t,\delta},V_{t+\tau})=0$ exactly ($V_{t+\tau}$ is $\mathcal F_t$-measurable; $r_{t,\delta}$ is a martingale increment after $t$). Likewise the second term of $\mathcal Z$ vanishes identically: $\mathbb E[r_{t+\Delta,\delta}\,r_{t,\delta}^2]=\mathbb E[r_{t,\delta}^2\,\mathbb E_{t+\Delta}[r_{t+\Delta,\delta}]]=0$. Hence under the pricing measure $\mathcal Z(\Delta)=\mathbb E[r^2_{t+\Delta,\delta}r_{t,\delta}]$: **the entire statistic is the leverage channel.**

**(ii) First-order leverage formula.** In the frozen/linearized regime (freeze $\sigma\approx\bar\sigma$ in the driver, linearize $V=F(u)^2$ at the operating point $\bar u$, Case A), the analogue of the linear-Gaussian leverage function [MS, eq. (9.13)] is
$$L(\tau):=\mathrm{Cov}\big(r_{t,\delta},V_{t+\tau}\big)\;\approx\;\delta\,\bar\sigma^2\,\underbrace{2F(\bar u)F'(\bar u)}_{=:G'(\bar u)}\,\big[K(\tau)+(\text{smoothed }z\text{-channel})\big],\qquad\tau>\delta,$$
and $\mathcal Z(\Delta)\approx\delta\,L(\Delta)$ at the same order. With one-signed weights, $\mathrm{sign}\,\mathcal Z=\mathrm{sign}(K)=\mathrm{sign}(\rho_c)$ — negative leverage ($\rho_c<0$) gives the empirically-signed effect. Note that here — unlike in the linear-Gaussian benchmark, where $\mathbb E[\sqrt{V_t}]$ was ill-defined — every ingredient is well-defined since $\sigma\ge\sigma_{\min}$.

**Consequence for attribution (C18, part of C3/C21):** the weak Zumbach signal and volatility clustering (persistence of $V$, whose timescales are the $\kappa_j$ already at the frozen-Gaussian level, cf. [MS Prop 9.1/9.10]) are **Layer-1 + readout properties**. "Layer 2 directly generating volatility clustering and the asymmetric Zumbach effect" misattributes both.

### 7.3 Proposition Z (impossibility of sign-folding with odd $\phi$) — the decisive negative result

**Hypotheses.** Case A; $\phi$ **odd** (e.g. tanh) applied componentwise; $z_0=0$ (or the symmetric stationary point); readout as in (D2).

**Statement.** Let $T$ denote the path map $M\mapsto-M$ (sign reversal of the driver). Then $r[TM]=-r[M]$, $z[TM]=-z[M]$, hence $u[TM]-b_{\rm out}=-(u[M]-b_{\rm out})$: the readout argument is exactly antisymmetric about $b_{\rm out}$. Since $x\mapsto F(b_{\rm out}+x)^2$ is **strictly increasing**, the volatility response to a trend and to its sign-reverse satisfies $\sigma[TM]=F\big(b_{\rm out}-(u-b_{\rm out})\big)\lessgtr\sigma[M]$ strictly (one large, one pushed toward the floor). Consequently **no parameter choice** $(\Lambda,c,A,W_{zr},W_{zz},w_{\rm out},b_{\rm out})$ produces a sign-folded response: the architecture has no ARCH/magnitude channel, and the *strong* Zumbach mechanism of the quadratic class is structurally absent.

**Proof.** Linearity of (D3) in $dM$ gives $r[TM]=-r[M]$. In Case A with $\phi$ odd, the pair $(-r,-z)$ solves (D4) driven by $-r$ with the same initial point (uniqueness of the Carathéodory ODE), so $z[TM]=-z[M]$. Antisymmetry of $u-b_{\rm out}$ follows by linearity of the readout; strict monotonicity of $F(\cdot)^2$ precludes an interior minimum of the response profile. ∎

**Scope and honest limits.** The proposition is a *pathwise* statement about the response map; conditional-expectation versions ($x\mapsto\mathbb E[V_{t+\Delta}\mid\text{trend}=x]$ monotone) are expected but require control of the stationary conditional law under feedback and are not claimed. Second-order curvature of $F^2$ does generate *some* even correlation (the Hermite-2 coefficient of $F^2$ at the operating point is nonzero), but the qualitative folded shape — both signs raising vol — is impossible under the hypotheses. **Repair options:** give $\phi$ an even component (then $z$ carries $|{\rm trend}|$-type features and folding is restored through $w_z$); or add a quadratic term to the readout, the sign-folding engine of [MS §5, Cor 5.2]; or (Case B) drive $z$ with $dM$ through a state-dependent loading, creating area/quadratic content. Each is a *specification*, i.e. exactly what (U1)/(U2) leave open.

### 7.4 Remaining wording items

- **C17:** $W_{zr}$ maps $r\to z$ *across layers*; "transfer from fast nodes to slow nodes" describes an intra-layer cascade (upper-triangular drift within one bank — the Pallavicini Cascade), which is not what (D4) does unless $W_{zr},A$ are given that structure (unstated). Rewrite as "cross-layer injection of the multi-scale basis into the interaction bank".
- **C16/C21:** with (U1),(U2) resolved in the "even-component" direction, Layer 2 *can* carry the magnitude channel, and $W_{zr},W_{zz}$ then *shape* the asymmetry; "controlled by" remains an overstatement until a $\mathcal Z$-formula (a four-point computation in the sense of [MS §9.2]) is exhibited. Until then C16/C21 are design intentions.

### 7.5 Measure caveat

The note validates against $\mathbb P$-measure stylized facts while the natural use is $\mathbb Q$-pricing. Restating the relevant split ([REV §10.2]): the structure-function content of §4 is drift-insensitive (quadratic variation is measure-invariant; Prop A holds under either measure with its own $\bar m$), but $\mathcal Z$ and leverage are finite-lag expectations that mix in the drift: comparing model-$\mathbb Q$ values of $\mathcal Z$ to empirical ($\mathbb P$) estimates requires an explicit risk-premium specification, and the functional $V=\Phi(S\text{-path})$ itself changes across measures unless $\mu_S$ is handled consistently (the martingale part of returns is measure-dependent). One clarifying sentence in the note would prevent a referee round-trip.

---

## 8. The calibration claim (C6, C22): when is this actually reservoir computing?

The RC selling point — states computed once, only a static readout trained — requires the state paths to be *independent of the trained parameters*. Here $\sigma=F(w_{\rm out}^\top h+b_{\rm out})$ sits inside the state dynamics, so:

**Proposition R.** (i) *Teacher forcing under $\mathbb P$:* given an *observed* return path (equivalently $dM$ from data), $r_t$ — and in Case A also $z_t$ — are computable **without knowledge of $(w_{\rm out},b_{\rm out})$** (P2's formulas use only $dM$). Fitting $(w_{\rm out},b_{\rm out})$ to realized-volatility targets is then a static, nonlinear-link regression (a log/softplus-link GLM in the sense of [MS §5]); the RC decoupling holds exactly. (ii) *Simulation under $\mathbb Q$ (pricing calibration):* the law of $h$ depends on $(w_{\rm out},b_{\rm out})$ through $\sigma$ in the driver; changing the readout changes the paths. Calibration to option prices is a full nonlinear SDE inverse problem — pathwise gradients exist (smooth coefficients ⇒ tangent process), but "optimization isolated entirely to the final static readout" is **false** in this regime, and the "highly efficient" claim needs the same evidence any SDE calibration does. ∎

So C22 is exactly half-true, split along the $\mathbb P/\mathbb Q$ line — which the note never draws. (This also re-derives §4.4's "permitted vs enforced": under (ii) the calibrated $w_r$ co-determines $K$, hence the measured $H$.)

---

## 9. Open problem: martingality of the price (pricing well-posedness)

$V=F(u)^2$ has quadratic growth in $h$, the noise is multiplicative with linear growth, and the tails of $u$ under $\pi$ need not be Gaussian; hence Novikov-type criteria fail generically and $\mathbb E[\mathcal E(\int\sigma\,dW)_T]=1$ is not automatic — the same delicacy as the softplus/exponential readouts flagged in [MS §3.4 caveat (iii)] and [REV §3.4].

**Conjecture M (with proof route).** Under (S) and the hypotheses of §5.3, $S$ is a true martingale under the pricing measure **iff** $\rho_c=w_r^\top c\le0$ (non-positive structural leverage), plus an explicit growth bound. *Route:* one-noise models are exactly the setting of the Sin (1998) / Lions–Musiela (2007) / Andersen–Piterbarg (2007) explosion test: under the measure with numeraire $S$, the driver gains drift $+\sigma_t\,dt$, so the readout argument gains drift $\rho_c\,\sigma^2\approx\rho_c\,u^2$ for $u\to+\infty$. If $\rho_c>0$ this is a $+u^2$ feedback ⇒ the auxiliary process explodes with positive probability ⇒ $S$ is a strict local martingale; if $\rho_c<0$ the feedback is restoring from above ⇒ non-explosion ⇒ true martingale. Making this rigorous (localization, the $z$-block, Case B) is a well-posed, publishable lemma; until then, any pricing claim built on the architecture is conditional. Note the calibrated sign will be negative (leverage), which is the favorable case — but favored, not proved.

---

## 10. Corrected statements (drop-in replacements for the note)

1. *(for C15/C20)* "Layer 1 applies an unpolluted bank of exponential filters to the return martingale; at stationarity its readout's second-order structure equals $\mathbb E[\sigma^2]$ times the deterministic multifactor proxy of the fractional kernel (Prop A). With input/readout weights $a_j\propto\kappa_j^{1/2-H}$ on the log-grid, the target $H$ is reproduced on $[\kappa_{\max}^{-1},\kappa_{\min}^{-1}]$ up to quadrature error; the infinitesimal exponent is $\tfrac12$ at any finite $N_r$, and exactness requires $N_r\to\infty,\kappa_{\max}\to\infty$."
2. *(for C4/C9)* "The floored-softplus readout has linear growth, making the system globally Lipschitz: paths cannot explode in finite time, unconditionally. Second-moment stationarity additionally requires the subcriticality condition $\|K\|_{L^2}^2<1$."
3. *(for C10/C8)* "$\sigma\ge\sigma_{\min}$ keeps the price driver non-degenerate; near the floor the volatility's own dynamics (and the readout gradients) switch off at rate $F'(u)$ — a sticky, not absorbing, floor. The floor also imposes $\mathrm{VIX}\ge100\,\sigma_{\min}$."
4. *(for C18/C3/C21)* "Under the martingale measure the Zumbach statistic reduces to the leverage channel, which Layer 1 with $\rho_c<0$ already produces with the correct sign and exact one-sidedness. The strong (magnitude/ARCH) channel requires an even component in $\phi$ or a quadratic readout term; with odd $\phi$ it is structurally absent (Prop Z)."
5. *(for C12)* the sentence in §6.3 above.
6. *(for C5)* replace "fully autonomous" by "endogenous (input-driven by the return martingale)".
7. *(for C22)* "Readout-only training holds exactly for teacher-forced fitting to observed returns; risk-neutral calibration to option prices is a full SDE inverse problem, since the readout parameters enter the state dynamics."
8. Specify (D4)'s diffusion and $\phi$ — the note's Zumbach and micro-scale claims cannot be evaluated, let alone proven, until (U1)/(U2) are fixed.

---

## 11. References (those load-bearing for this audit; ⚑ = verify exact bibliographic data before citing)

Bernstein/Laplace representation and multifactor (Markovian) approximation of rough kernels: Carmona–Coutin–Montseny; **Abi Jaber–El Euch**, *Multifactor approximation of rough volatility models*, SIAM J. Fin. Math. 10(2), 309–349 (2019); Bayer–Breneis ⚑; Alfonsi–Kebaier ⚑. Endogenous PDV: **Guyon–Lekeufack**, *Volatility is (mostly) path-dependent*, QF 23(9), 1221–1258 (2023). Zumbach and the weak/strong distinction: **Zumbach**, *Time reversal invariance in finance*, QF 9(5), 505–515 (2009); **El Euch–Gatheral–Radoičić–Rosenbaum**, *The Zumbach effect under rough Heston*, QF 20(2), 235–241 (2020) ⚑; **Blanc–Donier–Bouchaud**, *Quadratic Hawkes processes for financial prices*, QF 17(2), 171–188 (2017). Martingality: **Sin** (1998), Adv. Appl. Probab. 30, 256–268; **Lions–Musiela** (2007), Ann. IHP (C) 24(1), 1–16; **Andersen–Piterbarg** (2007), Finance Stoch. 11(1), 29–50. Ergodicity/hypoellipticity: Meyn–Tweedie; Khasminskii; Hörmander. Reservoir universality context: Grigoryeva–Ortega (2018); Gonon–Grigoryeva–Ortega; Cuchiero–Gonon–Grigoryeva–Ortega–Teichmann (2021/22). Internal: [MS] = `esn_signature_volterra_note.pdf` (eqs (3.8)–(3.11), (9.13), Props 9.1/9.10, §5, §9.2); [REV] = the Pallavicini review report (§3.1–3.2, §3.4, §9.1, §10.1, §10.2, §10.4).
