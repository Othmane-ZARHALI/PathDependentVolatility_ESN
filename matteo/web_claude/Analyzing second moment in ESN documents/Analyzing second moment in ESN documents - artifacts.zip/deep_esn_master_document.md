# Deep ESN for Path-Dependent Volatility — Master Document

**v0.1 — 22 July 2026.** Merger of `deep_esn_architecture_audit.md` and `deep_esn_stylized_facts_feasibility.md`, restructured around explicit cross-links between: the stylized facts we target, the problems of the current architecture, the decisions still to be made, the facts not yet addressed, and the propositions/theorems to prove. Self-contained, single notation. Intended as the reference for both the theoretical write-up and the code implementation (§8). Numerical companion: `verify_second_moment.py` (its check [8] is the direct test of Proposition A). External sources are tagged [MS] = `esn_signature_volterra_note.pdf` and [REV] = the Pallavicini review report; every borrowed result is restated here.

---

## 0. Reading map, ID conventions, and verdict

Five registers, cross-referenced throughout with "→":

- **SF1–SF8** — stylized facts we target (§1); **SF-G1–G3** — facts currently missed or out of scope (§6).
- **C1–C22** — the claims of the original architecture note, each with a verdict (§4.1).
- **I1–I12** — issues: problems with the current architecture, each with its fix or fix-path (§4.2).
- **D1–D8** — decisions and amendments: resolved, proposed, or open (§2.5).
- **Results** — established propositions with proofs (§3): P1–P4, Lemma F, Lemma z, Prop A + Cor A.1, Prop S, T1–T3, Lemma L, Prop W, Prop Z, Prop F, Lemma B, Prop TE, Prop R. **R1–R6** — the roadmap of what remains to prove (§7), including **Conjecture M**.

**Verdict in one paragraph.** The architecture is a two-layer, return-driven, continuous-time reservoir with a floored-softplus volatility readout. Its structural skeleton is sound and provable: well-posed Markovian SDE with no self-referential pathology (P1), *genuine* endogenous PDV with structural leverage (P2), unconditional pathwise non-explosion (P4). Its headline claims, as literally written, are not: the "exact Hurst preservation" fails at fixed dimension and omits the object that encodes $H$ (the kernel weights → I1); "bounded self-exciting stabilization" conflates pathwise and moment stability (→ I2, fixed by condition (S)); "directly generating clustering and the Zumbach effect" misattributes the weak channel and, for odd activations, claims something *impossible* (Prop Z → I3, fixed by decision D2). Every failed claim has a correct, provable surrogate — the strongest being Prop A: the entire self-excitation enters the second-order structure of the Layer-1 feature through one scalar. On the goals side: all eight target facts are reachable in the Case-A construction with two amendments (D2: even component in $\phi$; D4: moment-aware diagnostics), two facts (SF2 tails, SF4 Taylor) belong to the closed loop rather than to any layer, and the correct design philosophy is **axes, not layers** (§5.2). The one genuinely open mathematical gate to pricing use is martingality (Conjecture M → R6).

---

## 1. Goals: the stylized-facts register (SF)

Canonical catalogue: Cont (2001). Diagnostics are named here once and used consistently (definitions of the diagnostic objects in §2.2).

| ID | Fact | Diagnostic | Status in this architecture | Links |
|---|---|---|---|---|
| SF1 | No linear autocorrelation of returns | ACF of $r_{t,\delta}$ $\approx0$ beyond micro lags | ✓ structural (martingale returns) | → P2, D5 |
| SF2 | Heavy-tailed returns (cubic-law range) | Hill tail index $\hat\nu$ of $\lvert r\rvert$; empirical $\nu\in(3,5)$ | ✓ mechanism exact in the scalar caricature; multi-node open | → Prop F, Lemma B, D3, R4; raises urgency of R6 |
| SF3 | Volatility clustering | slow decay of $\rho_1(\tau)$ over a wide lag range | ✓ mid-band from Layer-1 kernel; long end from Layer-2 slow rates | → Cor A.1, D6, I4 |
| SF4 | Taylor effect | $\rho_\theta(\tau)$ largest near $\theta\approx1$; $\rho_1>\rho_2$ | ✓ ordering structural; location of max = calibration | → Prop TE, R5; corollary of SF2 ∧ SF3 |
| SF5 | Leverage effect | one-sided $L(\tau)$, negative | ✓ proved (sign $=\mathrm{sign}(\rho_c)$, one-sidedness exact) | → P3, Prop W |
| SF6 | Weak Zumbach (time-reversal asymmetry, $\mathcal Z\neq0$) | $\mathcal Z(\Delta)$ | ✓ proved: reduces to the leverage channel under martingale normalization | → Prop W, I4 |
| SF7 | Strong Zumbach / ARCH magnitude channel | trend-magnitude forecasting of vol beyond past vol; four-point statistics | ◑ blocked with odd $\phi$ (Prop Z); mechanism restored by D2 | → Prop Z, D2, R3 |
| SF8 | Rough volatility ($H\approx0.1$, band) | log-vol structure function $m_q^{\log}(\Delta)\propto\Delta^{qH}$ | ✓ proved at 2nd-moment level on the window | → Prop A, Cor A.1, Lemma L, D6, D4, I1 |

Missed / out of scope: **SF-G1** (imperfect instantaneous spot–vol correlation), **SF-G2** (jump-type gap risk), **SF-G3** (SSR & skew dynamics; joint SPX/VIX consistency) — §6.

---

## 2. The architecture: specification, notation, assumptions, decisions

### 2.1 Equations (decision D1 applied)

Single Brownian motion $W$ on $(\Omega,\mathcal F,(\mathcal F_t),\mathbb P)$. Asset and driver:
$$\frac{dS_t}{S_t}=\mu_S\,dt+\sigma_t\,dW_t,\qquad dM_t:=\sigma_t\,dW_t .$$
Reservoir state $h_t=[r_t^\top,z_t^\top]^\top\in\mathbb R^{N_r+N_z}$:
$$dr_t=-\Lambda r_t\,dt+c\,dM_t \tag{L1}$$
$$dz_t=\big(-Az_t+\phi(W_{zr}r_t+W_{zz}z_t)\big)\,dt \tag{L2}$$
(no diffusion in (L2): **decision D1**, resolving the truncated "$+\dots$" of the original note's Eq (4); the excluded diffusive-$z$ variant would add its own micro-scale semimartingale term and reopen I12). Readout:
$$\sigma_t=F(u_t),\qquad u_t:=w_r^\top r_t+w_z^\top z_t+b_{\rm out},\qquad F(u):=\sqrt{\sigma_{\min}^2+\mathrm{sp}(u)^2},\qquad V_t:=\sigma_t^2 .$$

### 2.2 Notation (all symbols defined here; used consistently)

| Symbol | Definition |
|---|---|
| $W,\ S_t,\ \mu_S$ | scalar Brownian driver; asset price; known constant drift (measure convention → D5) |
| $\sigma_t,\ V_t$ | instantaneous volatility (readout) and variance $V_t=\sigma_t^2$ |
| $M_t$ | martingale part of cumulative log-return, $M_t=\int_0^t\sigma_s dW_s=\int_0^t(dS_s/S_s-\mu_S ds)$ |
| $r_t,\ \Lambda,\ c$ | Layer-1 state; $\Lambda=\mathrm{diag}(\kappa_1,\dots,\kappa_{N_r})$, $0<\kappa_1<\dots<\kappa_{N_r}$, geometric grid, $\kappa_{\min}=\kappa_1$, $\kappa_{\max}=\kappa_{N_r}$; input loading $c\in\mathbb R^{N_r}$ |
| $z_t,\ A,\ a_z$ | Layer-2 state; decay matrix $A$ with $a_z:=\lambda_{\min}\big(\tfrac12(A+A^\top)\big)>0$ (log-norm condition — eigenvalues alone do not control non-normal transients, cf. I5) |
| $\phi$ | Layer-2 activation, componentwise, bounded and Lipschitz (assumption A1); parity → D2 |
| $W_{zr},\ W_{zz}$ | Layer-2 mixing matrices (cross-layer injection $r\to z$; intra-layer mixing) |
| $w_{\rm out}=(w_r,w_z),\ b_{\rm out}$ | readout weights and bias |
| $\mathrm{sp},\ F,\ u_t$ | softplus $\mathrm{sp}(x)=\ln(1+e^x)$ (recall $\mathrm{sp}(x)-\mathrm{sp}(-x)=x$, $\mathrm{sp}(x)\le x^++\ln2$); readout activation $F$; readout argument $u_t$ |
| $X_t,\ K,\ a_j,\ \rho_c$ | Layer-1 feature $X_t=w_r^\top r_t=\int_{-\infty}^tK(t-s)\,dM_s$; kernel $K(v)=\sum_ja_je^{-\kappa_jv}$ with weights $a_j=w_{r,j}c_j$; $\rho_c:=K(0)=w_r^\top c$ |
| $\Vert K\Vert_{L^2}^2$ | $\int_0^\infty K^2=\sum_{j,k}a_ja_k/(\kappa_j+\kappa_k)$; **condition (S)**: $\Vert K\Vert_{L^2}^2<1$ |
| $\pi,\ \bar m$ | stationary law of $(r,z)$; $\bar m=\mathbb E_\pi[\sigma^2]$ |
| $m_2^Y(\Delta)$ | structure function $\mathbb E[(Y_{t+\Delta}-Y_t)^2]$ of a stationary process $Y$ |
| $Q_K(\Delta)$ | kernel functional $\int_0^\Delta K^2+\int_0^\infty(K(\cdot+\Delta)-K)^2$ (Prop A) |
| $H,\ K_H,\ \mu_H$ | Hurst exponent; Riemann–Liouville kernel $K_H(v)=v^{H-1/2}/\Gamma(H+\tfrac12)$; Bernstein measure $\mu_H(dx)\propto x^{-H-1/2}dx$ with $K_H(v)=\int_0^\infty e^{-xv}\mu_H(dx)$ [MS eq. (3.8)] |
| $r_{t,\delta}$ | return over window $\delta$: $r_{t,\delta}=M_{t+\delta}-M_t$ (martingale normalization $\mu_S=0$ where needed) |
| $\nu$ | tail index of $\sigma$ under $\pi$: $\mathbb P_\pi(\sigma>x)=x^{-\nu}\ell(x)$, $\ell$ slowly varying |
| $\rho_\theta(\tau)$ | power ACF $\mathrm{Corr}\big(\lvert r_{t,\delta}\rvert^\theta,\lvert r_{t+\tau,\delta}\rvert^\theta\big)$ |
| $m_q^{\log}(\Delta)$ | log-vol structure function $\mathbb E\big[\lvert\log\sigma_{t+\Delta}-\log\sigma_t\rvert^q\big]$ (Gatheral–Jaisson–Rosenbaum diagnostic) |
| $\mathcal Z(\Delta)$ | Zumbach statistic $\mathbb E[r_{t+\Delta,\delta}^2 r_{t,\delta}]-\mathbb E[r_{t+\Delta,\delta}r_{t,\delta}^2]$ |
| $L(\tau)$ | leverage function $\mathrm{Cov}(r_{t,\delta},V_{t+\tau})$ |

**Lemma F (readout properties).** $F\in C^\infty$; $\sigma_{\min}<F(u)$ with $F\downarrow\sigma_{\min}$ as $u\to-\infty$ and $F(u)=u+O(1)$ as $u\to+\infty$ (linear growth); $0<F'(u)<\min\{\mathrm{sp}'(u),\mathrm{sp}(u)/\sigma_{\min}\}<1$, so $F$ is 1-Lipschitz and $F'\to0$ exponentially as $u\to-\infty$; $F''$ bounded; $u\mapsto\log F(u)$ is $(1/\sigma_{\min})$-Lipschitz. *(Direct computation: $F'=\mathrm{sp}\cdot\mathrm{sp}'/F$.)*

### 2.3 Standing assumptions

- **(A1)** $\phi$ bounded, globally Lipschitz. Consequence with D1 and (A2): $\lvert z_t\rvert\le e^{-a_zt}\lvert z_0\rvert+\Vert\phi\Vert_\infty/a_z$ deterministically, and $\lvert\dot z_t\rvert\le L_z:=\Vert A\Vert\sup_s\lvert z_s\rvert+\Vert\phi\Vert_\infty$ (variation of constants with the log-norm $a_z$).
- **(A2)** $a_z>0$.
- **(H1)** where stated: $\mathbb E_\pi[\sigma^4]<\infty$ (an $(\mathrm S_4)$-type strengthening of (S)).
- **(H2)** where stated: $\exists f_0>0,\eta\in[0,1)$ with $\pi\big(F'(u_t)\ge f_0\big)\ge1-\eta$ (localization away from the sticky floor).

### 2.4 — (reserved)

### 2.5 Decision register (D) — "things fixed or to be decided"

| ID | Decision | Status | Rationale / links |
|---|---|---|---|
| D1 | Layer 2 is **drift-only** (no diffusion in (L2)) | **Resolved** (user) | closes I12; makes $z\in C^1$ bounded (A1); enables T1, Prop Z as stated |
| D2 | $\phi$ must contain a nonzero **even component**; proposal $\phi(x)=\alpha\tanh(x)+\beta\tanh(x)^2$ | **Proposed, awaiting confirmation** | forced by Prop Z under D1 — the *only* entry point for SF7; bounded+Lipschitz keeps (A1); $\beta$ is the parity dial → R3 |
| D3 | Target tail regime: calibrate to $\nu\in(3,5)$ (cubic-law range)? | **Open** | sets the operating point $1-\Vert K\Vert^2$ (Prop F); interacts with R6 |
| D4 | Moment-aware diagnostics: roughness on $\log\sigma$ ($m_q^{\log}$), clustering on $\rho_1$ not $\rho_2$ | **Adopted** | in the D3 regime $\mathbb E_\pi[\sigma^4]=\infty$, so $m_2^V,\rho_2$ do not exist — matching data (→ Prop TE); Lemma L makes $m_q^{\log}$ transfer rigorous |
| D5 | Measure convention: $\mu_S$ known constant; martingale normalization $\mu_S=0$ for SF1/SF6/Prop W; explicit risk-premium link required before comparing model-$\mathbb Q$ statistics to empirical ($\mathbb P$) facts | **Adopted (convention) / Open (premium spec)** | → I11, §5.4; teacher-forcing (Prop R(i)) is the $\mathbb P$-side fitting route |
| D6 | Kernel weight specification: $a_j\propto\kappa_j^{1/2-H}$ on the log-grid (Laplace quadrature of $\mu_H$) at the fast end; independent slow-end tilt for clustering; Layer-2 rates slower than $\kappa_{\min}$ for the long-memory end | **Proposed** | closes I1; the note specified no weights at all → SF8, SF3 |
| D7 | Choice of $\sigma_{\min}$ subject to the hard floor $\mathrm{VIX}\ge100\,\sigma_{\min}$ | **Open** | → I9; check against low VIX strikes before fixing |
| D8 | Pricing-mode guard until R6 is settled: restrict to $\rho_c\le0$ (structural negative leverage) and/or cap the readout for pricing runs | **Open** | → Conjecture M; urgency raised by SF2 near-criticality |

---

## 3. Established results (with proofs)

### 3.1 Structural layer (P1–P4)

**Proposition P1 (well-posedness; no self-referential pathology).** Under (A1)–(A2) and D1, the $(r,z)$ system with $\sigma=F(u)$ has globally Lipschitz drift and diffusion of linear growth; hence a unique global strong solution for every initial condition and horizon. Given $(r,z)$, $\log S_t=\log S_0+\int_0^t(\mu_S-\tfrac12\sigma_s^2)ds+M_t$ is defined pathwise and $S_t>0$.
*Proof.* Drift: linear plus $\phi\circ$affine, Lipschitz by (A1). Diffusion rows: $c\,F(u)$, and $h\mapsto F(w_{\rm out}^\top h+b_{\rm out})$ is $\Vert w_{\rm out}\Vert$-Lipschitz (Lemma F). Standard Lipschitz-SDE theory. $\sigma$ has continuous paths so the exponential defining $S$ is finite. ∎
*Remark.* The construction looks self-referential ($\sigma$ inside its own driver) and for genuinely path-dependent formulations well-posedness is a real obstacle ([REV §9.1]); here the loop is resolved for free because $(\log S,r,z)$ is a finite-dimensional Markovian SDE. A genuine advantage — the note never states it (→ C1, C7).

**Proposition P2 (genuine endogenous PDV + Markov) — C7 true.** (i) $h=(r,z)$ and $(S,h)$ are Markov. (ii) With $\mu_S$ known, $M_t=\int_0^t dS_s/S_s-\mu_St$ is a functional of the price path; hence $r_t=e^{-\Lambda t}r_0+\int_0^te^{-\Lambda(t-s)}c\,dM_s$, $z_t$ (Carathéodory ODE driven by $r$), and $V_t$ are measurable functionals of $\{S_u\}_{u\le t}$ given $h_0$: endogenous PDV in the Guyon–Lekeufack sense, with **structural** leverage (no free correlation parameter).
*Proof.* Coefficients of $(r,z)$ depend on $(r,z)$ only; composition of measurable maps (the $dM$-integral is pathwise after integration by parts, the kernel being $C^1$). ∎
*Contrast.* The Pallavicini reservoir (exogenous Brownian noise) is **not** a functional of the price path ([REV §3.1–3.2]); this architecture fixes exactly that (→ SF1, SF5).

**Proposition P3 (single noise ⇒ correlation is a sign; local second-order geometry).** With $\rho_c=w_r^\top c$: $d\langle u\rangle_t=\rho_c^2\sigma_t^2dt$, $d\langle\sigma\rangle_t=F'(u_t)^2\rho_c^2\sigma_t^2dt$, $d\langle V\rangle_t=4F'(u_t)^2\rho_c^2\sigma_t^4dt$, $d\langle\log S,\sigma\rangle_t=F'(u_t)\rho_c\sigma_t^2dt$, and $\mathrm{corr}_t(d\log S,d\sigma)\equiv\mathrm{sign}(\rho_c)$.
*Proof.* $du=(\cdot)dt+\rho_c\sigma dW$ since $z$ carries no quadratic variation under D1; Itô on $F,F^2$; $F'>0$. ∎
*Consequences.* Instantaneous lognormal vol-of-variance $=2F'(u_t)\lvert\rho_c\rvert$: bounded, $\approx$ constant in the linear regime (Bergomi-type scaling, good for upward VIX-call smiles), and switching off near the floor (→ I9). Perfect $\pm1$ correlation is intrinsic to single-noise PDV (→ SF-G1).

**Proposition P4 (unconditional pathwise non-explosion) — the true content of C4/C9.** For every parameter choice and horizon, $(r,z,\sigma,S)$ neither explodes nor degenerates: $\sigma_t\ge\sigma_{\min}$, $\sup_{t\le T}(\lvert r_t\rvert+\lvert z_t\rvert)<\infty$ a.s. *Proof:* P1 + $F\ge\sigma_{\min}$. ∎ The stabilizing mechanism is **linear growth** (global Lipschitzness), not boundedness (→ I2 for what it does *not* deliver).

### 3.2 Second-moment core (Prop A, Cor A.1) — SF8, SF3

**Proposition A (exact stationary second-moment identity).** Hypotheses: D1 or not (holds either way); $(r,z)$ stationary under $\pi$ with $\bar m<\infty$ (sufficient: Prop S + §3.3 ergodicity); stationary two-sided version of $r$ (finite start: transients $O(e^{-2\kappa_{\min}t})$). Then for every $\Delta>0$,
$$m_2^X(\Delta)=\bar m\,Q_K(\Delta),\qquad Q_K(\Delta)=\int_0^\Delta K(v)^2dv+\int_0^\infty\big(K(v+\Delta)-K(v)\big)^2dv,$$
equivalently $\mathrm{Var}_\pi(X)=\bar m\Vert K\Vert^2_{L^2}$ and $\mathrm{Cov}(X_t,X_{t+\Delta})=\bar m\int_0^\infty K(v)K(v+\Delta)dv$.
*Proof.* Split the increment at $t$; the pre-$t$ part is $\mathcal F_t$-measurable and the post-$t$ part a martingale increment, so the cross term vanishes (tower). Itô isometry with predictable integrand $\sigma_s$ gives $\int f^2\,\mathbb E[\sigma_s^2]$; stationarity inserts $\bar m$; change variables. ∎
**Reading.** *The entire self-excitation — Layer 2 included — enters the second-order structure of the Layer-1 feature only through the scalar $\bar m$.* All fractional content reduces to the deterministic kernel functional $Q_K$; the architecture sits on the **common-driver / pathwise side** of the dichotomy in [MS eq. (3.11)] (a superposition of OU factors with a *common* Brownian is an $L^2$ pathwise approximation of $\int K_H\,dM$; *independent* per-node noises reproduce only the autocovariance). The design choice is right; the note never says why (→ C15, C19).

**Corollary A.1 (three regimes, explicit constants).**
$$Q_K(\Delta)=\sum_{j,k}\frac{a_ja_k}{\kappa_j+\kappa_k}\Big[\big(1-e^{-(\kappa_j+\kappa_k)\Delta}\big)+\big(1-e^{-\kappa_j\Delta}\big)\big(1-e^{-\kappa_k\Delta}\big)\Big].$$
- **Micro** ($\Delta\lesssim\kappa_{\max}^{-1}$): $m_2^X=\bar m\rho_c^2\Delta+O(\Delta^2)$ — infinitesimal $H=\tfrac12$ whenever $\rho_c\neq0$ (the input-driven instance of [MS eq. (3.10)]: any $C^2$ readout of a finite-dimensional Itô diffusion is micro-$H=\tfrac12$). Disproves the "exact $H$" reading of C15. (If $\rho_c=0$: micro-smooth while window-rough — degenerate curiosity.)
- **Window** ($\kappa_{\max}^{-1}\lesssim\Delta\lesssim\kappa_{\min}^{-1}$): with D6 weights ($a_j\propto\kappa_j^{1/2-H}$, all positive),
$$m_2^X(\Delta)=\bar m\,c_H\Delta^{2H}\big(1+\varepsilon_N(\Delta)\big),\qquad c_H=\frac1{2H}+\int_0^\infty\big((1+s)^{H-\frac12}-s^{H-\frac12}\big)^2ds,$$
(the ideal-kernel identity $Q_{K_H}(\Delta)=c_H\Delta^{2H}$ is exact by scaling), $\varepsilon_N$ controlled by $\Vert K-K_H\Vert_{L^2(0,T)}$: algebraic rates in $N_r$ for the naive log-grid, geometric for optimized nodes (Carmona–Coutin–Montseny; Abi Jaber–El Euch; Bayer–Breneis ⚑; Alfonsi–Kebaier ⚑).
- **Macro** ($\Delta\gtrsim\kappa_{\min}^{-1}$): saturation at $2\mathrm{Var}_\pi(X)=2\bar m\Vert K\Vert^2$.

**Numerical confirmation** (`verify_second_moment.py`, check [8]; Euler $dt=10^{-3}$, $N_r=6$, $\kappa\in[1,50]$ log-grid, $H=0.15$, $2\Vert K\Vert^2=0.30$): ratio $m_2^{\rm MC}/(\bar m\,Q_K)$ across three decades:

| $\Delta$ | 0.002 | 0.010 | 0.050 | 0.200 | 1.000 | 4.000 |
|---|---|---|---|---|---|---|
| ratio | 1.023 | 1.021 | 1.018 | 1.013 | 1.012 | 1.012 |

Flat to 1–2% (the residual is the $O(dt)$ Euler weak bias).

**Where $H$ lives (→ I1, D6, C20).** The exponent is the decay profile of the weights $a_j$; $\Lambda$ only sets the window. The note specifies "geometrically spaced eigenvalues" and no weights: as written, nothing selects any $H$. And since $w_r$ is trained, even correct $c_j\propto\kappa_j^{1/2-H}$ makes the architecture **permit** rather than **enforce** the target $H$ — the two-way ablation of [REV §10.4] (fix $w_r$, measure $H$ / constrain the spectral tilt, measure fit) is the required diagnostic.

**Clustering as the other end of the same object (→ SF3).** $m_2=2(\mathrm{Var}-\mathrm{Cov})$, so $\mathrm{ACF}(\tau)\approx1-(\tau/\tau_*)^{2H}$ over the rough band; beyond it, the linearized (frozen-Gaussian) variance ACF is $\mathrm{Cov}\sim\sum_j\tfrac{a_j^2\bar m}{2\kappa_j}e^{-\kappa_j\tau}$, and a slow-end profile $a_j^2/\kappa_j\propto\kappa_j^{\beta-1}\times$(grid mass) produces $\mathrm{ACF}(\tau)\sim\tau^{-\beta}$ across the slow band ([MS Prop 9.1/9.10] superposition mechanism). Roughness constrains the *fast* end of the Laplace measure, clustering the *slow* end: a broken power law in $a_j$ accommodates both — **no conflict** — with the usual exponential cutoff beyond $\kappa_{\min}^{-1}$ unless Layer 2 takes over: choosing rates of $A$ slower than $\kappa_{\min}$ makes the bounded, $C^1$ channel $w_z^\top z$ the long-horizon clustering bank, without disturbing micro/band regimes (T1). This is the one "layer owns a fact-cluster" assignment that survives scrutiny.

### 3.3 Moment stability and ergodicity (Prop S) — closes I2

**Proposition S (subcriticality).** Under D1, (A1)–(A2): if
$$\textbf{(S)}\qquad \Vert K\Vert^2_{L^2(0,\infty)}<1,$$
then $\sup_{t\ge0}\mathbb E[\sigma_t^2]<\infty$ for every initial condition, and any stationary law satisfies $\bar m\le C/(1-\theta)$, $\theta<1$ explicit.
*Proof.* (i) Stationary a priori bound: $\mathbb E_\pi[X^2]=\bar m\Vert K\Vert^2$ (Prop A). From $\mathrm{sp}(x)\le x^++\ln2$: $\mathrm{sp}(x)^2\le(1+\varepsilon)x^2+C_\varepsilon$; under D1, $\lvert w_z^\top z+b_{\rm out}\rvert\le C_z$ deterministically, so $u^2\le(1+\varepsilon)X^2+C'_\varepsilon$ and $\bar m\le C''_\varepsilon+(1+\varepsilon)^2\Vert K\Vert^2\bar m$; let $\varepsilon\downarrow0$. (ii) Non-stationary: $m(t)=\mathbb E[\sigma_t^2]$ obeys $m(t)\le C+(1+\varepsilon)^2\int_0^tK(t-s)^2m(s)ds$, a linear Volterra inequality with kernel $L^1$-norm $<1$: summable resolvent ⇒ $\sup_tm<\infty$. ∎
*Remarks.* The cruder bound $\mathrm{sp}^2\le2\ln^22+2x^2$ gives $2\Vert K\Vert^2<1$; (S) is the sharp version of this argument, but only *sufficient* — the true threshold is open (one-sidedness of $\mathrm{sp}^2$ gives slack). If (S)-type control fails, $\mathbb E[\sigma_t^2]$ can grow exponentially while paths never explode (P4): every stationarity-based diagnostic would be a non-stationary artifact — the note needs (S) and never states it (→ C4, I2). The tail interpretation of the (S)-margin is Prop F below.

**Ergodicity (sketch).** Under (S), $\mathcal V=\lvert r\rvert^2+\lvert z\rvert^2$ is a Lyapunov function. Irreducibility is delicate under D1: the diffusion is **rank one** (single field $g(h)=(cF(u),0)$); Hörmander via iterated brackets — $[b,g]$ yields $\Lambda c$ (and $\phi'\,W_{zr}c$ in the $z$-block); $\{\Lambda^kc\}$ spans $\mathbb R^{N_r}$ by Vandermonde when the $\kappa_j$ are distinct and $c_j\neq0$; a spanning condition on $(A,W_{zr},W_{zz})$ propagates to $z$. Generic hypoellipticity + Lyapunov ⇒ unique invariant law, geometric ergodicity (Meyn–Tweedie/Khasminskii).

### 3.4 Transfer through the readout (Lemma z, T1–T3, Lemma L) — SF8 measurement

**Lemma z.** Under D1+(A1)–(A2): $z\in C^1$ with $\lvert\dot z\rvert\le L_z$, so $\mathbb E[(w_z^\top(z_{t+\Delta}-z_t))^2]\le\Vert w_z\Vert^2L_z^2\Delta^2$.

**Proposition T1 (exponent decoupling for $u$).** $\big\lvert m_2^u(\Delta)^{1/2}-m_2^X(\Delta)^{1/2}\big\rvert\le\Vert w_z\Vert L_z\Delta$ (Minkowski + Lemma z); on the window $m_2^u=m_2^X\big(1+O(\Delta^{1-H})\big)$: **Layer 2 contributes level, not small-scale structure.** (A diffusive $z$ would break this — excluded by D1.)

**Proposition T2 (exact micro rates).** Under (H1): $\lim_{\Delta\downarrow0}m_2^\sigma(\Delta)/\Delta=\rho_c^2\,\mathbb E_\pi[F'(u_t)^2\sigma_t^2]$ and $\lim_{\Delta\downarrow0}m_2^V(\Delta)/\Delta=4\rho_c^2\,\mathbb E_\pi[F'(u_t)^2\sigma_t^4]$. *Proof sketch:* Itô (P3 rates); drift/cross remainders $O(\Delta^2),O(\Delta^{3/2})$ dominated via (H1), boundedness of $F',F''$. ∎

**Proposition T3 (band slope transfer).** Under (H1)+(H2), on the window: $f_0^2(1-\eta')\,m_2^u(\Delta)\lesssim m_2^\sigma(\Delta)\le m_2^u(\Delta)$ with tail terms controlled by Cauchy–Schwarz and fourth moments; hence the log–log slope of $m_2^\sigma$ equals that of $m_2^X$ up to $o(1)$. *Not claimed:* equality of constants; anything near the floor, where (H2) fails by design (sticky floor is genuinely smoother). *Proof sketch:* upper bound by 1-Lipschitzness; lower via second-order Taylor, remainder $\mathbb E\lvert\delta\rvert^3\lesssim m_2^u{}^{3/2}=o(m_2^u)$ on the window (BDG+(H1)), main term restricted to $\{F'\ge f_0\}$. ∎

**Lemma L (log-vol transfer — the D4 diagnostic is rigorous).** $\log F$ is $(1/\sigma_{\min})$-Lipschitz (Lemma F), so $m_2^{\log\sigma}(\Delta)\le\sigma_{\min}^{-2}m_2^u(\Delta)$ — requiring only $\bar m<\infty$, i.e. (S), **valid even when $\sigma$ is heavy-tailed** (unlike $m_2^V$, which needs $\mathbb E\sigma^4<\infty$ and does not exist in the D3 regime). Lower bounds/slope: as T3 with $F'/F$ in place of $F'$.

### 3.5 Leverage and weak Zumbach (Prop W) — SF5, SF6; fixes attribution I4

Under the martingale normalization ($\mu_S=0$, → D5):

**Proposition W.** (i) *Exact one-sidedness:* for $\tau<0$, $L(\tau)=0$ ($V_{t+\tau}$ is $\mathcal F_t$-measurable; $r_{t,\delta}$ a martingale increment after $t$); likewise $\mathbb E[r_{t+\Delta,\delta}r_{t,\delta}^2]=0$ identically, so
$$\mathcal Z(\Delta)=\mathbb E[r_{t+\Delta,\delta}^2\,r_{t,\delta}]:$$
**the entire Zumbach statistic is the leverage channel.** (ii) *First-order magnitude (frozen/linearized hypothesis):* freezing $\sigma\approx\bar\sigma$ in the driver and linearizing $V=F(u)^2$ at the operating point $\bar u$,
$$L(\tau)\approx\delta\,\bar\sigma^2\,G'(\bar u)\big[K(\tau)+(\text{smoothed }z\text{-channel})\big],\qquad G'=2FF',\qquad \mathcal Z(\Delta)\approx\delta\,L(\Delta),$$
with $\mathrm{sign}\,\mathcal Z=\mathrm{sign}(K)=\mathrm{sign}(\rho_c)$ for one-signed weights: $\rho_c<0$ gives the empirical sign. All ingredients are well-defined here since $\sigma\ge\sigma_{\min}$ (contrast the ill-defined $\mathbb E[\sqrt{V_t}]$ in the linear-Gaussian benchmark [MS eq. (9.13)]). ∎ *(Upgrading (ii) beyond the frozen regime is part of R2/R3.)*

**Attribution (→ I4, C18):** SF5, SF6, and mid-band SF3 are **Layer-1 + readout** properties. "Layer 2 directly generating volatility clustering and the asymmetric Zumbach effect" misattributes all of them.

### 3.6 The impossibility result (Prop Z) — the gate to SF7; forces D2

**Definition (sign-folding / magnitude channel).** The response of volatility to the driving trend is *folded* if it is even around an interior minimum: both large up- and large down-trends raise volatility (the ARCH/GJR/$R_2$-type feature; the strong-Zumbach engine — quadratic Hawkes, Blanc–Donier–Bouchaud 2017; quadratic rough Heston, Gatheral–Jusselin–Rosenbaum 2020 ⚑; rough Heston alone has only the weak effect, El Euch–Gatheral–Radoičić–Rosenbaum 2020 ⚑; [MS §4–5, Cor 5.2]).

**Proposition Z.** Under D1, $\phi$ **odd** (e.g. tanh), $z_0=0$ (or symmetric stationary point): sign reversal of the driver $M\mapsto-M$ gives $r\mapsto-r$, $z\mapsto-z$ (uniqueness of the ODE), hence $u-b_{\rm out}\mapsto-(u-b_{\rm out})$; strict monotonicity of $x\mapsto F(b_{\rm out}+x)^2$ then precludes a folded response for **any** parameter choice $(\Lambda,c,A,W_{zr},W_{zz},w_{\rm out},b_{\rm out})$: the architecture has **no ARCH/magnitude channel**, hence no strong Zumbach of the quadratic class. ∎
*Scope.* Pathwise statement about the response map; conditional-expectation versions are expected but not claimed. Second-order curvature of $F^2$ yields *some* even correlation, but never the folded shape.
**Repair — the even channel (D2).** With $\phi=\alpha\tanh+\beta\tanh^2$ (or any bounded Lipschitz even part), $z$ integrates even functionals of the smoothed trends $W_{zr}r$. By Itô, the square of an exponentially-weighted trend contains the exponentially-weighted **realized variance** $\int e^{-2\kappa(t-s)}d[M]_s$ plus a martingale part: the even channel spans both trend-magnitude and realized-variance features — a strict superset of the Guyon–Lekeufack $(R_1,R_2)$ pair, with $R_1$ on Layer 1 and $R_2$-type content on Layer 2. The channel *saturates* in extremes ($\tanh^2$, $z$ bounded): the strong effect is produced in the bulk, which protects (S) and is arguably realistic. Theorem = roadmap R3.

### 3.7 Fat tails from the closed loop (Prop F, Lemma B) — SF2; interprets the (S)-margin

On the linear branch of the soft floor the readout argument is a **multiplicative-noise** process: along the excursion direction, $du\approx-\kappa_{\rm eff}u\,dt+\rho_cF(u)\,dW$ with $F(u)\sim u$.

**Proposition F (scalar caricature — exact).** For the one-node model $du=-\kappa u\,dt+\rho_cF(u)\,dW$ with $F(u)=u$ on $u\ge u_0>0$ and uniformly elliptic mean-reverting behavior below $u_0$: the stationary density solves the Fokker–Planck equation; the power ansatz $p(x)\propto x^{-\alpha-1}$ on the linear branch gives $-\kappa\alpha+\tfrac12\rho_c^2\alpha(\alpha-1)=0$, i.e.
$$\nu=\alpha=1+\frac{2\kappa}{\rho_c^2}$$
— a tunable Pareto tail for $\sigma$ (continuous-time analogue of Nelson's (1990) GARCH-diffusion inverse-gamma tail; Kesten 1973; Buraczewski–Damek–Mikosch 2016). ∎

**Lemma B (Breiman transfer).** Returns are a Gaussian mixture, $r_{t,\delta}\approx\sigma_t\sqrt\delta Z$: if $\sigma$ is regularly varying with index $-\nu$ and $Z$ has all moments, $\mathbb P(\lvert r\rvert>x)\sim\mathbb E\lvert Z\rvert^\nu\,\mathbb P(\sigma\sqrt\delta>x)$ (Breiman 1965): **the return tail index equals $\nu$.** Empirical $\nu\in(3,5)$ (cubic-law range, Gopikrishnan et al. 1999 ⚑) ⇔ $\rho_c^2/\kappa_{\rm eff}\in(\tfrac12,1)$ (→ D3).

**Consistency check ((S) ⇔ finite variance).** In the scalar caricature $\Vert K\Vert^2=\rho_c^2/(2\kappa)$, so $\textbf{(S)}\iff\rho_c^2<2\kappa\iff\nu>2$ (up to one-sided corrections): **the subcriticality condition of Prop S is exactly the finite-variance condition on the tail index.** One dial — the distance to criticality $1-\Vert K\Vert^2$ — is simultaneously the moment-stability margin and the tail heaviness; the model is *designed* to live near-critical, the quadratic-Hawkes reading of market fat tails.

*Status:* scalar exact; **multi-node exponent is a conjecture** (Lyapunov-exponent/Kesten-type problem; heuristically the slowest heavily-loaded mode dominates, $\nu\approx1+2\kappa_{\rm eff}/\rho_c^2$). Numerics: Hill estimator on long simulations → R4.

### 3.8 Taylor effect as a corollary (Prop TE) — SF4

With $r=\sigma\sqrt\delta Z$ conditionally Gaussian, tails of index $\nu$, persistent $\sigma$:
$$\rho_\theta(\tau)=A_\theta\cdot\mathrm{Corr}\big(\sigma_t^\theta,\sigma_{t+\tau}^\theta\big),\qquad A_\theta=\frac{(\mathbb E\lvert Z\rvert^\theta)^2\,\mathrm{Var}(\sigma^\theta)}{\mathbb E\lvert Z\rvert^{2\theta}\,\mathrm{Var}(\sigma^\theta)+\big(\mathbb E\lvert Z\rvert^{2\theta}-(\mathbb E\lvert Z\rvert^\theta)^2\big)(\mathbb E\sigma^\theta)^2}.$$
**Proposition TE.** (i) $\rho_\theta$ exists iff $\theta<\nu/2$: with $\nu<4$ the squared-return ACF does not exist in population (its sample version is unstable) while $\rho_1$ is well-defined — Taylor's ordering $\rho_1>\rho_2$ is **structural**. (ii) The attenuation factor is bounded by $(\mathbb E\lvert Z\rvert^\theta)^2/\mathbb E\lvert Z\rvert^{2\theta}$, strictly decreasing in $\theta$ (log-convexity of moments): large-$\theta$ ACFs degrade even when they exist. ∎ The location of the maximum near $\theta\approx1$ is a quantitative outcome of the calibrated $(\nu,\text{persistence})$ pair (Ding–Granger–Engle 1993; He–Teräsvirta 1999 ⚑) — **no new architectural element needed**: SF4 = joint signature of SF2 ∧ SF3, and a free out-of-sample diagnostic of the tail/persistence balance (→ R5).

### 3.9 Calibration split (Prop R) — resolves C22, I7

**Proposition R.** (i) *Teacher forcing under $\mathbb P$:* given an observed return path ($dM$ from data), $r_t$ and (under D1) $z_t$ are computable **without knowledge of $(w_{\rm out},b_{\rm out})$** (P2's formulas use only $dM$); fitting the readout to realized-vol targets is a static nonlinear-link regression (log/softplus-link GLM, [MS §5]) — the RC decoupling holds exactly. (ii) *Simulation under $\mathbb Q$ (pricing calibration):* the law of $h$ depends on $(w_{\rm out},b_{\rm out})$ through $\sigma$ in the driver; calibration to option prices is a full nonlinear SDE inverse problem — pathwise gradients exist (smooth coefficients ⇒ tangent process), but "optimization isolated entirely to the final static readout" is **false** in this regime. ∎
The $\mathbb P/\mathbb Q$ line the note never draws (→ D5, I11); it also re-derives "permitted vs enforced" $H$ (§3.2).

---

## 4. The original note: claims and issues

### 4.1 Claim inventory (C1–C22)

Verdicts: ✓ correct/provable; ✓* correct under hypotheses supplied here; ✗ false as stated; ◑ not provable as stated; **O** open.

| ID | Location | Claim (paraphrase) | Verdict | Links |
|---|---|---|---|---|
| C1 | Abstract | ESN embedded in an SDE; reservoir = CDE driven by the martingale part of returns | ✓ | P1 |
| C2 | Abstract, §3 | "dynamically generates rough volatility signatures" | ◑→✓* | Prop A, Cor A.1, D6, I1 |
| C3 | Abstract, §3.2, §4 | "captures the Zumbach effect" | ◑; ✗ (strong sense) for odd $\phi$ | Prop W, Prop Z, D2, R3 |
| C4 | Abstract, §2 | "prevents numerical explosions through **bounded** self-exciting mechanisms" | ✗ wording; ✓ pathwise; ✓* moments | P4, Prop S, I2 |
| C5 | §1 | "fully **autonomous**" | ✗ terminology | I6 |
| C6 | §1 | "trained **linear** readout" | ✓* (affine ∘ fixed activation) | Prop R, I7 |
| C7 | §1 | endogenous, path-dependent, Markovian in $(S,h)$ | ✓ | P2 |
| C8 | §2 | stabilizes "without killing optimization gradients" | ✗ as absolute | I9 |
| C9 | §2 | unbounded upper tail avoids exponential explosion | ✓ | P1, P4 |
| C10 | §2 | floor prevents collapse "and structural freezing of the SDE" | ✓ price / ✗ vol dynamics | P3, I9 |
| C11 | §3 | roughness+Zumbach "require multi-scale memory and dense non-linear crosstalk" | ◑ right instinct, wrong objects | D6, D2, §5.2 |
| C12 | §3 | "a single dense matrix smears the relaxation spectrum" | ✗ as stated | I5 |
| C13 | §3 | block-triangular, "isomorphic to a Deep ESN", "forward-flowing" | ◑ drift level only | §5.2, T1 |
| C14 | §3.1 | Layer 1 = "decoupled bank of linear OU processes" | ✗ strictly / ✓ as linear filter of $M$ | P2, Prop A |
| C15 | §3.1 | "no cross-talk ⇒ **exact** target Hurst preserved" | ✗; surrogate ✓ | Prop A, Cor A.1, I1 |
| C16 | §3.2 | Layer 2 "extracts cross-correlations … directional impact" | ◑ needs D2 | Prop Z, R3 |
| C17 | §3.2 | "$W_{zr}$ transfers excitations fast→slow" | ✗ wording | I10 |
| C18 | §3.2, §4 | Layer 2 "directly generating volatility clustering" | ✗ misattributed | Prop W, §3.2, I4 |
| C19 | §4 | "independent spectral decoupling" | ◑; ✓ at 2nd-moment level | Prop A, T1 |
| C20 | §4 | "roughness is tuned by $\Lambda$" | ✗ | I1, D6 |
| C21 | §4 | "asymmetry controlled by $W_{zr},W_{zz}$" | ◑ | D2, R3 |
| C22 | §4 | "optimization isolated to $w_{\rm out}$, highly efficient" | ✓ ($\mathbb P$ teacher-forcing) / ✗ ($\mathbb Q$) | Prop R, I7 |
| — | implicit | prices well-defined ($S$ true martingale) | **O** | Conjecture M, R6, D8 |

### 4.2 Issues register (I) with fixes / corrected drop-in statements

| ID | Problem | Fix / corrected statement | Status |
|---|---|---|---|
| I1 | Roughness overclaim + **no weight specification**: nothing in the note selects $H$ (C15, C20, C2) | Adopt D6; replace by: *"Layer 1 applies an unpolluted bank of exponential filters to the return martingale; at stationarity its readout's second-order structure equals $\mathbb E[\sigma^2]$ times the deterministic multifactor proxy of the fractional kernel (Prop A). With $a_j\propto\kappa_j^{1/2-H}$ the target $H$ is reproduced on $[\kappa_{\max}^{-1},\kappa_{\min}^{-1}]$ up to quadrature error; the infinitesimal exponent is $\tfrac12$ at any finite $N_r$; exactness requires $N_r\to\infty,\kappa_{\max}\to\infty$."* | fixed (theory); D6 pending confirmation |
| I2 | Moment stability silently assumed (C4) | State condition (S); replace by: *"Linear growth makes the system globally Lipschitz: paths cannot explode, unconditionally. Second-moment stationarity additionally requires $\Vert K\Vert_{L^2}^2<1$."* | fixed (Prop S) |
| I3 | Strong-Zumbach mechanism impossible with odd $\phi$ under D1 (C3, C16, C21) | Adopt D2 (even component); theorem via R3 | fix specified; D2 pending confirmation |
| I4 | Misattribution: clustering + weak Zumbach credited to Layer 2 (C18) | Replace by: *"Under the martingale measure the Zumbach statistic reduces to the leverage channel, which Layer 1 with $\rho_c<0$ produces with the correct sign and exact one-sidedness (Prop W); mid-band clustering is a Layer-1 kernel property. The strong (magnitude) channel requires the even component of $\phi$ (D2); with odd $\phi$ it is structurally absent (Prop Z)."* | fixed |
| I5 | "Dense matrix smears the spectrum" imprecise (C12) | Replace by: *"an uncontrolled dense drift loses the weight/quadrature structure that encodes $H$, and non-normal mixing adds transient amplification (numerical abscissa / pseudospectra, not eigenvalues, [REV §10.1]); a diagonal Layer 1 keeps the kernel weights addressable."* | fixed |
| I6 | "Fully autonomous" contradicts the input-driven design (C5) | Rename **endogenous** (input-driven by the return martingale); "autonomous" is the *opposite* regime in the [MS]/[REV] taxonomy | fixed (wording) |
| I7 | RC-efficiency claim unqualified (C6, C22) | Prop R; add the $\mathbb P$ (teacher-forcing) vs $\mathbb Q$ (SDE inverse problem) split | fixed |
| I8 | Martingality untouched by the floor; Novikov fails generically | Conjecture M + route (§7.3); interim guard D8 | **open** (R6) |
| I9 | Floor claims half-wrong (C8, C10): $F'\to0$ kills vol dynamics and gradients near the floor; hard VIX floor | Replace by: *"$\sigma\ge\sigma_{\min}$ keeps the price driver non-degenerate; near the floor the volatility's own dynamics and the readout gradients switch off at rate $F'(u)$ — a sticky, not absorbing, floor. The floor imposes $\mathrm{VIX}\ge100\,\sigma_{\min}$."* → D7 | fixed (statement); D7 open |
| I10 | "$W_{zr}$ fast→slow" mischaracterizes a cross-layer map (C17) | Rewrite: *"cross-layer injection of the multi-scale basis into the interaction bank"* | fixed (wording) |
| I11 | No measure statement; $\mathbb P$-facts vs $\mathbb Q$-pricing conflated | D5; §5.4 item 5 | convention fixed; premium spec open |
| I12 | Eq (4) truncated ("$+\dots$") — analysis was blocked | **Resolved by D1** (drift-only) | closed |

---

## 5. The linkage layer

### 5.1 Master coverage map (facts ↔ mechanism ↔ dial ↔ results ↔ open items)

| Fact | Generating mechanism | Architectural dial | Supporting results | Blocking / open |
|---|---|---|---|---|
| SF1 | martingale returns | — | P2 | D5 (normalization) |
| SF5, SF6 | monotone readout of signed trend, $\rho_c<0$ | Layer 1 + readout **sign** | P3, Prop W | full nonlinear $\mathcal Z$ formula → R2/R3 |
| SF8 | common-driver kernel quadrature | $\Lambda$ (window) + weight **shape** at fast $\kappa$ (D6) | Prop A, Cor A.1, T1–T3, Lemma L | I1 fixed; enforcement ablation ([REV §10.4]) |
| SF3 (mid) | slow end of the same Laplace measure | weight shape at slow $\kappa$ (D6) | Cor A.1 (macro), linearized ACF | window cutoff beyond $\kappa_{\min}^{-1}$ |
| SF3 (long) | slow nonlinear drift integrals | Layer-2 rates $A\prec\kappa_{\min}$ | Lemma z, T1 | quantitative ACF = linearized computation |
| SF2 | multiplicative loop closure near criticality | loop **gain** $1-\Vert K\Vert^2$; balance $\kappa_{\rm eff}$ vs $\rho_c^2$ | Prop F, Lemma B, (S)⇔$\nu>2$ | multi-node exponent → R4; D3 |
| SF4 | tails × persistence through the Gaussian mixture | corollary of SF2 ∧ SF3 | Prop TE | max-location numerics → R5 |
| SF7 | even features of past trends feeding $\sigma$ | Layer-2 **parity** $\beta$ (D2) | Prop Z (obstruction), even-channel mechanism (§3.6) | theorem → R3 |
| pricing use | true-martingale property | leverage sign $\rho_c\le0$; cap (D8) | — | Conjecture M → R6; D7, D8 |

### 5.2 The corrected design philosophy: axes, not layers

The one-layer-per-fact picture does not survive; a sharper version does. The facts map onto four near-orthogonal **axes**, and the layering is valuable because it makes the axes independently addressable:

1. **Kernel shape** ($a_j$ profile across the $\Lambda$-grid): SF8 (fast end) and SF3-mid (slow end) — one Laplace measure, two asymptotics.
2. **Loop gain and balance** ($\Vert K\Vert^2$ vs 1; $\kappa_{\rm eff}$ vs $\rho_c^2$): SF2, and jointly with axis 1, SF4.
3. **Nonlinearity parity** (odd channel = Layer 1 + monotone readout; even channel = Layer-2 $\beta$, D2): SF5/SF6 vs SF7. The even channel *must* live in Layer 2 (Prop Z under D1).
4. **Layer-2 timescales** ($A,W_{zr},W_{zz}$): SF3-long and the lag structure of SF7.

Two facts (SF2, SF4) are produced by **no layer**: they belong to the closed loop — a feature, since they come free from the same near-critical regime, with (S) as the single stability/heaviness dial. This extends the orthogonality principle of [MS] (expressivity structure ⊥ control identity) with the parity and slow-drift axes.

### 5.3 Dependency graph

```
SF8  <- D6 (weights)                      <- Prop A, Cor A.1, T1-T3, Lemma L (D4)   [I1 fixed]
SF3  <- D6 slow-end  + Layer-2 slow rates <- Cor A.1(macro), linearized ACF          [cutoff §5.4-4]
SF5,SF6 <- sign(rho_c)<0                  <- P3, Prop W                              [I4 fixed]
SF7  <- D2 (even phi)  [else blocked: Prop Z]                                        -> R3
SF2  <- near-critical (S)-margin, D3      <- Prop F, Lemma B, (S)<=>nu>2             -> R4 ; raises R6 urgency
SF4  <- SF2 and SF3                       <- Prop TE                                 -> R5
pricing <- Conjecture M (R6), D8, D7 (VIX floor)
SF-G1 <- would need exogenous vol factor (new decision if pursued; dilutes P2 endogeneity)
```

### 5.4 Tensions and hard limits (what "yes" does not include)

1. **Moment regime forces the diagnostics** (D4): with $\nu\in(3,5)$, $\mathbb E\sigma^4=\infty$ ⇒ $m_2^V$ and $\rho_2$ do not exist; use $m_q^{\log}$ (Lemma L) and $\rho_1$. Not a defect — the data's own moment regime — but every claim must be stated for objects that exist.
2. **Tails vs martingality:** the near-critical regime generating $\nu\in(3,5)$ is where Conjecture M matters most; $\rho_c<0$ is the favorable case but unproven → D8 until R6.
3. **Single noise:** $\mathrm{corr}_t(d\log S,d\sigma)\equiv\pm1$ (P3). SSR/skew-dynamics diagnostics inherit this rigidity (→ SF-G1, SF-G3).
4. **Everything is window-limited:** roughness, power-law ACFs, Pareto tails hold over ranges set by $(\kappa_{\min},\kappa_{\max},N_r,A)$; semimartingale micro-behavior and exponential/Gaussian far ends. Matches finite-sample data, but must be stated (the (S1) lesson of Cor A.1 generalizes).
5. **$\mathbb P/\mathbb Q$:** SF2/SF4/SF6/SF7 are $\mathbb P$-statistics; pricing is $\mathbb Q$. Teacher forcing (Prop R(i)) fits the $\mathbb P$-facts; using the same reservoir for pricing needs an explicit risk-premium link (D5). Structure functions are drift-insensitive (quadratic variation is measure-invariant; Prop A holds under either measure with its own $\bar m$); $\mathcal Z$ and $L$ are not.

---

## 6. Stylized facts currently missed or out of scope (SF-G)

- **SF-G1 (imperfect spot–vol correlation).** Structurally out of reach: single noise ⇒ $\pm1$ (P3). Remedy = exogenous vol factor (Guyon–Lekeufack's residual noise), a new decision if pursued, at the cost of diluting the endogeneity of P2.
- **SF-G2 (jumps / gap risk).** No jump component; very short-horizon tail behavior and gap risk are diffusive-only. Extension would change the micro regime of Cor A.1 and the SSR limit.
- **SF-G3 (SSR & skew dynamics; joint SPX/VIX consistency).** Programme-level diagnostics not treated in the merged sources; they presuppose pricing well-posedness, hence are gated by R6 (and constrained by P3's $\pm1$ correlation). Flagged as next-stage scope, not attempted here.

---

## 7. Theorem roadmap (R) and the open conjecture

| ID | Statement to prove | Depends on | Effort | Status |
|---|---|---|---|---|
| R1 | Roughness & mid-band clustering: Prop A + Cor A.1 + Lemma L | D6 | done + half-page lemma | **done** |
| R2 | Leverage / weak Zumbach beyond the frozen regime: full nonlinear one-sided $L(\tau)$, $\mathcal Z(\Delta)$ | Prop W | ~1 page | open (formalization) |
| R3 | **Strong Zumbach theorem:** with $\phi=\alpha\tanh+\beta\tanh^2$, compute $\mathcal Z(\Delta)=\mathcal Z_{\rm lev}+\beta\,\mathcal Z_{\rm mag}+O(\beta^2)$ with explicit kernels/signs (four-point machinery of [MS §9.2] on the linearized loop) | D2, R2 | substantial | open |
| R4 | Tails: (a) rigorous scalar Prop F (boundary classification + stationary density); (b) multi-node exponent (Kesten/Lyapunov-exponent) + Hill numerics; (c) Lemma B | D3 | (a),(c) short; (b) numerics an afternoon, theory open | open |
| R5 | Taylor: Prop TE + numerical $\theta$-profile at the calibrated $(\nu,\text{persistence})$ | R4 | short | open |
| R6 | **Conjecture M** (below) | D8 interim | a real lemma | open |

**Conjecture M (martingality / pricing well-posedness).** $V=F(u)^2$ has quadratic growth in $h$ with linear-growth multiplicative noise; Novikov-type criteria fail generically ([MS §3.4 caveat (iii)], [REV §3.4]). *Conjecture:* under (S) and §3.3 hypotheses, $S$ is a true martingale under the pricing measure **iff** $\rho_c\le0$, plus an explicit growth bound. *Route:* one-noise models are the setting of the Sin (1998) / Lions–Musiela (2007) / Andersen–Piterbarg (2007) explosion test: under the $S$-numeraire measure the driver gains drift $+\sigma_t\,dt$, so $u$ gains drift $\rho_c\sigma^2\approx\rho_c u^2$ as $u\to+\infty$: $\rho_c>0$ ⇒ auxiliary explosion ⇒ strict local martingale; $\rho_c<0$ ⇒ restoring from above ⇒ true martingale. The calibrated sign will be negative (leverage) — favored, not proved.

---

## 8. Toward implementation (structure for the code)

Design principle: OOP, reusing what exists (`verify_second_moment.py` already contains the exact-stationary OU benchmark class and the Prop-A feedback test). Every register object maps to a code artifact and a test:

| Document object | Code artifact | Test / acceptance |
|---|---|---|
| Kernel, weights, (S), $Q_K$, D6 quadrature (fast tilt $H$, slow tilt $\beta_{\rm ACF}$) | `kernel_bank.py: KernelBank` | window-constant identity $Q_{K_H}=c_H\Delta^{2H}$; $\Vert K\Vert^2$ vs (S) margin report |
| Model spec (D1, D2 with $(\alpha,\beta)$, Lemma F readout, D7 $\sigma_{\min}$) | `model.py: DeepESNPDV` | P1 sanity (Lipschitz constants), floor behavior |
| Simulation: $\mathbb Q$-mode (joint loop) and $\mathbb P$ teacher-forced mode ($dM$ from data) | `simulate.py: Simulator` | Prop A ratio flatness (port of check [8]); T2 micro-rate check |
| Diagnostics: $m_2$, $m_q^{\log}$, $\rho_\theta$, Hill $\hat\nu$, $\mathcal Z(\Delta)$, $L(\tau)$ | `diagnostics.py` | Prop F: $\hat\nu$ vs $1+2\kappa/\rho_c^2$ (scalar); Prop TE $\theta$-profile; Prop W sign/one-sidedness |
| Teacher-forced readout fit (Prop R(i); GLM link) | `fit.py` | R(i) invariance: states independent of $(w_{\rm out},b_{\rm out})$ |
| Ablations: permitted-vs-enforced $H$; $\beta$-sweep for SF7 | `experiments/` | [REV §10.4] two-way ablation; R3 support sims |

**Build order (mirrors roadmap value):** 1. `KernelBank` + `DeepESNPDV` (largely a refactor of existing tested code); 2. `diagnostics.py`; 3. R4(b) numerics (Hill on long runs, multi-node $\nu$ vs caricature); 4. R3 support simulations ($\beta$-sweep of $\mathcal Z$); 5. teacher-forced fit. Everything seeded; intermediate outputs written to disk early and often.

---

## 9. References (⚑ = verify exact bibliographic data before citing)

Cont (2001), *Empirical properties of asset returns: stylized facts and statistical issues*, QF 1(2), 223–236. Taylor (1986), *Modelling Financial Time Series*, Wiley. Ding–Granger–Engle (1993), *A long memory property of stock market returns and a new model*, J. Empirical Finance 1(1), 83–106. Gatheral–Jaisson–Rosenbaum (2018), *Volatility is rough*, QF 18(6), 933–949. Guyon–Lekeufack (2023), *Volatility is (mostly) path-dependent*, QF 23(9), 1221–1258. Blanc–Donier–Bouchaud (2017), *Quadratic Hawkes processes for financial prices*, QF 17(2), 171–188. El Euch–Gatheral–Radoičić–Rosenbaum (2020), *The Zumbach effect under rough Heston*, QF 20(2), 235–241 ⚑. Gatheral–Jusselin–Rosenbaum (2020), *The quadratic rough Heston model and the joint S&P 500/VIX smile calibration problem*, Risk (Cutting Edge) / arXiv:2001.01789 ⚑. Zumbach (2009), *Time reversal invariance in finance*, QF 9(5), 505–515. Nelson (1990), *ARCH models as diffusion approximations*, J. Econometrics 45, 7–38. Kesten (1973), Acta Math. 131, 207–248. Buraczewski–Damek–Mikosch (2016), *Stochastic Models with Power-Law Tails*, Springer. Breiman (1965), Theory Probab. Appl. 10(2), 323–331. Gopikrishnan–Plerou–Amaral–Meyer–Stanley (1999), Phys. Rev. E 60, 5305 ⚑. He–Teräsvirta (1999), *Properties of moments of a family of GARCH processes*, J. Econometrics 92, 173–192 ⚑. Carmona–Coutin–Montseny; Abi Jaber–El Euch (2019), SIAM J. Fin. Math. 10(2), 309–349; Bayer–Breneis ⚑; Alfonsi–Kebaier ⚑ (multifactor rough-kernel approximation). Sin (1998), Adv. Appl. Probab. 30, 256–268; Lions–Musiela (2007), Ann. IHP (C) 24(1), 1–16; Andersen–Piterbarg (2007), Finance Stoch. 11(1), 29–50 (martingality). Meyn–Tweedie; Khasminskii; Hörmander (ergodicity/hypoellipticity). Grigoryeva–Ortega (2018); Gonon–Grigoryeva–Ortega; Cuchiero–Gonon–Grigoryeva–Ortega–Teichmann (2021/22) (reservoir universality context). Internal: [MS] eqs (3.8)–(3.11), (9.13), Props 9.1/9.10, §5, §9.2; [REV] §3.1–3.2, §3.4, §9.1, §10.1, §10.2, §10.4.
